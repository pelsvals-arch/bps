"""Build closing_lines from odds_snapshots.

Definition of "closing line":
    For each (event, market, line, outcome), the MAX decimal odds across all
    bookmakers observed in the window [start_at - close_window, start_at).

Why max and not last:
    predictions.odds_decimal is "best price across books at decision time"
    (see Trainer._generate_predictions). Comparing best-at-decision with
    last-at-close would produce a positive bias by construction. Using max
    on both sides makes CLV apples-to-apples.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from betdash.db.repository import Repository

logger = logging.getLogger(__name__)


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def refresh_closing_lines(
    repo: Repository,
    close_window_minutes: int = 60,
    fallback_window_hours: int = 24,
) -> int:
    """Rebuild closing_lines. Returns number of rows written."""
    events = repo.events_for_resolution()
    start_by_uid: dict[str, datetime] = {}
    for ev in events:
        s = _to_dt(ev.start_at)
        if s is not None:
            start_by_uid[str(ev.event_uid)] = s

    with repo.connection() as conn:
        rows = conn.execute(
            """
            SELECT event_uid, market, line, outcome, odds_decimal, bookmaker, observed_at
            FROM odds_snapshots
            WHERE is_live = 0
            ORDER BY event_uid, market, line, outcome, observed_at, id
            """
        ).fetchall()

    primary: dict[tuple, dict] = {}
    fallback: dict[tuple, dict] = {}
    book_primary: dict[tuple, dict] = {}
    book_fallback: dict[tuple, dict] = {}
    close_delta = timedelta(minutes=close_window_minutes)
    fallback_delta = timedelta(hours=fallback_window_hours)

    def _keep_best(target: dict[tuple, dict], key: tuple, payload: dict) -> None:
        prev = target.get(key)
        if prev is None or payload["odds_closing"] > prev["odds_closing"]:
            target[key] = payload

    for row in rows:
        uid = str(row["event_uid"])
        start_at = start_by_uid.get(uid)
        if start_at is None:
            continue
        observed = _to_dt(row["observed_at"])
        if observed is None or observed >= start_at:
            continue
        odds = float(row["odds_decimal"])
        if odds <= 1.0:
            continue
        key = (uid, str(row["market"]), row["line"], str(row["outcome"]))
        book_key = (*key, str(row["bookmaker"]))
        payload = {"odds_closing": odds, "bookmaker": row["bookmaker"], "captured_at": observed.isoformat()}
        in_primary = observed >= start_at - close_delta
        in_fallback = observed >= start_at - fallback_delta
        if in_primary:
            _keep_best(primary, key, payload)
            _keep_best(book_primary, book_key, payload)
        elif in_fallback:
            _keep_best(fallback, key, payload)
            _keep_best(book_fallback, book_key, payload)

    closing = dict(fallback)
    closing.update(primary)
    per_book = dict(book_fallback)
    per_book.update(book_primary)
    if not closing:
        logger.warning("No closing lines found; check start_at and pre-start snapshots")
        return 0
    with repo.connection() as conn:
        conn.execute("DELETE FROM closing_lines")
        conn.executemany(
            """
            INSERT INTO closing_lines(event_uid, market, line, outcome, odds_closing, bookmaker, captured_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [(uid, market, line, outcome, v["odds_closing"], v["bookmaker"], v["captured_at"])
             for (uid, market, line, outcome), v in closing.items()],
        )
        conn.execute("DELETE FROM closing_lines_book")
        conn.executemany(
            """
            INSERT INTO closing_lines_book(event_uid, market, line, outcome, bookmaker, odds_closing, captured_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [(uid, market, line, outcome, v["bookmaker"], v["odds_closing"], v["captured_at"])
             for (uid, market, line, outcome, _book), v in per_book.items()],
        )
        conn.commit()
    logger.info(
        "Refreshed %d closing lines (%d primary, %d fallback-only, %d per-book)",
        len(closing), len(primary), len(closing) - len(primary), len(per_book),
    )
    return len(closing)
