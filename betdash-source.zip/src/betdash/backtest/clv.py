"""CLV: did the model get a better price than the market at close?"""
from __future__ import annotations
import logging, math, statistics
from betdash.db.repository import Repository
logger = logging.getLogger(__name__)

def _safe_odds(v):
    try:
        f=float(v); return f if math.isfinite(f) and f>1.0 else None
    except (TypeError, ValueError):
        return None

def compute_clv(decision_odds, closing_odds):
    d=_safe_odds(decision_odds); c=_safe_odds(closing_odds)
    if d is None or c is None: return None
    return (1.0/c)/(1.0/d)-1.0

def backfill_clv(repo: Repository) -> int:
    with repo.connection() as conn:
        rows=conn.execute("""
            SELECT p.prediction_id,p.odds_decimal,
                   COALESCE(
                       cb.odds_closing,
                       CASE WHEN NULLIF(p.bookmaker, '') IS NULL THEN c.odds_closing END
                   ) AS odds_closing
            FROM predictions p
            LEFT JOIN closing_lines_book cb
              ON cb.event_uid=p.event_uid AND cb.market=p.market
             AND (cb.line=p.line OR (cb.line IS NULL AND p.line IS NULL))
             AND cb.outcome=p.outcome
             AND cb.bookmaker=p.bookmaker
            LEFT JOIN closing_lines c
              ON c.event_uid=p.event_uid AND c.market=p.market
             AND (c.line=p.line OR (c.line IS NULL AND p.line IS NULL))
             AND c.outcome=p.outcome
            WHERE p.odds_decimal IS NOT NULL
        """).fetchall()
    updates=[
        (row["odds_closing"], clv, row["prediction_id"])
        for row in rows
        if (clv := compute_clv(row["odds_decimal"], row["odds_closing"])) is not None
    ]
    with repo.connection() as conn:
        conn.executemany("UPDATE predictions SET closing_odds=?, clv=? WHERE prediction_id=?", updates)
        conn.commit()
    filled=sum(1 for u in updates if u[1] is not None)
    logger.info("Backfilled CLV for %d/%d predictions", filled, len(updates))
    return filled

def _pct(values, p):
    if not values: return None
    s=sorted(values); k=max(0,min(len(s)-1,int(round(p*(len(s)-1))))); return s[k]

def _agg(values):
    if not values: return {"n":0,"mean":None,"median":None,"pos_pct":None,"p10":None,"p90":None,"trimmed_mean":None,"outlier_pct":None}
    s=sorted(values); trim=int(len(s)*0.05); trimmed=s[trim:-trim] if trim else s
    return {"n":len(values),"mean":statistics.mean(values),"median":statistics.median(values),
            "pos_pct":sum(1 for x in values if x>0)/len(values),"p10":_pct(values,.10),"p90":_pct(values,.90),
            "trimmed_mean":statistics.mean(trimmed) if trimmed else None,
            "outlier_pct":sum(1 for x in values if abs(x)>1.0)/len(values)}

def clv_report(repo: Repository, min_samples: int = 20):
    with repo.connection() as conn:
        rows=conn.execute("""
            SELECT p.market,p.odds_decimal,p.clv
            FROM predictions p
            WHERE p.clv IS NOT NULL
        """).fetchall()
    def bucket(odds):
        if odds<1.5: return "1.01-1.50"
        if odds<2.0: return "1.50-2.00"
        if odds<3.0: return "2.00-3.00"
        if odds<5.0: return "3.00-5.00"
        return "5.00+"
    all_clv=[]; by_market={}; by_bucket={}
    for row in rows:
        v=row["clv"]
        if v is None: continue
        v=float(v); all_clv.append(v)
        by_market.setdefault(str(row["market"] or "?"),[]).append(v)
        odds=_safe_odds(row["odds_decimal"])
        if odds is not None: by_bucket.setdefault(bucket(odds),[]).append(v)
    return {"overall":_agg(all_clv),
            "by_market":{k:_agg(v) for k,v in by_market.items() if len(v)>=min_samples},
            "by_odds_bucket":{k:_agg(v) for k,v in by_bucket.items() if len(v)>=min_samples}}
