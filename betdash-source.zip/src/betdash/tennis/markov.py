"""Point-level Markov simulator for tennis score distributions."""

from __future__ import annotations

import random
from collections.abc import Mapping
from typing import Any

from betdash.tennis.markets import ScoreAtom


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def point_probability_from_serve(stats: Mapping[str, Any]) -> float:
    """Blend serve and return point-win rates into one point probability."""
    served = _number(stats.get("svc_pts"))
    return_points = _number(stats.get("ret_pts"))
    total = served + return_points
    if total <= 0:
        return 0.5
    return (_number(stats.get("svc_won")) + _number(stats.get("ret_won"))) / total


def _point_prob(p1_hold: float, p2_hold: float, server: int) -> float:
    if server == 1:
        return p1_hold
    return 1.0 - p2_hold


def _simulate_game(rng: random.Random, p1_hold: float, p2_hold: float, server: int) -> tuple[int, int]:
    a = b = 0
    for _ in range(1000):
        if (a >= 4 or b >= 4) and abs(a - b) >= 2:
            break
        if rng.random() < _point_prob(p1_hold, p2_hold, server):
            a += 1
        else:
            b += 1
    return a, b


def _simulate_tiebreak(
    rng: random.Random, p1_hold: float, p2_hold: float, first_server: int
) -> bool:
    a = b = 0
    for point in range(1000):
        if (a >= 7 or b >= 7) and abs(a - b) >= 2:
            break
        server = first_server if point % 4 in (0, 3) else 3 - first_server
        if rng.random() < _point_prob(p1_hold, p2_hold, server):
            a += 1
        else:
            b += 1
    return a > b


def _simulate_set(
    rng: random.Random,
    p1_hold: float,
    p2_hold: float,
    first_server: int,
    tiebreak: bool,
) -> tuple[int, int]:
    a = b = 0
    server = first_server
    for _ in range(100):
        game_a, game_b = _simulate_game(rng, p1_hold, p2_hold, server)
        if game_a > game_b:
            a += 1
        else:
            b += 1
        if a >= 6 and a - b >= 2:
            return a, b
        if b >= 6 and b - a >= 2:
            return a, b
        if tiebreak and a == 6 and b == 6:
            return (7, 6) if _simulate_tiebreak(rng, p1_hold, p2_hold, server) else (6, 7)
        server = 3 - server
    return a, b


def markov_score_distribution(
    p1_point_prob: float,
    p2_point_prob: float,
    best_of: int = 3,
    simulations: int = 2000,
    seed: int = 7,
    tiebreak: bool = True,
) -> dict[ScoreAtom, float]:
    """Simulate serve-aware games, sets and match score atoms."""
    p1_hold = min(0.99, max(0.01, _number(p1_point_prob)))
    p2_hold = min(0.99, max(0.01, _number(p2_point_prob)))
    wins_needed = 3 if int(best_of) == 5 else 2
    rng = random.Random(seed)
    counts: dict[ScoreAtom, float] = {}
    for _ in range(max(1, int(simulations))):
        p1_sets = p2_sets = 0
        sets: list[tuple[int, int]] = []
        while p1_sets < wins_needed and p2_sets < wins_needed:
            set_score = _simulate_set(rng, p1_hold, p2_hold, 1 + len(sets) % 2, tiebreak)
            sets.append(set_score)
            if set_score[0] > set_score[1]:
                p1_sets += 1
            else:
                p2_sets += 1
        atom: ScoreAtom = tuple(sets)
        counts[atom] = counts.get(atom, 0.0) + 1.0
    total = float(sum(counts.values()))
    return {atom: count / total for atom, count in counts.items()}
