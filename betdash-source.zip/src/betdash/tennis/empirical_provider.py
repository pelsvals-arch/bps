"""Empirical score distribution provider backed by Sackmann history."""
from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from betdash.data.sackmann import ensure_sackmann_tables
from betdash.tennis.distribution import empirical_score_distribution
from betdash.tennis.markets import ScoreAtom

_SET_SCORE = re.compile(r"(\d+)\s*-\s*(\d+)")


def _canonical_player(value: Any) -> str:
    # Import here to avoid a sports-model ↔ tennis-provider import cycle.
    from betdash.models.features import _sackmann_canonical_name

    return _sackmann_canonical_name(str(value)).casefold()


def _cutoff(target: Mapping[str, Any]) -> str:
    text = str(target.get("observed_at") or "").replace("-", "").replace(":", "")
    return text[:8]


def _p1_first(score: str, winner_is_p1: bool) -> str:
    if winner_is_p1:
        return score
    return _SET_SCORE.sub(lambda m: f"{m.group(2)}-{m.group(1)}", score)


def _as_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def sackmann_history_rows(
    repo: Any,
    p1: str,
    p2: str,
    target: Mapping[str, Any],
    limit: int = 2000,
) -> list[dict[str, Any]]:
    """Load pre-event Sackmann rows for p1/p2, oriented to canonical p1."""
    left = _canonical_player(p1)
    right = _canonical_player(p2)
    if not left or not right:
        return []
    cutoff = _cutoff(target)
    with repo.connection() as conn:
        ensure_sackmann_tables(conn)
        rows = conn.execute(
            """
            SELECT tourney_date, surface, tourney_level, round, best_of,
                   winner_name, loser_name, score, winner_rank, loser_rank
            FROM sackmann_matches
            WHERE (lower(winner_name) IN (?, ?) OR lower(loser_name) IN (?, ?))
              AND (? = '' OR tourney_date < ?)
            ORDER BY tourney_date, tourney_id, match_num
            LIMIT ?
            """,
            (left, right, left, right, cutoff, cutoff, int(limit)),
        ).fetchall()
    out: list[dict[str, Any]] = []
    for row in rows:
        winner = str(row["winner_name"] or "").casefold()
        winner_is_p1 = winner == left
        if not winner_is_p1 and winner != right:
            continue
        w_rank = _as_int(row["winner_rank"]) or 300
        l_rank = _as_int(row["loser_rank"]) or 300
        elo_gap = (l_rank - w_rank) if winner_is_p1 else (w_rank - l_rank)
        out.append(
            {
                "observed_at": str(row["tourney_date"]),
                "surface": row["surface"],
                "tourney_level": row["tourney_level"],
                "round": row["round"],
                "best_of": row["best_of"],
                "score_p1_first": _p1_first(str(row["score"] or ""), winner_is_p1),
                "elo_gap": float(elo_gap),
            }
        )
    return out


def empirical_provider_distribution(
    repo: Any,
    p1: str,
    p2: str,
    target: Mapping[str, Any],
) -> dict[ScoreAtom, float]:
    """Build a score distribution from similar pre-event Sackmann matches."""
    return empirical_score_distribution(sackmann_history_rows(repo, p1, p2, target), target)
