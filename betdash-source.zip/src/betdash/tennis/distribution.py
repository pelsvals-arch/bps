"""Empirical score distributions for tennis markets."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

from betdash.tennis.markets import ScoreAtom
from betdash.tennis.score import parse_tennis_score

ELO_GAP_TOLERANCE = 150.0


def _text(value: Any) -> str:
    return str(value or "").strip().casefold()


def _as_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _time_value(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        try:
            parsed = datetime.strptime(text, "%Y%m%d")
        except ValueError:
            return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _before_target(row: Mapping[str, Any], target: Mapping[str, Any]) -> bool:
    row_time = _time_value(row.get("observed_at") or row.get("tourney_date"))
    target_time = _time_value(target.get("observed_at") or target.get("tourney_date"))
    if row_time is None or target_time is None:
        return True
    return row_time < target_time


def _base_atoms(best_of: Any) -> tuple[ScoreAtom, ...]:
    if _as_int(best_of) == 5:
        return (((6, 4), (6, 3), (6, 4)), ((4, 6), (3, 6), (6, 4)), ((6, 4), (4, 6), (6, 3)))
    return (((6, 4), (6, 3)), ((4, 6), (3, 6)), ((7, 6), (6, 4)))


def _same_context(row: Mapping[str, Any], target: Mapping[str, Any]) -> bool:
    for key in ("surface", "tourney_level", "round"):
        wanted = _text(target.get(key))
        if wanted and _text(row.get(key)) != wanted:
            return False
    if _as_int(row.get("best_of")) != _as_int(target.get("best_of")):
        return False
    row_gap = _as_float(row.get("elo_gap"))
    target_gap = _as_float(target.get("elo_gap"))
    if row_gap is None or target_gap is None:
        return False
    return abs(row_gap - target_gap) <= ELO_GAP_TOLERANCE


def _atom_winner(atom: ScoreAtom) -> str | None:
    left = sum(1 for a, b in atom if a > b)
    right = sum(1 for a, b in atom if b > a)
    if left > right:
        return "p1"
    if right > left:
        return "p2"
    return None


def _normalize(weights: Mapping[ScoreAtom, float]) -> dict[ScoreAtom, float]:
    total = sum(weights.values())
    if total <= 0:
        return {}
    return {atom: weight / total for atom, weight in weights.items()}


def empirical_score_distribution(
    history: Sequence[Mapping[str, Any]],
    target: Mapping[str, Any],
    prior_strength: float = 5.0,
) -> dict[ScoreAtom, float]:
    """Build a smoothed score distribution from contextually similar matches."""
    counts: dict[ScoreAtom, float] = {}
    for row in history:
        if not _same_context(row, target) or not _before_target(row, target):
            continue
        score = parse_tennis_score(str(row.get("score_p1_first") or ""), str(row.get("comment") or ""))
        if score is None or not score.sets:
            continue
        if row.get("is_retirement") or score.retirement or score.walkover:
            continue
        if not score.completed or not score.totals_reliable or score.match_tiebreak:
            continue
        atom = tuple((int(a), int(b)) for a, b in score.sets)
        counts[atom] = counts.get(atom, 0.0) + 1.0

    if not counts:
        atoms = _base_atoms(target.get("best_of"))
        return _normalize({atom: 1.0 + max(0.0, float(prior_strength)) for atom in atoms})

    prior = max(0.0, float(prior_strength)) / len(counts)
    return _normalize({atom: count + prior for atom, count in counts.items()})


def condition_distribution_on_win_prob(
    distribution: Mapping[ScoreAtom, float],
    p1_win_prob: float,
) -> dict[ScoreAtom, float]:
    """Rescale winner groups so P(p1 wins) matches the requested probability."""
    target = min(1.0, max(0.0, float(p1_win_prob)))
    mass = {"p1": 0.0, "p2": 0.0}
    for atom, probability in distribution.items():
        winner = _atom_winner(atom)
        if winner in mass:
            mass[winner] += float(probability)

    if mass["p1"] <= 0 or mass["p2"] <= 0:
        return _normalize({atom: float(probability) for atom, probability in distribution.items()})

    scale = {
        "p1": target / mass["p1"],
        "p2": (1.0 - target) / mass["p2"],
    }
    weights: dict[ScoreAtom, float] = {}
    for atom, probability in distribution.items():
        winner = _atom_winner(atom)
        factor = scale.get(winner or "", 1.0)
        weights[atom] = float(probability) * factor
    return _normalize(weights)
