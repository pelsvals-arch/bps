"""Blend empirical and Markov score distributions by OOF log loss."""
from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any

from betdash.normalize.registry import normalize_name
from betdash.tennis.markets import ScoreAtom
from betdash.tennis.score import parse_tennis_score


def _mass(dist: Mapping[ScoreAtom, float]) -> float:
    return sum(max(0.0, float(v)) for v in dist.values())


def _p1_probability(dist: Mapping[ScoreAtom, float]) -> float:
    total = _mass(dist)
    if total <= 0:
        return 0.5
    p1 = 0.0
    for atom, probability in dist.items():
        left = sum(1 for a, b in atom if a > b)
        right = sum(1 for a, b in atom if b > a)
        if left > right:
            p1 += max(0.0, float(probability))
    return min(max(p1 / total, 1e-6), 1 - 1e-6)


def _actual_p1(actual: Any) -> float | None:
    if not isinstance(actual, (tuple, list)):
        return None
    if len(actual) == 2 and all(isinstance(x, (int, float)) for x in actual):
        return 1.0 if actual[0] > actual[1] else 0.0
    left = right = 0
    for pair in actual:
        try:
            a, b = pair
        except (TypeError, ValueError):
            return None
        if a > b:
            left += 1
        elif b > a:
            right += 1
    if left == right:
        return None
    return 1.0 if left > right else 0.0


def _log_loss(pairs: Sequence[Mapping[str, Any]], get_probability: Any) -> float:
    values: list[float] = []
    for pair in pairs:
        actual = _actual_p1(pair.get("actual"))
        if actual is None:
            continue
        p = min(max(float(get_probability(pair)), 1e-6), 1 - 1e-6)
        values.append(-(actual * math.log(p) + (1 - actual) * math.log(1 - p)))
    return sum(values) / len(values) if values else 0.0


def blend_score_distributions(
    empirical: Mapping[ScoreAtom, float],
    markov: Mapping[ScoreAtom, float],
    weight: float,
) -> dict[ScoreAtom, float]:
    """Create a normalized weighted mixture of two score distributions."""
    w = min(1.0, max(0.0, float(weight)))
    weights: dict[ScoreAtom, float] = {}
    for dist, factor in ((empirical, w), (markov, 1.0 - w)):
        for atom, probability in dist.items():
            weights[atom] = weights.get(atom, 0.0) + max(0.0, float(probability)) * factor
    total = sum(weights.values())
    if total <= 0:
        return {}
    return {atom: probability / total for atom, probability in weights.items()}


def fit_blend_weight(pairs: Sequence[Mapping[str, Any]]) -> tuple[float, dict[str, float]]:
    """Choose blend weight by match-winner log loss on OOF pairs."""
    if not pairs:
        return 0.5, {}
    losses = {
        "empirical": _log_loss(pairs, lambda p: _p1_probability(p["empirical"])),
        "markov": _log_loss(pairs, lambda p: _p1_probability(p["markov"])),
    }
    best_weight, best_loss = 0.5, float("inf")
    for step in range(21):
        weight = step / 20.0
        loss = _log_loss(
            pairs,
            lambda p, w=weight: _p1_probability(
                blend_score_distributions(p["empirical"], p["markov"], w)
            ),
        )
        if loss < best_loss:
            best_weight, best_loss = weight, loss
    losses["blend"] = best_loss
    return best_weight, losses


def fit_blend_weight_from_repository(repo: Any) -> tuple[float, dict[str, float]]:
    """Fit the score-blend weight from settled stored distributions."""
    by_event: dict[str, list[tuple[str, dict[str, Mapping[ScoreAtom, float]]]]] = {}
    for row in repo.score_distributions():
        uid = str(row.get("event_uid"))
        run_id = str(row.get("model_run_id"))
        bucket = by_event.setdefault(uid, [])
        entry = next((item for item in bucket if item[0] == run_id), None)
        if entry is None:
            entry = (run_id, {})
            bucket.append(entry)
        entry[1][str(row.get("provider"))] = row["distribution"]
    events = {str(event.event_uid): event for event in repo.events_for_resolution()}
    pairs: list[dict[str, Any]] = []
    for result in repo.results():
        uid = str(result.get("event_uid"))
        for run_id, distributions in by_event.get(uid, ()):
            if not {"empirical", "markov"} <= distributions.keys():
                continue
            actual = _actual_from_result(result, events.get(uid))
            if actual is None:
                continue
            pairs.append(
                {
                    "empirical": distributions["empirical"],
                    "markov": distributions["markov"],
                    "actual": actual,
                    "model_run_id": run_id,
                }
            )
    return fit_blend_weight(pairs)


def _actual_from_result(result: Mapping[str, Any], event: Any) -> tuple[tuple[int, int], ...] | None:
    score = parse_tennis_score(str(result.get("score") or ""))
    if score is None or not score.sets:
        return None
    sets = tuple((int(a), int(b)) for a, b in score.sets)
    if event is None or not getattr(event, "participant_ids", None):
        return sets
    p1 = normalize_name(str(event.participant_ids[0]).split(":", 1)[-1])
    participant_a = normalize_name(str(result.get("participant_a") or ""))
    if p1 and participant_a and p1 != participant_a:
        return tuple((b, a) for a, b in sets)
    return sets
