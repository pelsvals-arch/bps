"""Resolve tennis markets from a distribution of set-score atoms."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace

from betdash.tennis.score import TennisScore, is_match_tiebreak, is_set_finished

ScoreAtom = tuple[tuple[int, int], ...]

_WINNER_MARKETS = {"match_winner"}
_TOTAL_MARKETS = {"total_games", "total_sets", "set_total"}
_HANDICAP_MARKETS = {"game_handicap", "set_handicap", "set_game_handicap"}
_COMBINED_MARKETS = {"winner_plus_total"}
_SUPPORTED_MARKETS = _WINNER_MARKETS | _TOTAL_MARKETS | _HANDICAP_MARKETS | _COMBINED_MARKETS
_MARKET_ALIASES = {"total_points": "total_games", "spread": "game_handicap"}


def canonical_tennis_market(market: str) -> str:
    """Return the canonical market name, resolving bookmaker aliases."""
    key = str(market or "").strip().casefold()
    return _MARKET_ALIASES.get(key, key)


def _canonical_market(market: str) -> str:
    return canonical_tennis_market(market)


def _outcomes_for(market: str) -> tuple[str, ...]:
    market = _canonical_market(market)
    if market in _WINNER_MARKETS:
        return ("p1", "p2", "push")
    if market in _TOTAL_MARKETS:
        return ("over", "under", "push")
    if market in _HANDICAP_MARKETS:
        return ("p1", "p2", "push")
    if market in _COMBINED_MARKETS:
        return ("p1_over", "p1_under", "p2_over", "p2_under", "push")
    raise ValueError(f"unsupported tennis market: {market}")


def _atom_score(atom: ScoreAtom) -> TennisScore:
    sets = tuple((int(a), int(b)) for a, b in atom)
    games_left = sum(a for a, _ in sets)
    games_right = sum(b for _, b in sets)
    sets_left = sum(1 for a, b in sets if a > b)
    sets_right = sum(1 for a, b in sets if b > a)
    winner_side = "left" if sets_left > sets_right else "right" if sets_right > sets_left else None
    last_a, last_b = sets[-1] if sets else (0, 0)
    match_tiebreak = is_match_tiebreak(last_a, last_b)
    completed = bool(sets) and all(is_set_finished(a, b) for a, b in sets)
    return TennisScore(
        sets=sets,
        sets_left=sets_left,
        sets_right=sets_right,
        games_left=games_left,
        games_right=games_right,
        completed=completed,
        winner_side=winner_side,
        match_tiebreak=match_tiebreak,
        totals_reliable=completed and not match_tiebreak,
    )


def _canonical_score(score: TennisScore, participant_side: str) -> TennisScore:
    side = str(participant_side or "p1").strip().casefold()
    if side in {"p1", "left", "1"}:
        return score
    if side in {"p2", "right", "2"}:
        swapped = tuple((b, a) for a, b in score.sets)
        winner = "left" if score.winner_side == "right" else "right" if score.winner_side == "left" else None
        return replace(
            score,
            sets=swapped,
            sets_left=score.sets_right,
            sets_right=score.sets_left,
            games_left=score.games_right,
            games_right=score.games_left,
            winner_side=winner,
        )
    raise ValueError(f"unsupported participant side: {participant_side}")


def _is_push_line(value: int, line: float) -> bool:
    return float(line).is_integer() and value == int(line)


def _total_outcome(value: int, line: float, reliable: bool) -> str:
    if not reliable or _is_push_line(value, line):
        return "push"
    return "over" if value > line else "under"


def _handicap_outcome(diff: int, line: float) -> str:
    if _is_push_line(diff, line):
        return "push"
    return "p1" if diff > line else "p2"


def _winner_outcome(score: TennisScore) -> str:
    if score.winner_side == "left":
        return "p1"
    if score.winner_side == "right":
        return "p2"
    return "push"


def _resolve_outcome(
    market: str,
    line: float | None,
    score: TennisScore,
    set_index: int | None,
) -> str:
    market = _canonical_market(market)
    if market not in _SUPPORTED_MARKETS:
        raise ValueError(f"unsupported tennis market: {market}")

    if market == "match_winner":
        return _winner_outcome(score)

    if line is None:
        raise ValueError(f"market {market} requires a line")

    if market == "total_games":
        return _total_outcome(score.games_left + score.games_right, line, score.totals_reliable)
    if market == "total_sets":
        return _total_outcome(score.sets_left + score.sets_right, line, score.completed)

    if market == "set_total":
        index = 1 if set_index is None else set_index
        if index < 1 or index > len(score.sets):
            return "push"
        left, right = score.sets[index - 1]
        return _total_outcome(left + right, line, is_set_finished(left, right))

    if market == "game_handicap":
        return _handicap_outcome(score.games_left - score.games_right, line)
    if market == "set_handicap":
        return _handicap_outcome(score.sets_left - score.sets_right, line)
    if market == "set_game_handicap":
        index = 1 if set_index is None else set_index
        if index < 1 or index > len(score.sets):
            return "push"
        left, right = score.sets[index - 1]
        return _handicap_outcome(left - right, line)

    winner = _winner_outcome(score)
    if winner not in {"p1", "p2"}:
        return "push"
    total = _total_outcome(score.games_left + score.games_right, line, score.totals_reliable)
    if total == "push":
        return "push"
    return f"{winner}_{total}"


def market_probabilities(
    distribution: Mapping[ScoreAtom, float],
    market: str,
    line: float | None = None,
    set_index: int | None = None,
) -> dict[str, float]:
    """Aggregate distribution mass into market outcome probabilities."""
    outcomes = _outcomes_for(market)
    result = {outcome: 0.0 for outcome in outcomes}
    for atom, probability in distribution.items():
        outcome = _resolve_outcome(market, line, _atom_score(atom), set_index)
        result[outcome] += float(probability)
    return result


def resolve_tennis_market(
    market: str,
    line: float | None,
    outcome: str,
    score: TennisScore,
    participant_side: str,
) -> float:
    """Return 1/0/0.5 for win/loss/push of one market outcome on a score."""
    canonical = _canonical_score(score, participant_side)
    settlement = _resolve_outcome(market, line, canonical, None)
    wanted = str(outcome or "").strip().casefold()
    if settlement == "push":
        return 0.5
    if wanted == "push":
        return 0.0
    return 1.0 if settlement == wanted else 0.0
