"""Honest accuracy and value evaluation for tennis score distributions."""
from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

from betdash.tennis.markets import ScoreAtom, market_probabilities
from betdash.tennis.score import parse_tennis_score

EvaluationPair = Mapping[str, Any]
_EPS = 1e-12


def _finite_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _clamp(value: float) -> float:
    return min(1.0 - _EPS, max(_EPS, value))


def _sort_key(pair: EvaluationPair) -> tuple[int, float | str]:
    text = str(pair.get("observed_at") or "")
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return (1, text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return (0, parsed.timestamp())


def _log_loss(probability: float, actual: int) -> float:
    p = _clamp(probability)
    return -(math.log(p) if actual == 1 else math.log(1.0 - p))


def _actual_atom(score_text: Any) -> ScoreAtom | None:
    score = parse_tennis_score(str(score_text or ""))
    if score is None or not score.sets:
        return None
    return tuple((int(a), int(b)) for a, b in score.sets)


def evaluation_report(pairs: Sequence[EvaluationPair]) -> dict[str, Any]:
    """Split result quality from betting value over chronological OOF pairs."""
    ordered = sorted(pairs, key=_sort_key)
    brier: list[float] = []
    log_losses: list[float] = []
    score_losses: list[float] = []
    evs: list[float] = []

    for pair in ordered:
        distribution = pair.get("distribution") or {}
        p1 = market_probabilities(distribution, "match_winner").get("p1", 0.0)
        actual_value = _finite_float(pair.get("actual"))
        if actual_value is not None:
            actual = 1 if actual_value >= 0.5 else 0
            brier.append((p1 - actual) ** 2)
            log_losses.append(_log_loss(p1, actual))

        atom = _actual_atom(pair.get("actual_score"))
        if atom is not None:
            score_probability = float(distribution.get(atom, 0.0))
            score_losses.append(-math.log(_clamp(score_probability)))

        market_p = _finite_float(pair.get("market_probability"))
        market_odds = _finite_float(pair.get("market_odds"))
        if (
            market_p is not None
            and market_odds is not None
            and 0.0 < p1 < 1.0
            and 0.0 < market_p < 1.0
            and market_odds > 1.0
        ):
            evs.append(p1 * market_odds - 1.0)

    observed = [str(pair["observed_at"]) for pair in ordered if pair.get("observed_at")]
    return {
        "oof_samples": len(ordered),
        "result_brier": sum(brier) / len(brier) if brier else None,
        "result_log_loss": sum(log_losses) / len(log_losses) if log_losses else None,
        "score_log_loss": sum(score_losses) / len(score_losses) if score_losses else None,
        "value_samples": len(evs),
        "value_ev": sum(evs) / len(evs) if evs else None,
        "first_observed_at": observed[0] if observed else None,
        "last_observed_at": observed[-1] if observed else None,
    }
