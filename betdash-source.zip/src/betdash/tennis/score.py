"""Tennis score parsing for the score-distribution engine."""
from __future__ import annotations

import re
from dataclasses import dataclass

_TIEBREAK = re.compile(r"\(\s*\d+(?:\s*[-–—:]\s*\d+)?\s*\)")
_SET = re.compile(r"(\d+)\s*[-–—:]\s*(\d+)")


def tennis_winner_side(score: str, comment: str = "") -> str | None:
    """Return the winner side from the tennis score parser, if known."""
    parsed = parse_tennis_score(score, comment)
    return parsed.winner_side if parsed is not None else None
_WALKOVER_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (r"\bwalkover\b", r"\bw\.?\s*/?\s*o\.?\b")
)
_RETIREMENT_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (r"\bret\b", r"\bretired\b", r"\bretirement\b", r"\babandoned\b", r"\bdefault\b", r"\bdef\b")
)


@dataclass(frozen=True, slots=True)
class TennisScore:
    sets: tuple[tuple[int, int], ...] = ()
    sets_left: int = 0
    sets_right: int = 0
    games_left: int = 0
    games_right: int = 0
    completed: bool = False
    walkover: bool = False
    retirement: bool = False
    match_tiebreak: bool = False
    winner_side: str | None = None
    totals_reliable: bool = False


def is_set_finished(left: int, right: int) -> bool:
    """Return True for a legal completed set score."""
    hi, lo = max(left, right), min(left, right)
    return (hi >= 6 and hi - lo >= 2) or (hi == 7 and lo <= 6)


def is_match_tiebreak(left: int, right: int) -> bool:
    """Return True for a final-set match tiebreak (first to 10, win by two)."""
    hi, lo = max(left, right), min(left, right)
    return hi >= 10 and hi - lo >= 2


_set_finished = is_set_finished


def _has_marker(text: str, patterns: tuple[re.Pattern[str], ...]) -> bool:
    return any(pattern.search(text) for pattern in patterns)


def parse_tennis_score(score: str, comment: str = "") -> TennisScore | None:
    """Parse a tennis score into set/game counts and settlement flags."""
    raw = str(score or "").strip()
    note = str(comment or "").strip().casefold()
    low = raw.casefold()
    walkover = _has_marker(low, _WALKOVER_PATTERNS) or _has_marker(note, _WALKOVER_PATTERNS)
    if walkover:
        return TennisScore(walkover=True, completed=False, totals_reliable=False)

    retirement = _has_marker(low, _RETIREMENT_PATTERNS) or _has_marker(note, _RETIREMENT_PATTERNS)
    cleaned = _TIEBREAK.sub("", raw)
    pairs = [(int(a), int(b)) for a, b in _SET.findall(cleaned)]
    if not pairs:
        return None

    sets = tuple(pairs)
    games_left = sum(a for a, _ in sets)
    games_right = sum(b for _, b in sets)
    sets_left = sum(1 for a, b in sets if a > b)
    sets_right = sum(1 for a, b in sets if b > a)
    winner_side = None
    if sets_left > sets_right:
        winner_side = "left"
    elif sets_right > sets_left:
        winner_side = "right"

    final_a, final_b = sets[-1]
    match_tiebreak = is_match_tiebreak(final_a, final_b)
    completed = not retirement and all(_set_finished(a, b) for a, b in sets)
    totals_reliable = completed and not match_tiebreak
    return TennisScore(
        sets=sets,
        sets_left=sets_left,
        sets_right=sets_right,
        games_left=games_left,
        games_right=games_right,
        completed=completed,
        retirement=retirement,
        match_tiebreak=match_tiebreak,
        winner_side=winner_side,
        totals_reliable=totals_reliable,
    )
