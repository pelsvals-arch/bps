"""Paper risk engine package."""
