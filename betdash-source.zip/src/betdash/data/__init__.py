"""Data ingestion utilities."""
