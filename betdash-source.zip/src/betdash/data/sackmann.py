from __future__ import annotations

import csv
import sqlite3
from pathlib import Path
from typing import Iterable

SACKMANN_MATCH_COLUMNS = [
    "tour","tourney_id","tourney_name","surface","draw_size","tourney_level",
    "tourney_date","match_num","winner_id","winner_name","loser_id","loser_name",
    "score","best_of","round","minutes",
    "w_ace","w_df","w_svpt","w_1stIn","w_1stWon","w_2ndWon","w_SvGms","w_bpSaved","w_bpFaced",
    "l_ace","l_df","l_svpt","l_1stIn","l_1stWon","l_2ndWon","l_SvGms","l_bpSaved","l_bpFaced",
    "is_retirement","winner_rank","winner_rank_points","loser_rank","loser_rank_points",
]
INT_COLS = {
    "draw_size","match_num","winner_id","loser_id","best_of","minutes",
    "w_ace","w_df","w_svpt","w_1stIn","w_1stWon","w_2ndWon","w_SvGms","w_bpSaved","w_bpFaced",
    "l_ace","l_df","l_svpt","l_1stIn","l_1stWon","l_2ndWon","l_SvGms","l_bpSaved","l_bpFaced",
    "is_retirement","winner_rank","winner_rank_points","loser_rank","loser_rank_points",
}


def _as_int(value: str | None) -> int | None:
    if value is None:
        return None
    v = str(value).strip()
    if v == "" or v.upper() == "NA":
        return None
    try:
        return int(float(v))
    except ValueError:
        return None


def _ensure_sackmann_columns(conn: sqlite3.Connection) -> None:
    cols = {row[1] for row in conn.execute("PRAGMA table_info(sackmann_matches)").fetchall()}
    for name in ("winner_rank", "winner_rank_points", "loser_rank", "loser_rank_points"):
        if name not in cols:
            conn.execute(f"ALTER TABLE sackmann_matches ADD COLUMN {name} INTEGER")


def ensure_sackmann_tables(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS sackmann_matches (
            tour TEXT NOT NULL,
            tourney_id TEXT,
            tourney_name TEXT,
            surface TEXT,
            draw_size INTEGER,
            tourney_level TEXT,
            tourney_date TEXT,
            match_num INTEGER,
            winner_id INTEGER,
            winner_name TEXT,
            loser_id INTEGER,
            loser_name TEXT,
            score TEXT,
            best_of INTEGER,
            round TEXT,
            minutes INTEGER,
            w_ace INTEGER,w_df INTEGER,w_svpt INTEGER,w_1stIn INTEGER,w_1stWon INTEGER,w_2ndWon INTEGER,w_SvGms INTEGER,w_bpSaved INTEGER,w_bpFaced INTEGER,
            l_ace INTEGER,l_df INTEGER,l_svpt INTEGER,l_1stIn INTEGER,l_1stWon INTEGER,l_2ndWon INTEGER,l_SvGms INTEGER,l_bpSaved INTEGER,l_bpFaced INTEGER,
            is_retirement INTEGER NOT NULL DEFAULT 0,
            winner_rank INTEGER,
            winner_rank_points INTEGER,
            loser_rank INTEGER,
            loser_rank_points INTEGER,
            PRIMARY KEY (tour, tourney_id, match_num, winner_id, loser_id)
        )
        """
    )
    _ensure_sackmann_columns(conn)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sackmann_date ON sackmann_matches(tourney_date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sackmann_winner ON sackmann_matches(winner_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sackmann_loser ON sackmann_matches(loser_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sackmann_winner_date ON sackmann_matches(winner_id,tourney_date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sackmann_loser_date ON sackmann_matches(loser_id,tourney_date)")


def ingest_sackmann_matches(repo, csv_paths: Iterable[Path], tour: str) -> int:
    paths = [Path(p) for p in csv_paths]
    inserted = 0
    db_path = getattr(repo, "db_path", None) or repo.path
    conn = sqlite3.connect(db_path)
    try:
        ensure_sackmann_tables(conn)
        for path in paths:
            with path.open(newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                rows = []
                for raw in reader:
                    score = (raw.get("score") or "").strip()
                    row = {"tour": tour.lower(), "is_retirement": 1 if "RET" in score.upper() else 0}
                    for col in SACKMANN_MATCH_COLUMNS:
                        if col in {"tour", "is_retirement"}:
                            continue
                        val = raw.get(col)
                        if col in INT_COLS:
                            row[col] = _as_int(val)
                        else:
                            row[col] = (val.strip() if isinstance(val, str) and val.strip() != "" else None)
                    rows.append(row)
                if not rows:
                    continue
                cols = SACKMANN_MATCH_COLUMNS
                placeholders = ",".join(["?"] * len(cols))
                sql = f"INSERT OR IGNORE INTO sackmann_matches ({','.join(cols)}) VALUES ({placeholders})"
                values = [tuple(r.get(c) for c in cols) for r in rows]
                before = conn.total_changes
                conn.executemany(sql, values)
                inserted += conn.total_changes - before
                # Existing rows were ingested before rank columns existed. Backfill
                # only missing ranks, leaving the rest of the immutable snapshot intact.
                rank_updates = [
                    (
                        r["winner_rank"], r["winner_rank_points"],
                        r["loser_rank"], r["loser_rank_points"],
                        r["tour"], r["tourney_id"], r["match_num"],
                        r["winner_id"], r["loser_id"],
                    )
                    for r in rows
                    if any(r.get(k) is not None for k in (
                        "winner_rank", "winner_rank_points", "loser_rank", "loser_rank_points"
                    ))
                ]
                if rank_updates:
                    conn.executemany(
                        """
                        UPDATE sackmann_matches
                        SET winner_rank = ?, winner_rank_points = ?,
                            loser_rank = ?, loser_rank_points = ?
                        WHERE tour = ? AND tourney_id = ? AND match_num = ?
                          AND winner_id = ? AND loser_id = ?
                          AND winner_rank IS NULL AND loser_rank IS NULL
                        """,
                        rank_updates,
                    )
        conn.commit()
    finally:
        conn.close()
    return inserted
