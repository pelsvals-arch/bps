"""Typer CLI: signals, bet, settle, report, refresh-clv."""
from __future__ import annotations

import json
from typing import Optional

import typer

from betdash.backtest.clv import backfill_clv, clv_report
from betdash.backtest.closing import refresh_closing_lines
from betdash.bets.journal import BetJournal
from betdash.config import Settings
from betdash.db.repository import Repository

app = typer.Typer(help="betdash personal betting system")


def _ctx():
    settings = Settings()
    repo = Repository(settings.db_path)
    return settings, repo


@app.command()
def refresh_closing() -> None:
    """Rebuild closing_lines from odds_snapshots."""
    _, repo = _ctx()
    n = refresh_closing_lines(repo)
    typer.echo(f"closing lines refreshed: {n}")


@app.command()
def refresh_clv() -> None:
    """Backfill predictions.clv from closing_lines."""
    _, repo = _ctx()
    n = backfill_clv(repo)
    typer.echo(f"clv backfilled: {n}")


@app.command()
def clv() -> None:
    """Show CLV report across all predictions."""
    _, repo = _ctx()
    report = clv_report(repo, min_samples=20)
    typer.echo(json.dumps(report, indent=2, default=str))


@app.command()
def signals(limit: int = 20, min_edge: float = 0.03) -> None:
    """List candidate bets where model_prob deviates from current market by >= min_edge."""
    _, repo = _ctx()
    with repo.connection() as conn:
        rows = conn.execute(
            """
            SELECT p.prediction_id, p.event_uid, p.market, p.line, p.outcome,
                   p.model_prob, p.odds_decimal, p.clv
            FROM predictions p
            WHERE p.odds_decimal IS NOT NULL
              AND p.model_prob > 0
            ORDER BY p.created_at DESC, p.model_prob DESC
            LIMIT 1000
            """
        ).fetchall()

    seen: set[tuple] = set()
    out = []
    for r in rows:
        key = (r["event_uid"], r["market"], r["line"], r["outcome"])
        if key in seen:
            continue
        seen.add(key)
        odds = float(r["odds_decimal"])
        implied = 1.0 / odds if odds > 1.0 else None
        if implied is None:
            continue
        model_p = float(r["model_prob"])
        edge = model_p - implied
        if edge >= min_edge:
            out.append({
                "prediction_id": r["prediction_id"],
                "event": r["event_uid"],
                "market": r["market"],
                "line": r["line"],
                "outcome": r["outcome"],
                "model_p": round(model_p, 4),
                "market_implied": round(implied, 4),
                "edge_pct": round(edge * 100, 2),
                "odds": odds,
                "clv": r["clv"],
            })
        if len(out) >= limit:
            break
    typer.echo(json.dumps(out, indent=2, default=str))


@app.command()
def bet(prediction_id: str, stake: float, odds: float,
        bookmaker: Optional[str] = None, notes: Optional[str] = None) -> None:
    """Record a real bet against a prediction."""
    _, repo = _ctx()
    journal = BetJournal(repo)
    b = journal.place(prediction_id, stake, odds, bookmaker, notes)
    typer.echo(f"placed {b['bet_id']} stake={stake} odds={odds} bankroll={b['bankroll_after']:.2f}")


@app.command()
def settle(bet_id: str, won: bool = typer.Option(..., "--won/--lost"),
           notes: Optional[str] = None) -> None:
    """Settle a bet."""
    _, repo = _ctx()
    journal = BetJournal(repo)
    b = journal.settle(bet_id, won, notes)
    typer.echo(f"settled {bet_id} result={'win' if won else 'loss'} pnl={b['pnl']:.2f} bankroll={b['bankroll_after']:.2f}")


@app.command()
def pending() -> None:
    """List open bets."""
    _, repo = _ctx()
    journal = BetJournal(repo)
    typer.echo(json.dumps(journal.open_positions(), indent=2, default=str))


@app.command()
def report() -> None:
    """P&L, ROI, drawdown, CLV on placed bets."""
    _, repo = _ctx()
    journal = BetJournal(repo)
    typer.echo(json.dumps(journal.report(), indent=2, default=str))


@app.command()
def set_bankroll(amount: float) -> None:
    """Set starting bankroll."""
    _, repo = _ctx()
    journal = BetJournal(repo)
    journal._set_bankroll(amount)
    typer.echo(f"bankroll set to {amount:.2f}")


if __name__ == "__main__":
    app()