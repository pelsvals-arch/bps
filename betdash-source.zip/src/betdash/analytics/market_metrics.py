from __future__ import annotations
from datetime import timedelta
from typing import Iterable

def margin(odds: Iterable[float]) -> float:
    vals = [float(o) for o in odds if o is not None and float(o) > 1.0]
    if not vals:
        return 0.0
    return max(0.0, sum(1.0 / o for o in vals) - 1.0)

def fair_odds(odds: Iterable[float]) -> list[float]:
    vals = [float(o) for o in odds if o is not None and float(o) > 1.0]
    if not vals:
        return []
    inv = [1.0 / o for o in vals]
    total = sum(inv)
    if total <= 0:
        return vals
    probs = [i / total for i in inv]
    return [1.0 / p for p in probs]

def edge_vs_consensus(book_odds: float | None, fair: float | None) -> float | None:
    if book_odds is None or fair is None or fair <= 0:
        return None
    return float(book_odds) / float(fair) - 1.0

def movement_delta(old: float | None, new: float | None) -> dict[str, float | None]:
    if old is None or new is None or old == 0:
        return {"abs": None, "pct": None}
    abs_d = float(new) - float(old)
    return {"abs": abs_d, "pct": abs_d / float(old)}

import statistics

def median(values: Iterable[float]) -> float | None:
    vals=[float(v) for v in values if v is not None]
    if not vals: return None
    return float(statistics.median(vals))

def z_score(value: float | None, values: Iterable[float]) -> float | None:
    if value is None: return None
    vals=[float(v) for v in values if v is not None]
    if len(vals)<2: return 0.0
    mu=statistics.fmean(vals)
    sd=statistics.pstdev(vals)
    if sd==0: return 0.0
    return (float(value)-mu)/sd


def movement_windows(history, now=None, windows_min=(1,5,15,60)):
    """Compute pct movement over rolling windows from (dt, odds) history."""
    if not history:
        return {f"{w}m_pct": None for w in windows_min}
    hist = sorted(history, key=lambda x: x[0])
    latest_dt, latest_odds = hist[-1]
    now = now or latest_dt
    out = {}
    for w in windows_min:
        cutoff = now - timedelta(minutes=int(w))
        base = None
        for dt, odds in hist:
            if dt <= cutoff:
                base = odds
            else:
                break
        if base is None:
            # try first point if within window
            for dt, odds in hist:
                if dt >= cutoff:
                    base = odds
                    break
        md = movement_delta(base, latest_odds)
        out[f"{w}m_pct"] = md["pct"] * 100 if md["pct"] is not None else None
    return out
