"""Link predictions to results by canonical participant pair and date."""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from typing import Any

from betdash.normalize.alias_generator import DEFAULT_ALIAS_PATH
from betdash.normalize.registry import normalize_name

_PREFIXES = ("name:", "unresolved:", "ambiguous:", "resolved:")
_ALIAS_REVERSE: dict[str, str] | None = None


def clear_alias_cache() -> None:
    """Drop cached reverse aliases after the alias file changes."""
    global _ALIAS_REVERSE
    _ALIAS_REVERSE = None


def _alias_reverse() -> dict[str, str]:
    global _ALIAS_REVERSE
    if _ALIAS_REVERSE is None:
        mapping: dict[str, str] = {}
        try:
            raw = json.loads(Path(DEFAULT_ALIAS_PATH).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raw = {}
        for canonical, aliases in raw.items():
            if not isinstance(aliases, list):
                continue
            for alias in aliases:
                mapping[normalize_name(alias)] = normalize_name(canonical)
        _ALIAS_REVERSE = mapping
    return _ALIAS_REVERSE


def _canonical_key(value: Any) -> str:
    text = str(value or "")
    for prefix in _PREFIXES:
        if text.startswith(prefix):
            text = text[len(prefix):]
            break
    normalized = normalize_name(text)
    return _alias_reverse().get(normalized, normalized)


def _day(value: Any) -> date | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        pass
    try:
        return datetime.strptime(text[:10], "%d/%m/%Y").date()
    except ValueError:
        return None


def link_prediction_results(repo: Any) -> dict[str, int]:
    """Create links for prediction events whose result uses another UID."""
    report = {"linked": 0, "skipped": 0}
    with repo.connection() as conn:
        prediction_rows = conn.execute(
            """
            SELECT DISTINCT p.event_uid, c.participant_ids, c.start_at
            FROM predictions p
            JOIN canonical_events c ON c.event_uid = p.event_uid
            LEFT JOIN results r ON r.event_uid = p.event_uid
            WHERE r.event_uid IS NULL
            """
        ).fetchall()
        result_rows = conn.execute(
            "SELECT event_uid, participant_a, participant_b, event_date FROM results"
        ).fetchall()
        by_key: dict[tuple[tuple[str, str], date], list[str]] = {}
        for row in result_rows:
            day = _day(row["event_date"])
            if day is None:
                continue
            pair = tuple(sorted((_canonical_key(row["participant_a"]), _canonical_key(row["participant_b"]))))
            by_key.setdefault((pair, day), []).append(str(row["event_uid"]))
        for row in prediction_rows:
            try:
                participants = json.loads(row["participant_ids"])
            except (TypeError, ValueError):
                participants = []
            day = _day(row["start_at"])
            if len(participants) != 2 or day is None:
                report["skipped"] += 1
                continue
            pair = tuple(sorted((_canonical_key(participants[0]), _canonical_key(participants[1]))))
            candidates = by_key.get((pair, day), [])
            if len(candidates) != 1:
                report["skipped"] += 1
                continue
            conn.execute(
                """
                INSERT OR REPLACE INTO prediction_result_links
                    (prediction_event_uid, result_event_uid, confidence)
                VALUES (?,?,?)
                """,
                (row["event_uid"], candidates[0], 1.0),
            )
            report["linked"] += 1
    return report
