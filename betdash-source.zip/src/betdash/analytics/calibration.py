"""Small, dependency-free calibration and market-parity helpers.

All functions accept already out-of-sample (probability, outcome) pairs.
The caller is responsible for avoiding training leakage before calling them.
"""
from __future__ import annotations

import math
from collections.abc import Iterable, Sequence

Pair = tuple[float, int]


def _clean_pairs(pairs: Iterable[Pair]) -> list[Pair]:
    out: list[Pair] = []
    for p, a in pairs:
        try:
            prob = float(p)
            actual = int(a)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(prob) or actual not in (0, 1):
            continue
        out.append((min(max(prob, 1e-6), 1.0 - 1e-6), actual))
    return out


def fit_isotonic(pairs: Iterable[Pair]) -> list[tuple[float, float, float]]:
    """Pool-adjacent-violators isotonic fit; returns (x_lo, x_hi, value) blocks."""
    data = sorted(_clean_pairs(pairs), key=lambda row: row[0])
    if not data:
        return []
    blocks: list[list[float]] = []
    for x, y in data:
        blocks.append([x, x, float(y), 1.0])
        while len(blocks) > 1:
            left, right = blocks[-2], blocks[-1]
            if left[2] / left[3] <= right[2] / right[3]:
                break
            merged = [
                left[0], right[1], left[2] + right[2], left[3] + right[3],
            ]
            blocks[-2:] = [merged]
    return [(b[0], b[1], b[2] / b[3]) for b in blocks]


def predict_isotonic(
    breakpoints: Sequence[tuple[float, float, float]], probs: Iterable[float]
) -> list[float]:
    if not breakpoints:
        return [float(p) for p in probs]
    out: list[float] = []
    for raw in probs:
        try:
            p = float(raw)
        except (TypeError, ValueError):
            p = 0.5
        chosen = breakpoints[0][2]
        for lo, hi, value in breakpoints:
            if p <= hi:
                chosen = value
                break
        else:
            chosen = breakpoints[-1][2]
        out.append(chosen)
    return out


def _scores(pairs: Sequence[Pair]) -> dict[str, float | None]:
    if not pairs:
        return {"brier": None, "log_loss": None}
    brier = sum((p - a) ** 2 for p, a in pairs) / len(pairs)
    log_loss = -sum(
        a * math.log(p) + (1 - a) * math.log(1 - p) for p, a in pairs
    ) / len(pairs)
    return {"brier": brier, "log_loss": log_loss}


def calibration_report(pairs: Iterable[Pair], bins: int = 10) -> dict[str, object]:
    data = _clean_pairs(pairs)
    scores = _scores(data)
    buckets: list[dict[str, float]] = []
    bin_count = max(1, int(bins))
    for i in range(bin_count):
        lo, hi = i / bin_count, (i + 1) / bin_count
        bucket = [
            (p, a) for p, a in data
            if (lo <= p < hi) or (i == bin_count - 1 and p <= hi)
        ]
        if not bucket:
            continue
        avg_pred = sum(p for p, _ in bucket) / len(bucket)
        avg_actual = sum(a for _, a in bucket) / len(bucket)
        buckets.append({
            "bin_lo": lo, "bin_hi": hi, "count": float(len(bucket)),
            "avg_pred": avg_pred, "avg_actual": avg_actual,
            "gap": avg_pred - avg_actual,
        })
    return {
        "n": len(data),
        "brier": scores["brier"],
        "log_loss": scores["log_loss"],
        "bins": buckets,
    }


def apply_blend(p_model: float, p_market: float, alpha: float) -> float:
    """Blend a model probability with a de-vigged market probability."""
    a = min(max(float(alpha), 0.0), 1.0)
    blended = (1.0 - a) * float(p_model) + a * float(p_market)
    return min(max(blended, 1e-6), 1.0 - 1e-6)


def fit_blend_alpha(pairs: Iterable[tuple[float, float, int]]) -> float:
    """Pick the market weight with the lowest Brier score on OOF pairs."""
    rows = list(pairs)
    if not rows:
        return 0.0
    best_alpha, best_score = 0.0, float("inf")
    for step in range(0, 11):
        alpha = step / 10.0
        score = sum(
            (apply_blend(mp, kp, alpha) - int(actual)) ** 2
            for mp, kp, actual in rows
        ) / len(rows)
        if score < best_score:
            best_alpha, best_score = alpha, score
    return best_alpha


def kelly_fraction(
    p: float, decimal_odds: float, fraction: float = 0.5, cap: float = 0.08
) -> float:
    """Fractional Kelly stake for decimal odds, floors at zero and caps risk."""
    b = float(decimal_odds) - 1.0
    prob = min(max(float(p), 0.0), 1.0)
    if b <= 0.0:
        return 0.0
    full = (b * prob - (1.0 - prob)) / b
    safe_fraction = max(0.0, float(fraction))
    stake = max(0.0, full * safe_fraction)
    return max(0.0, min(stake, max(0.0, float(cap))))


def market_comparison(rows: Iterable[tuple[float, float, int]]) -> dict[str, float | None]:
    """Compare model probabilities with devigged market probabilities."""
    model: list[Pair] = []
    market: list[Pair] = []
    for model_p, market_p, actual in rows:
        cleaned = _clean_pairs([(model_p, actual), (market_p, actual)])
        model.append(cleaned[0])
        market.append(cleaned[1])
    ms, ks = _scores(model), _scores(market)
    delta = (
        None if ms["log_loss"] is None or ks["log_loss"] is None
        else float(ms["log_loss"]) - float(ks["log_loss"])
    )
    return {
        "n": len(model),
        "log_loss_model": ms["log_loss"],
        "log_loss_market": ks["log_loss"],
        "brier_model": ms["brier"],
        "brier_market": ks["brier"],
        "delta_log_loss": delta,
    }
