"""Honest quality report for stored, settled predictions."""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

from betdash.analytics.calibration import calibration_report, market_comparison
from betdash.analytics.prediction_links import link_prediction_results
from betdash.analytics.prediction_outcomes import backfill_prediction_outcomes, prediction_outcomes


def _finite_odds(value: Any) -> float | None:
    try:
        odds = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(odds) or odds <= 1.0:
        return None
    return odds


def _market_pairs(rows: list[dict[str, Any]]) -> list[tuple[float, float, int]]:
    by_event: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        if row.get("outcome") in {"p1", "p2"}:
            by_event[str(row.get("event_uid"))][str(row["outcome"])] = row
    pairs: list[tuple[float, float, int]] = []
    for outcomes in by_event.values():
        if set(outcomes) != {"p1", "p2"}:
            continue
        odds = {side: _finite_odds(outcomes[side].get("odds_decimal")) for side in ("p1", "p2")}
        if any(value is None for value in odds.values()):
            continue
        inverse = {side: 1.0 / float(odds[side]) for side in ("p1", "p2")}
        total = inverse["p1"] + inverse["p2"]
        if total <= 0.0:
            continue
        for side in ("p1", "p2"):
            row = outcomes[side]
            try:
                actual = int(row["actual"])
            except (KeyError, TypeError, ValueError):
                continue
            if actual not in (0, 1):
                continue
            pairs.append((float(row["model_prob"]), inverse[side] / total, actual))
    return pairs


def forecast_quality_report(repo: Any) -> dict[str, Any]:
    """Link, settle, and score stored predictions without claiming OOF."""
    links = link_prediction_results(repo)
    settlement = backfill_prediction_outcomes(repo)
    rows = prediction_outcomes(repo)
    calibration = calibration_report(
        [(row["model_prob"], row["actual"]) for row in rows]
    )
    comparison = market_comparison(_market_pairs(rows))
    return {
        "links": links,
        "settlement": settlement,
        "n_settled": len(rows),
        "sample_type": "historical_settled_predictions_not_oof",
        "warning": (
            "Stored predictions are historical settled predictions, not out-of-sample; "
            "use walk-forward OOF pairs for model selection."
        ),
        "model": {
            "n": calibration["n"],
            "brier": calibration["brier"],
            "log_loss": calibration["log_loss"],
            "bins": calibration["bins"],
        },
        "market": comparison,
    }
