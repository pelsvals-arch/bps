"""Score stored predictions against settled results."""

from __future__ import annotations

import json
import math
import sqlite3
from datetime import datetime, timezone
from typing import Any

from betdash.analytics.prediction_links import _canonical_key
from betdash.tennis.score import tennis_winner_side

_PROB_EPS = 1e-12


def _norm_pid(value: str) -> str:
    return _canonical_key(value)


def _outcome(participants: list[str], result: sqlite3.Row) -> str | None:
    if not participants or not result["participant_a"]:
        return None
    canonical_pids = tuple(sorted(_norm_pid(p) for p in participants))
    raw_a = _norm_pid(str(result["participant_a"]))
    raw_b = _norm_pid(str(result["participant_b"] or ""))
    if sorted((raw_a, raw_b)) != list(canonical_pids):
        return None
    try:
        comment = str(result["comment"] or "")
    except (IndexError, KeyError):
        comment = ""
    winner_side = tennis_winner_side(str(result["score"] or ""), comment)
    if winner_side not in {"left", "right"}:
        return None
    winner_pid = raw_a if winner_side == "left" else raw_b
    return "p1" if winner_pid == canonical_pids[0] else "p2"


def _safe_prob(value: Any) -> float | None:
    try:
        p = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(p):
        return None
    return min(1.0 - _PROB_EPS, max(_PROB_EPS, p))


def backfill_prediction_outcomes(repo: Any) -> dict[str, int]:
    """Write one outcome row per settled settled-able prediction."""
    report = {"settled": 0, "skipped": 0}
    with repo.connection() as connection:
        rows = connection.execute(
            """
            SELECT p.prediction_id, p.event_uid, p.market, p.outcome, p.model_prob,
                   p.odds_decimal, p.clv, c.participant_ids,
                   r.participant_a, r.participant_b, r.score, r.league
            FROM predictions p
            JOIN canonical_events c ON c.event_uid = p.event_uid
            LEFT JOIN results r ON r.rowid = (
                SELECT MAX(r2.rowid) FROM results r2
                WHERE r2.event_uid = p.event_uid
                   OR r2.event_uid IN (
                       SELECT l.result_event_uid FROM prediction_result_links l
                       WHERE l.prediction_event_uid = p.event_uid
                   )
            )
            WHERE p.market = 'match_winner' AND p.outcome IN ('p1', 'p2')
            """
        ).fetchall()
        for row in rows:
            try:
                participants = json.loads(row["participant_ids"])
                if not isinstance(participants, list):
                    raise ValueError("participant_ids must be a list")
                winner = _outcome(participants, row)
                p = _safe_prob(row["model_prob"])
            except (TypeError, ValueError, json.JSONDecodeError):
                winner, p = None, None
            if winner is None or p is None:
                report["skipped"] += 1
                continue
            actual = 1 if row["outcome"] == winner else 0
            clv = row["clv"]
            connection.execute(
                """
                INSERT INTO prediction_outcomes (
                    prediction_id, event_uid, market, outcome, model_prob, odds_decimal,
                    actual, brier, log_loss, clv, settled_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(prediction_id) DO UPDATE SET
                    actual = excluded.actual, brier = excluded.brier,
                    log_loss = excluded.log_loss, clv = excluded.clv,
                    settled_at = excluded.settled_at
                """,
                (
                    row["prediction_id"],
                    row["event_uid"],
                    row["market"],
                    row["outcome"],
                    p,
                    row["odds_decimal"],
                    actual,
                    (p - actual) ** 2,
                    -(math.log(p) if actual else math.log(1.0 - p)),
                    clv,
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            report["settled"] += 1
    return report


def prediction_outcomes(repo: Any) -> list[dict[str, Any]]:
    with repo.connection() as connection:
        rows = connection.execute("SELECT * FROM prediction_outcomes ORDER BY event_uid, prediction_id").fetchall()
    return [dict(row) for row in rows]
