"""One-time migration helpers for the tennis-only project scope."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path
from typing import Any

from betdash.db.repository import Repository

DEPENDENT_TABLES = (
    "odds_snapshots",
    "predictions",
    "results",
    "closing_lines",
    "closing_lines_book",
    "event_aliases",
    "feature_values",
    "bets",
    "events",
)


def _quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in conn.execute(f"PRAGMA main.table_info({_quote(table)})")}


def prepare_connection(conn: sqlite3.Connection) -> None:
    """Make a live migration safe under concurrent readers/writers."""
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def _purge_predicate(conn: sqlite3.Connection, table: str) -> str | None:
    cols = _columns(conn, table)
    if table == "canonical_events":
        return "(sport IS NULL OR sport <> 'tennis')"
    parts: list[str] = []
    if "sport" in cols:
        parts.append("(sport IS NULL OR sport <> 'tennis')")
    if "event_uid" in cols:
        parts.append("event_uid IN (SELECT event_uid FROM _purge_uids)")
    return " OR ".join(parts) if parts else None


def archive_and_purge_non_tennis(
    repo: Repository, archive_path: Path
) -> dict[str, dict[str, int]]:
    """Archive non-tennis rows into ``archive_path`` and purge them from ``repo``.

    Returns a report keyed by table. ``canonical_events`` counts are keyed by
    sport; every other table uses a single ``rows`` key.
    """
    db_path = Path(repo.path)
    archive_path = Path(archive_path)
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    archive_path.unlink(missing_ok=True)

    conn = sqlite3.connect(str(db_path))
    try:
        prepare_connection(conn)
        conn.execute("ATTACH DATABASE ? AS archive", (str(archive_path),))
        tables = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM main.sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
            )
        ]
        for table in tables:
            row = conn.execute(
                "SELECT sql FROM main.sqlite_master WHERE type = 'table' AND name = ?",
                (table,),
            ).fetchone()
            if row and row[0]:
                conn.execute(f"CREATE TABLE archive.{_quote(table)} ({row[0].split('(', 1)[1] if '(' in row[0] else ''}")

        conn.execute(
            """
            CREATE TEMP TABLE _purge_uids AS
            SELECT event_uid FROM main.canonical_events
            WHERE (sport IS NULL OR sport <> 'tennis') AND event_uid IS NOT NULL
            """
        )
        for table in tables:
            if table == "canonical_events" or "event_uid" not in _columns(conn, table):
                continue
            conn.execute(
                f"""
                INSERT INTO _purge_uids(event_uid)
                SELECT DISTINCT t.event_uid FROM main.{_quote(table)} t
                WHERE t.event_uid IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1 FROM main.canonical_events e WHERE e.event_uid = t.event_uid
                  )
                  AND NOT EXISTS (
                      SELECT 1 FROM _purge_uids p WHERE p.event_uid = t.event_uid
                  )
                """
            )

        report: dict[str, dict[str, int]] = {}
        predicates: dict[str, str] = {}
        for table in tables:
            predicate = _purge_predicate(conn, table)
            if predicate is None:
                continue
            predicates[table] = predicate
            conn.execute(
                f"INSERT INTO archive.{_quote(table)} SELECT * FROM main.{_quote(table)} WHERE {predicate}"
            )
            if table == "canonical_events":
                report[table] = {
                    str(sport or ""): int(count)
                    for sport, count in conn.execute(
                        "SELECT sport, COUNT(*) FROM archive.canonical_events GROUP BY sport"
                    )
                }
            else:
                count = conn.execute(f"SELECT COUNT(*) FROM archive.{_quote(table)}").fetchone()[0]
                report[table] = {"rows": int(count)}

        for table in reversed(tables):
            predicate = predicates.get(table)
            if predicate is None:
                continue
            conn.execute(f"DELETE FROM main.{_quote(table)} WHERE {predicate}")
        conn.commit()
        conn.execute("DETACH DATABASE archive")
        conn.execute("VACUUM")
        return report
    finally:
        conn.close()


def migrate_checkpoint(path: Path) -> dict[str, int]:
    """Remove non-tennis rating keys from a trainer checkpoint in place."""
    path = Path(path)
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    removed: dict[str, int] = {}
    for section in ("elo", "glicko"):
        ratings = payload.get(section)
        if not isinstance(ratings, dict):
            continue
        before = set(ratings)
        payload[section] = {key: value for key, value in ratings.items() if key == "tennis"}
        removed[section] = len(before - set(payload[section]))
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return removed


def main(argv: list[str] | None = None) -> int:
    """CLI entry point used once against the live database."""
    from betdash.config import Settings

    parser = argparse.ArgumentParser(description="Archive and purge non-tennis data")
    parser.add_argument("--db", default=str(Settings().db_path))
    parser.add_argument("--archive", default="data/archive/non-tennis-2026-11-27.sqlite")
    parser.add_argument("--checkpoint", default="data/checkpoints/trainer_checkpoint.json")
    args = parser.parse_args(argv)
    checkpoint_path = Path(args.checkpoint)
    checkpoint_payload = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    if not isinstance(checkpoint_payload, dict):
        raise ValueError(f"Checkpoint must contain a JSON object: {checkpoint_path}")
    report = archive_and_purge_non_tennis(Repository(args.db), Path(args.archive))
    report["checkpoint"] = migrate_checkpoint(checkpoint_path)
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
