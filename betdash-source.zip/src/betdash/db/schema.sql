-- SQLite schema for the local betting-research dashboard.
-- odds_snapshots is append-only: rows are never updated or deleted.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS events (
    event_uid TEXT PRIMARY KEY,
    sport TEXT NOT NULL,
    league TEXT NOT NULL,
    participant_ids TEXT,
    start_at TEXT,
    market_close_at TEXT,
    mapping_confidence REAL NOT NULL DEFAULT 0.0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS canonical_events (
    event_uid TEXT PRIMARY KEY,
    sport TEXT NOT NULL,
    league TEXT NOT NULL,
    participant_ids TEXT NOT NULL, -- JSON array of strings
    start_at TEXT NOT NULL,
    mapping_confidence REAL NOT NULL,
    market_close_at TEXT
);

CREATE TABLE IF NOT EXISTS participants (
    participant_id TEXT PRIMARY KEY,
    sport TEXT NOT NULL,
    display_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_aliases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_uid TEXT NOT NULL,
    bookmaker TEXT NOT NULL,
    source_event_id TEXT NOT NULL,
    UNIQUE (bookmaker, source_event_id)
);

CREATE TABLE IF NOT EXISTS market_types (
    market TEXT PRIMARY KEY,
    sport TEXT,
    description TEXT,
    outcomes TEXT
);

CREATE TABLE IF NOT EXISTS odds_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_uid TEXT NOT NULL,
    bookmaker TEXT NOT NULL,
    market TEXT NOT NULL,
    outcome TEXT NOT NULL,
    line REAL,
    odds_decimal REAL NOT NULL,
    observed_at TEXT NOT NULL,
    source_event_id TEXT,
    source_url TEXT,
    adapter_version TEXT NOT NULL,
    is_live INTEGER NOT NULL DEFAULT 0 CHECK (is_live IN (0, 1)),
    line_key REAL NOT NULL DEFAULT -1e308,
    UNIQUE (event_uid, bookmaker, market, outcome, line_key, observed_at, adapter_version)
);

CREATE INDEX IF NOT EXISTS idx_odds_snapshots_event_observed
    ON odds_snapshots (event_uid, observed_at);

CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_uid TEXT NOT NULL,
    participant_a TEXT,
    participant_b TEXT,
    score TEXT,
    league TEXT,
    event_date TEXT,
    source TEXT,
    comment TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (event_uid, source)
);

CREATE TABLE IF NOT EXISTS feature_values (
    event_uid TEXT NOT NULL,
    feature TEXT NOT NULL,
    value REAL NOT NULL,
    source TEXT NOT NULL,
    as_of TEXT NOT NULL,
    transform_version TEXT NOT NULL,
    PRIMARY KEY (event_uid, feature, as_of, transform_version)
);

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prediction_id TEXT UNIQUE,
    model_run_id TEXT,
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    outcome TEXT NOT NULL,
    line REAL,
    model_prob REAL NOT NULL,
    odds_decimal REAL,
    bookmaker TEXT,
    observed_at TEXT NOT NULL,
    decision_observed_at TEXT,
    event_start_at TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    closing_odds REAL,
    clv REAL,
    actual_outcome INTEGER,
    settled_at TEXT
);

CREATE TABLE IF NOT EXISTS prediction_outcomes (
    prediction_id TEXT PRIMARY KEY,
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    outcome TEXT NOT NULL,
    model_prob REAL NOT NULL,
    odds_decimal REAL,
    actual INTEGER NOT NULL,
    brier REAL NOT NULL,
    log_loss REAL NOT NULL,
    clv REAL,
    settled_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_prediction_outcomes_event ON prediction_outcomes(event_uid);

CREATE TABLE IF NOT EXISTS prediction_result_links (
    prediction_event_uid TEXT NOT NULL,
    result_event_uid TEXT NOT NULL,
    confidence REAL NOT NULL,
    PRIMARY KEY (prediction_event_uid, result_event_uid)
);

CREATE TABLE IF NOT EXISTS score_distributions (
    event_uid TEXT NOT NULL,
    model_run_id TEXT NOT NULL,
    provider TEXT NOT NULL CHECK (provider IN ('empirical', 'markov', 'blend')),
    observed_at TEXT NOT NULL,
    distribution_json TEXT NOT NULL,
    p1_prob REAL NOT NULL,
    blend_weight REAL NOT NULL DEFAULT 0.5,
    PRIMARY KEY (event_uid, model_run_id, provider)
);

CREATE INDEX IF NOT EXISTS idx_score_distributions_event ON score_distributions(event_uid);

CREATE TABLE IF NOT EXISTS model_runs (
    run_id TEXT PRIMARY KEY,
    features_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    metrics_json TEXT
);

CREATE TABLE IF NOT EXISTS adapter_health (
    bookmaker TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    last_success TEXT,
    error_count INTEGER NOT NULL DEFAULT 0,
    adapter_version TEXT NOT NULL,
    last_error TEXT,
    rows_last_poll INTEGER,
    payload_hash TEXT,
    freshness_sec REAL
);

-- Closing lines: last pre-start odds snapshot per (event, market, outcome)
CREATE TABLE IF NOT EXISTS closing_lines (
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    line REAL,
    outcome TEXT NOT NULL,
    odds_closing REAL NOT NULL,
    bookmaker TEXT,
    captured_at TEXT NOT NULL,
    PRIMARY KEY (event_uid, market, line, outcome)
);
CREATE INDEX IF NOT EXISTS idx_closing_event ON closing_lines(event_uid);

-- Per-bookmaker closing lines. CLV must compare the same book's decision and
-- closing price; a cross-book max is not comparable when books list the
-- participants in different p1/p2 order.
CREATE TABLE IF NOT EXISTS closing_lines_book (
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    line REAL,
    outcome TEXT NOT NULL,
    bookmaker TEXT NOT NULL,
    odds_closing REAL NOT NULL,
    captured_at TEXT NOT NULL,
    PRIMARY KEY (event_uid, market, line, outcome, bookmaker)
);
CREATE INDEX IF NOT EXISTS idx_closing_book_event ON closing_lines_book(event_uid);

-- Personal bet journal
CREATE TABLE IF NOT EXISTS bets (
    bet_id TEXT PRIMARY KEY,
    prediction_id TEXT NOT NULL,
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    line REAL,
    outcome TEXT NOT NULL,
    stake REAL NOT NULL,
    odds_taken REAL NOT NULL,
    bookmaker TEXT,
    placed_at TEXT NOT NULL,
    settled_at TEXT,
    result INTEGER,
    pnl REAL,
    bankroll_before REAL,
    bankroll_after REAL,
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_bets_event ON bets(event_uid);
CREATE INDEX IF NOT EXISTS idx_bets_pending ON bets(settled_at) WHERE settled_at IS NULL;

CREATE TABLE IF NOT EXISTS bankroll (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    amount REAL NOT NULL,
    updated_at TEXT NOT NULL
);
INSERT OR IGNORE INTO bankroll(id, amount, updated_at) VALUES (1, 0, strftime('%Y-%m-%dT%H:%M:%fZ','now'));

CREATE TABLE IF NOT EXISTS tournaments (
    tournament_key TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    tour TEXT,
    surface TEXT,
    court_pace_index REAL,
    altitude_m REAL,
    ball_brand TEXT,
    ball_speed_factor REAL,
    ball_softness REAL,
    notes TEXT,
    updated_at TEXT NOT NULL
);
