"""Resilient polling collector for bookmaker adapters."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from threading import Lock
from typing import Any

from apscheduler.schedulers.background import BackgroundScheduler

from betdash.config import Settings
from betdash.db.repository import AdapterHealth, Repository, Snapshot
from betdash.normalize import MVP_SPORTS, EntityRegistry, canon_market, canon_sport, canonical_outcome, normalize_event
from betdash.normalize.models import RawOdd


class Collector:
    """Poll adapters, normalize quotes, and persist immutable snapshots."""

    def __init__(
        self,
        settings: Settings,
        repository: Repository,
        adapters: list[Any],
        registry: EntityRegistry,
    ) -> None:
        self.settings = settings
        self.repository = repository
        self.adapters = adapters
        self.registry = registry
        self._scheduler: BackgroundScheduler | None = None
        self._lock = Lock()
        self._error_counts: dict[str, int] = {}
        self._last_success: dict[str, datetime | None] = {}
        self._adapter_versions: dict[str, str] = {}
        self._seed_health_from_repository()

    def poll_once(self) -> int:
        """Poll all adapters once. Never raises to caller."""
        with self._lock:
            return self._poll_once_locked()

    def _seed_health_from_repository(self) -> None:
        try:
            rows = self.repository.list_adapter_health() if hasattr(self.repository, "list_adapter_health") else self.repository.adapter_health()
        except Exception:
            return
        if not rows:
            return
        for row in rows:
            self._error_counts[row.bookmaker] = row.error_count
            self._last_success[row.bookmaker] = row.last_success
            self._adapter_versions[row.bookmaker] = row.adapter_version

    def _ensure_bookmaker_state(self, adapter: Any, bookmaker: str) -> None:
        if bookmaker in self._error_counts:
            return
        try:
            rows = self.repository.list_adapter_health() if hasattr(self.repository, "list_adapter_health") else self.repository.adapter_health()
        except Exception:
            rows = []
        for row in rows or []:
            if row.bookmaker != bookmaker:
                continue
            self._error_counts[bookmaker] = row.error_count
            self._last_success[bookmaker] = row.last_success
            self._adapter_versions[bookmaker] = row.adapter_version
            return
        self._error_counts.setdefault(bookmaker, 0)
        self._last_success.setdefault(bookmaker, None)
        try:
            self._adapter_versions.setdefault(bookmaker, self._adapter_version(adapter))
        except Exception:
            self._adapter_versions.setdefault(bookmaker, "unknown")

    def _poll_once_locked(self) -> int:
        for adapter in self.adapters:
            self._ensure_bookmaker_state(adapter, self._bookmaker(adapter))

        snapshots: list[Snapshot] = []
        events: dict[str, Any] = {}
        ready: list[tuple[Any, str, int, str, set[str]]] = []

        for adapter, bookmaker, raw_odds, fetch_error in self._fetch_all_adapters():
            if fetch_error is not None:
                self._mark_degraded(adapter, bookmaker, last_error=fetch_error, rows_last_poll=0)
                continue

            if not raw_odds:
                self._mark_degraded(adapter, bookmaker, last_error="empty_snapshot", rows_last_poll=0)
                continue

            payload_hash = str(abs(hash(tuple((getattr(r,'event_uid',getattr(r,'source_event_id','')),getattr(r,'market',''),getattr(r,'outcome',''),getattr(r,'line',None),getattr(r,'odds_decimal',None)) for r in raw_odds[:500]))))
            try:
                normalized, canonicals, had_persistable = self._normalize_fetched(adapter, raw_odds)
            except Exception as exc:
                self._mark_degraded(adapter, bookmaker, last_error=f"ingest:{type(exc).__name__}", rows_last_poll=len(raw_odds), payload_hash=payload_hash)
                continue

            if not had_persistable:
                self._mark_degraded(adapter, bookmaker, last_error="no_persistable_rows", rows_last_poll=len(raw_odds), payload_hash=payload_hash)
                continue

            snapshots.extend(normalized)
            events.update(canonicals)
            contributed = {str(snapshot.event_uid) for snapshot in normalized}
            ready.append((adapter, bookmaker, len(raw_odds), payload_hash, contributed))

        if not snapshots:
            return 0
        failed_events: dict[str, str] = {}
        for uid, canonical in events.items():
            try:
                self.repository.upsert_canonical_event(canonical)
            except Exception as exc:
                failed_events[uid] = f"persist:{type(exc).__name__}"

        try:
            saved = self.repository.save_snapshots(self._dedupe_snapshots(snapshots))
        except Exception as exc:
            for adapter, bookmaker, rows, payload_hash, _ in ready:
                self._mark_degraded(adapter, bookmaker, last_error=f"persist:{type(exc).__name__}", rows_last_poll=rows, payload_hash=payload_hash)
            return 0

        for adapter, bookmaker, rows, payload_hash, contributed in ready:
            failure = next((failed_events[uid] for uid in contributed if uid in failed_events), None)
            if failure is not None:
                self._mark_degraded(adapter, bookmaker, last_error=failure, rows_last_poll=rows, payload_hash=payload_hash)
            else:
                self._mark_ok(adapter, bookmaker, rows_last_poll=rows, payload_hash=payload_hash)
        return saved

    def _fetch_all_adapters(self) -> list[tuple[Any, str, list[RawOdd] | None, str | None]]:
        """Fetch all adapters concurrently, preserving submission order."""
        if not self.adapters:
            return []

        def fetch(adapter: Any) -> tuple[Any, str, list[RawOdd] | None, str | None]:
            bookmaker = self._bookmaker(adapter)
            try:
                return adapter, bookmaker, list(adapter.fetch_snapshot() or []), None
            except Exception as exc:
                return adapter, bookmaker, None, f"{type(exc).__name__}: {exc}"

        with ThreadPoolExecutor(max_workers=min(4, len(self.adapters))) as pool:
            futures = [pool.submit(fetch, adapter) for adapter in self.adapters]
            return [future.result() for future in futures]

    def _normalize_fetched(
        self, adapter: Any, raw_odds: list[RawOdd]
    ) -> tuple[list[Snapshot], dict[str, Any], bool]:
        snapshots: list[Snapshot] = []
        events: dict[str, Any] = {}
        had_persistable = False
        for raw in raw_odds:
            try:
                if raw.is_live:
                    continue
                sport = canon_sport(raw.sport)
                market = canon_market(raw.market, raw.bookmaker)
                if sport not in MVP_SPORTS:
                    continue
                if market.startswith("unknown_") and len(tuple(getattr(raw, "participants", ()) or ())) < 2:
                    # Stat/prop noise often has no two-sided event identity.
                    continue
                canonical = normalize_event(raw, self.registry)
                if canonical.mapping_confidence < 0.5:
                    continue
                snapshot = Snapshot(
                    event_uid=canonical.event_uid,
                    bookmaker=raw.bookmaker,
                    market=market,
                    outcome=canonical_outcome(raw, canonical),
                    line=getattr(raw, "line", None),
                    odds_decimal=raw.odds_decimal,
                    observed_at=raw.observed_at,
                    source_event_id=raw.source_event_id,
                    adapter_version=self._adapter_version(adapter),
                    is_live=raw.is_live,
                    source_url=getattr(raw, "source_url", None),
                )
                snapshots.append(snapshot)
                events[canonical.event_uid] = canonical
                had_persistable = True
            except Exception:
                continue
        return snapshots, events, had_persistable

    @staticmethod
    def _dedupe_snapshots(snapshots: list[Snapshot]) -> list[Snapshot]:
        def key(snapshot: Snapshot) -> tuple[str, ...]:
            return (
                str(snapshot.event_uid),
                str(snapshot.bookmaker),
                str(snapshot.market),
                str(snapshot.outcome),
                str(snapshot.line),
                str(snapshot.observed_at),
                str(snapshot.source_event_id),
                str(snapshot.adapter_version),
            )

        seen: set[tuple[str, ...]] = set()
        result: list[Snapshot] = []
        for snapshot in sorted(snapshots, key=key):
            identity = key(snapshot)
            if identity in seen:
                continue
            seen.add(identity)
            result.append(snapshot)
        return result

    def start(self) -> None:
        """Register periodic polling using Settings.poll_seconds."""
        with self._lock:
            if self._scheduler is not None:
                return
            scheduler = BackgroundScheduler()
            scheduler.add_job(
                self.poll_once,
                "interval",
                seconds=self.settings.poll_seconds,
                max_instances=1,
                coalesce=True,
            )
            scheduler.start()
            self._scheduler = scheduler

    def stop(self) -> None:
        """Shut scheduler down cleanly."""
        with self._lock:
            scheduler = self._scheduler
            self._scheduler = None
        if scheduler is not None:
            scheduler.shutdown(wait=False)

    def health(self) -> list[AdapterHealth]:
        """Return current adapter health known to collector/repository."""
        if hasattr(self.repository, "list_adapter_health"):
            return self.repository.list_adapter_health()
        return self.repository.adapter_health()

    def _mark_ok(self, adapter: Any, bookmaker: str, *, rows_last_poll: int | None = None, payload_hash: str | None = None) -> None:
        now = datetime.now(timezone.utc)
        self._error_counts[bookmaker] = 0
        self._last_success[bookmaker] = now
        version = self._adapter_version(adapter)
        self._adapter_versions[bookmaker] = version
        freshness = (datetime.now(timezone.utc) - now).total_seconds()
        self._upsert_health(bookmaker, "ok", now, 0, version, last_error=None, rows_last_poll=rows_last_poll, payload_hash=payload_hash, freshness_sec=freshness)

    def _mark_degraded(self, adapter: Any, bookmaker: str, *, last_error: str | None = None, rows_last_poll: int | None = None, payload_hash: str | None = None) -> None:
        self._error_counts[bookmaker] = self._error_counts.get(bookmaker, 0) + 1
        version = self._adapter_version(adapter)
        self._adapter_versions[bookmaker] = version
        last_success = self._last_success.get(bookmaker)
        try:
            adapter_health = adapter.health()
            if last_success is None:
                last_success = adapter_health.last_success
        except Exception:
            pass
        self._last_success[bookmaker] = last_success
        freshness = None
        if last_success is not None:
            freshness = max(0.0, (datetime.now(timezone.utc) - last_success).total_seconds())
        self._upsert_health(
            bookmaker,
            "degraded",
            last_success,
            self._error_counts[bookmaker],
            version,
            last_error=last_error,
            rows_last_poll=rows_last_poll,
            payload_hash=payload_hash,
            freshness_sec=freshness,
        )

    def _upsert_health(
        self,
        bookmaker: str,
        status: str,
        last_success: datetime | None,
        error_count: int,
        adapter_version: str,
        *,
        last_error: str | None = None,
        rows_last_poll: int | None = None,
        payload_hash: str | None = None,
        freshness_sec: float | None = None,
    ) -> None:
        health = AdapterHealth(
            bookmaker=bookmaker,
            status=status,
            last_success=last_success,
            error_count=error_count,
            adapter_version=adapter_version,
            last_error=last_error,
            rows_last_poll=rows_last_poll,
            payload_hash=payload_hash,
            freshness_sec=freshness_sec,
        )
        # Support brief interface and existing repository.
        if hasattr(self.repository, "adapter_health_upsert"):
            self.repository.adapter_health_upsert(health)
            return
        if hasattr(self.repository, "upsert_adapter_health"):
            self.repository.upsert_adapter_health(health)
            return
        # brief-named method form
        if callable(getattr(self.repository, "adapter_health", None)):
            try:
                # Try brief signature: adapter_health(bookmaker, status, last_success, error_count, adapter_version)
                self.repository.adapter_health(bookmaker, status, last_success, error_count, adapter_version)  # type: ignore[misc]
                return
            except TypeError:
                pass
        self.repository.upsert_adapter_health(health)

    def _bookmaker(self, adapter: Any) -> str:
        try:
            health = adapter.health()
            if health.bookmaker:
                return health.bookmaker
        except Exception:
            pass
        return str(getattr(adapter, "bookmaker", "unknown"))

    def _adapter_version(self, adapter: Any) -> str:
        try:
            version = adapter.health().adapter_version
            if version:
                return version
        except Exception:
            pass
        return str(getattr(adapter, "adapter_version", "unknown"))
