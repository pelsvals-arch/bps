"""Resumable incremental trainer for baseline models."""
from __future__ import annotations

import copy
import json
import logging
import math
import os
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence
from uuid import uuid4

from apscheduler.schedulers.background import BackgroundScheduler

from betdash.analytics.calibration import (
    apply_blend,
    calibration_report,
    fit_blend_alpha,
    fit_isotonic,
    kelly_fraction,
    market_comparison,
    predict_isotonic,
)
from betdash.config import Settings
from betdash.db.repository import Repository, Snapshot
from betdash.markets.consensus import consensus_prob
from betdash.models.baseline import EloRating, GlickoRating, _welo_weight, score_margin
from betdash.models.features import build_features
from betdash.tennis.blend import blend_score_distributions, fit_blend_weight_from_repository
from betdash.tennis.empirical_provider import empirical_provider_distribution
from betdash.tennis.markov import markov_score_distribution
from betdash.tennis.markets import canonical_tennis_market
from betdash.tennis.score import tennis_winner_side

if TYPE_CHECKING:
    from betdash.normalize.models import CanonicalEvent

logger = logging.getLogger(__name__)

FEATURES_VERSION = "baseline-v1"
TENNIS_ONLY_SPORT = "tennis"
ELO_PER_RANK_UNIT = 15.0


def _numeric_features(features: Mapping[str, Any]) -> dict[str, float]:
    """Keep only model-usable numeric features; context strings stay out."""
    out: dict[str, float] = {}
    for key, value in features.items():
        if isinstance(value, bool):
            continue
        try:
            out[key] = float(value)
        except (TypeError, ValueError):
            continue
    return out
MARKET_PRIOR_MAX_AGE_HOURS = 6
MIN_EDGE_FOR_STAKE = 0.015
TENNIS_MARKETS = frozenset({
    "match_winner", "total_points", "total_games", "spread",
    "game_handicap", "set_handicap",
})


def barnett_clarke_hold_rates(features: dict[str, Any]) -> tuple[float, float]:
    """Convert serve and return rates into per-server hold rates."""
    p1_serve = float(features.get("p1_srv_win", 0.62))
    p2_serve = float(features.get("p2_srv_win", 0.62))
    p1_return = float(features.get("p1_ret_win", 0.38))
    p2_return = float(features.get("p2_ret_win", 0.38))
    p1_hold = (p1_serve + (1.0 - p2_return)) / 2.0
    p2_hold = (p2_serve + (1.0 - p1_return)) / 2.0
    return (
        min(0.99, max(0.01, p1_hold)),
        min(0.99, max(0.01, p2_hold)),
    )

# Score predictions in batches to avoid refitting the model on every row.
# With test_window=1 the trainer does O(n) model fits per step, which is
# impractical for large histories (especially with CatBoost).
DEFAULT_TEST_WINDOW = 25


def build_score_distribution_rows(
    event: CanonicalEvent,
    repo: Repository,
    p1_prob: float,
    model_run_id: str,
    observed_at: datetime,
    blend_weight: float | None = None,
    cached_results: Any | None = None,
) -> list[dict[str, Any]]:
    """Build empirical, Markov and blended score distributions for an event."""
    features = build_features(
        event,
        repo,
        as_of=observed_at,
        cached_results=cached_results,
    )
    p1, p2 = event.participant_ids[0], event.participant_ids[1]
    try:
        best_of = int(features.get("best_of") or 3)
    except (TypeError, ValueError):
        best_of = 3
    if best_of not in (3, 5):
        best_of = 3
    target = {
        "surface": str(features.get("surface_name") or ""),
        "best_of": best_of,
        "tourney_level": "",
        "round": "",
        "elo_gap": (
            float(features.get("p1_elo_blend", 1500.0))
            - float(features.get("p2_elo_blend", 1500.0))
        ) / ELO_PER_RANK_UNIT,
        "observed_at": str(event.start_at),
    }
    empirical = empirical_provider_distribution(repo, p1, p2, target)

    p1_hold, p2_hold = barnett_clarke_hold_rates(features)
    markov = markov_score_distribution(p1_hold, p2_hold, best_of=best_of)
    weight = 0.5 if blend_weight is None else min(1.0, max(0.0, float(blend_weight)))
    blended = blend_score_distributions(empirical, markov, weight)
    rows = []
    for provider, distribution in (
        ("empirical", empirical),
        ("markov", markov),
        ("blend", blended),
    ):
        rows.append(
            {
                "event_uid": event.event_uid,
                "model_run_id": model_run_id,
                "provider": provider,
                "observed_at": observed_at,
                "distribution": distribution,
                "p1_prob": float(p1_prob),
                "blend_weight": weight,
            }
        )
    return rows


@dataclass(frozen=True, slots=True)
class ModelRun:
    run_id: str
    features_version: str
    created_at: str


def _to_dt(value: str | datetime | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class Trainer:
    """Incremental walk-forward trainer with atomic checkpoint resume."""

    def __init__(self, repo: Repository, settings: Settings):
        self.repo = repo
        self.settings = settings
        self.checkpoint_dir = Path(settings.checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path = self.checkpoint_dir / "trainer_checkpoint.json"
        self._lock = threading.Lock()
        self._scheduler: BackgroundScheduler | None = None
        self._elo: dict[str, EloRating] = {}
        self._glicko: dict[str, GlickoRating] = {}
        self._model: Any | None = None
        self._state: dict[str, Any] = {
            "last_run_id": None,
            "features_version": FEATURES_VERSION,
            "last_snapshot_id": 0,
            "last_result_id": 0,
            "runs": 0,
            "processed_event_uids": [],
            "processed_count": 0,
            "processed_rows": [],
        }
        self._load_checkpoint()

    @property
    def last_run_id(self) -> str | None:
        value = self._state.get("last_run_id")
        return str(value) if value else None

    def _load_checkpoint(self) -> None:
        if not self.checkpoint_path.exists():
            return
        try:
            data = json.loads(self.checkpoint_path.read_text(encoding="utf-8"))
        except Exception:
            logger.warning(
                "Failed to read trainer checkpoint %s; starting fresh",
                self.checkpoint_path,
                exc_info=True,
            )
            return
        if not isinstance(data, dict):
            logger.warning("Trainer checkpoint is not a dict; starting fresh")
            return

        stored_version = data.get("features_version")
        if stored_version != FEATURES_VERSION:
            logger.warning(
                "Checkpoint features_version=%r != current %r; "
                "ratings and history will be reset",
                stored_version,
                FEATURES_VERSION,
            )
            data = {}

        self._state.update(data)
        self._state.setdefault("processed_event_uids", [])
        self._state.setdefault("processed_count", 0)
        self._state.setdefault("processed_rows", [])
        self._state["features_version"] = FEATURES_VERSION

        try:
            self._restore_ratings()
        except Exception:
            logger.exception(
                "Failed to restore ratings from checkpoint; resetting ratings"
            )
            self._elo = {}
            self._glicko = {}

    def _restore_ratings(self) -> None:
        elo_state = self._state.get("elo") or {}
        glicko_state = self._state.get("glicko") or {}
        self._elo = {}
        self._glicko = {}
        if isinstance(elo_state, dict):
            ratings = elo_state.get(TENNIS_ONLY_SPORT)
            if isinstance(ratings, dict):
                er = EloRating()
                er.ratings = {str(k): float(v) for k, v in ratings.items()}
                self._elo[TENNIS_ONLY_SPORT] = er
        if isinstance(glicko_state, dict):
            ratings = glicko_state.get(TENNIS_ONLY_SPORT)
            gr = GlickoRating()
            if isinstance(ratings, dict):
                for player, st in ratings.items():
                    if isinstance(st, dict):
                        gs = gr.get(str(player))
                        gs.rating = float(st.get("rating", gs.rating))
                        gs.rd = float(st.get("rd", gs.rd))
                self._glicko[TENNIS_ONLY_SPORT] = gr

    def _serialize_ratings(
        self,
        elo: dict[str, EloRating] | None = None,
        glicko: dict[str, GlickoRating] | None = None,
    ) -> None:
        elo = self._elo if elo is None else elo
        glicko = self._glicko if glicko is None else glicko
        tennis_elo = elo.get(TENNIS_ONLY_SPORT)
        tennis_glicko = glicko.get(TENNIS_ONLY_SPORT)
        self._state["elo"] = (
            {TENNIS_ONLY_SPORT: {k: float(v) for k, v in tennis_elo.ratings.items()}}
            if tennis_elo is not None else {}
        )
        self._state["glicko"] = (
            {
                TENNIS_ONLY_SPORT: {
                    k: {"rating": float(s.rating), "rd": float(s.rd)}
                    for k, s in tennis_glicko.ratings.items()
                }
            }
            if tennis_glicko is not None else {}
        )

    def _atomic_write_checkpoint(self) -> None:
        self._serialize_ratings()
        payload = json.dumps(self._state, ensure_ascii=False, sort_keys=True)
        tmp_path = self.checkpoint_path.with_name(self.checkpoint_path.name + ".tmp")
        with tmp_path.open("w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, self.checkpoint_path)

    def _watermarks(self) -> tuple[int, int]:
        with self.repo.connection() as conn:
            snap = conn.execute(
                "SELECT COALESCE(MAX(id), 0) AS m FROM odds_snapshots"
            ).fetchone()
            res = conn.execute(
                "SELECT COALESCE(MAX(id), 0) AS m FROM results"
            ).fetchone()
        return int(snap["m"] if snap else 0), int(res["m"] if res else 0)

    @staticmethod
    def _norm_pid(value: str) -> str:
        from betdash.normalize.registry import normalize_name
        text = str(value or "")
        for prefix in ("name:", "unresolved:", "ambiguous:", "resolved:"):
            if text.startswith(prefix):
                text = text[len(prefix):]
                break
        return normalize_name(text)

    @staticmethod
    def _actual_for_event(event: Any, result: dict[str, Any]) -> int | None:
        parts = tuple(str(p) for p in (getattr(event, "participant_ids", None) or ()))
        if len(parts) != 2:
            return None
        p1, p2 = parts
        pa = str(result.get("participant_a") or "")
        pb = str(result.get("participant_b") or "")
        score = str(result.get("score") or "")
        side = tennis_winner_side(str(score or ""))
        if side is None:
            # Draws, empty or unparseable scores cannot produce a 0/1
            # label. Previously these were silently mapped to "p1 wins",
            # which trained the model on bogus targets.
            return None
        n1, n2, na, nb = (
            Trainer._norm_pid(p1),
            Trainer._norm_pid(p2),
            Trainer._norm_pid(pa),
            Trainer._norm_pid(pb),
        )
        if not all([n1, n2, na, nb]):
            return None
        if na == n1 and nb == n2:
            ordered = ("p1", "p2")
        elif na == n2 and nb == n1:
            ordered = ("p2", "p1")
        else:
            return None
        winner = ordered[0] if side == "left" else ordered[1]
        return 1 if winner == "p1" else 0

    def _event_decision_time(self, event_uid: str, start_at: datetime) -> datetime | None:
        with self.repo.connection() as conn:
            rows = conn.execute(
                """
                SELECT observed_at, is_live
                FROM odds_snapshots
                WHERE event_uid = ?
                ORDER BY observed_at, id
                """,
                (event_uid,),
            ).fetchall()
        times: list[datetime] = []
        for row in rows:
            if bool(row["is_live"]):
                continue
            dt = _to_dt(row["observed_at"])
            if dt is None or dt >= start_at:
                continue
            times.append(dt)
        if not times:
            return None
        return max(times)

    @staticmethod
    def _market_p1_from_snapshots(
        snapshots: list[Snapshot], start_at: datetime
    ) -> tuple[float, int]:
        """De-vigged p1 prior from fresh, non-live, single-book pairs.

        Coverage is the number of qualifying bookmakers. Below two books the
        market prior is unusable and the model must stand on its own.
        """
        fresh: list[Snapshot] = []
        for snap in snapshots:
            if bool(getattr(snap, "is_live", False)):
                continue
            observed = _to_dt(getattr(snap, "observed_at", None))
            if observed is None or observed >= start_at:
                continue
            if (start_at - observed).total_seconds() > MARKET_PRIOR_MAX_AGE_HOURS * 3600:
                continue
            fresh.append(snap)
        prob, coverage = consensus_prob(fresh, "p1")
        if coverage < 2:
            return 0.0, coverage
        return min(max(float(prob), 1e-6), 1 - 1e-6), coverage

    def _collect_new_rows(
        self,
        elo: dict[str, EloRating],
        glicko: dict[str, GlickoRating],
        processed_uids: set[str],
    ) -> list[dict[str, Any]]:
        events = self.repo.events_for_resolution()
        results_dict = {str(row["event_uid"]): row for row in self.repo.results()}
        all_results = list(results_dict.values())

        candidates: list[
            tuple[datetime, str, Any, dict[str, Any], datetime, int]
        ] = []
        for event in events:
            if event.event_uid in processed_uids:
                continue
            result = results_dict.get(event.event_uid)
            if result is None:
                continue
            actual = self._actual_for_event(event, result)
            if actual is None:
                continue
            start_at = _to_dt(event.start_at)
            if start_at is None:
                continue
            observed_at = self._event_decision_time(event.event_uid, start_at)
            if observed_at is None:
                from datetime import timedelta
                observed_at = start_at - timedelta(minutes=1)
            candidates.append(
                (start_at, event.event_uid, event, result, observed_at, int(actual))
            )

        candidates.sort(key=lambda x: (x[0], x[1]))
        new_rows: list[dict[str, Any]] = []
        for start_at, _uid, event, result, observed_at, actual in candidates:
            if str(event.sport) != TENNIS_ONLY_SPORT:
                continue
            sport = TENNIS_ONLY_SPORT
            p1 = event.participant_ids[0] if len(event.participant_ids) > 0 else ""
            p2 = event.participant_ids[1] if len(event.participant_ids) > 1 else ""

            er = elo.setdefault(sport, EloRating())
            gr = glicko.setdefault(sport, GlickoRating())

            features = build_features(
                event, self.repo, as_of=observed_at, cached_results=all_results
            )
            features["elo_p1"] = float(er.probability(p1, p2)) if p1 and p2 else 0.5
            features["glicko_p1"] = float(gr.probability(p1, p2)) if p1 and p2 else 0.5

            winner_snaps = [
                s for s in self.repo.last_snapshots(event.event_uid)
                if str(getattr(s, "market", "")) == "match_winner"
            ]
            market_p1, market_coverage = self._market_p1_from_snapshots(winner_snaps, start_at)
            offered_odds = max(
                (
                    float(s.odds_decimal)
                    for s in winner_snaps
                    if str(getattr(s, "outcome", "")) == "p1"
                    and not bool(getattr(s, "is_live", False))
                    and (dt := _to_dt(getattr(s, "observed_at", None))) is not None
                    and dt < start_at
                    and (start_at - dt).total_seconds() <= MARKET_PRIOR_MAX_AGE_HOURS * 3600
                ),
                default=None,
            )

            new_rows.append(
                {
                    "event_uid": event.event_uid,
                    "sport": sport,
                    "observed_at": observed_at,
                    "event_start_at": start_at,
                    "features": features,
                    "actual": int(actual),
                    "p1": p1,
                    "p2": p2,
                    "market_p1": market_p1,
                    "market_coverage": market_coverage,
                    "offered_odds": offered_odds,
                }
            )
            if p1 and p2:
                weight = _welo_weight(score_margin(str(result.get("score") or "")))
                er.update(p1, p2, float(actual), weight=weight)
                gr.update(p1, p2, float(actual))
        return new_rows

    def _fit_model(self, rows: list[dict[str, Any]]) -> Any:
        if not rows:
            return None
        numeric = [_numeric_features(r["features"]) for r in rows]
        feature_names = sorted({k for row in numeric for k in row})
        X = [[row.get(k, 0.0) for k in feature_names] for row in numeric]
        y = [int(r["actual"]) for r in rows]
        if self.settings.enable_catboost:
            try:
                from catboost import CatBoostClassifier
                if len(set(y)) >= 2:
                    model = CatBoostClassifier(
                        iterations=50,
                        depth=4,
                        learning_rate=0.1,
                        verbose=False,
                        allow_writing_files=False,
                    )
                    model.fit(X, y)
                    return {"type": "catboost", "model": model, "features": feature_names}
            except Exception:
                logger.exception("CatBoost training failed; falling back to logreg")
        try:
            from sklearn.linear_model import LogisticRegression
        except Exception:
            return None
        if len(set(y)) < 2:
            return {"type": "constant", "p": sum(y) / len(y), "features": feature_names}
        model = LogisticRegression(max_iter=500)
        model.fit(X, y)
        return {"type": "logreg", "model": model, "features": feature_names}

    @staticmethod
    def _predict_with_model(model: Any, features: dict[str, float]) -> float:
        if not model:
            return 0.5
        if isinstance(model, dict) and model.get("type") == "constant":
            return float(model.get("p", 0.5))
        if isinstance(model, dict) and model.get("type") in {"logreg", "catboost"}:
            names = model["features"]
            clf = model["model"]
            numeric = _numeric_features(features)
            X = [[numeric.get(k, 0.0) for k in names]]
            try:
                prob = float(clf.predict_proba(X)[0][1])
            except Exception:
                prob = 0.5
            return min(max(prob, 1e-6), 1 - 1e-6)
        return 0.5

    @staticmethod
    def _implied_probs_from_outcomes(
        outcomes: dict[str, tuple[float, str | None]]
    ) -> dict[str, float]:
        inv: dict[str, float] = {}
        for k, v in outcomes.items():
            try:
                odds = float(v[0])
            except Exception:
                continue
            if odds > 1.01 and math.isfinite(odds):
                inv[k] = 1.0 / odds
        total = sum(inv.values())
        if total <= 0:
            return {}
        return {k: v / total for k, v in inv.items()}

    def _market_probs(
        self,
        market: str,
        line: float | None,
        outcomes: dict[str, tuple[float, str | None]],
        p1_prob: float,
        model: Any,
        alpha: float = 0.0,
        market_p1: float | None = None,
        coverage_books: int = 0,
    ) -> dict[str, float]:
        implied = self._implied_probs_from_outcomes(outcomes)
        market = str(market)
        if market not in TENNIS_MARKETS:
            return {}
        if market == "match_winner":
            base = min(max(float(p1_prob), 1e-6), 1 - 1e-6)
            usable = (
                market_p1 is not None
                and int(coverage_books) >= 2
                and math.isfinite(float(market_p1))
                and 0.0 < float(market_p1) < 1.0
            )
            if usable:
                p1_m = min(max(float(market_p1), 1e-6), 1 - 1e-6)
                p1 = base if model is None else apply_blend(base, p1_m, alpha)
                p1 = min(max(p1, 1e-6), 1 - 1e-6)
                return {"p1": p1, "p2": 1 - p1}
            return {"p1": base, "p2": 1 - base}
        if market in {"total_points", "total_games", "spread", "game_handicap", "set_handicap"}:
            keys = ["over", "under"] if market in {"total_points", "total_games"} else ["p1", "p2"]
            out: dict[str, float] = {}
            if implied:
                for k in keys:
                    if k in implied:
                        out[k] = float(implied[k])
            for k in keys:
                out.setdefault(k, 0.5)
            if keys == ["p1", "p2"]:
                edge = (float(p1_prob) - 0.5) * 0.15
                out["p1"] = min(max(out["p1"] + edge, 1e-6), 1 - 1e-6)
                out["p2"] = 1.0 - out["p1"]
            s = sum(out.values())
            return {k: v / s for k, v in out.items()} if s > 0 else {}
        if implied:
            s = sum(implied.values())
            return {k: v / s for k, v in implied.items()} if s > 0 else {}
        if len(outcomes) == 2:
            ks = list(outcomes.keys())
            return {ks[0]: 0.5, ks[1]: 0.5}
        return {}

    def _walk_forward(self, rows: list[dict[str, Any]]) -> dict[str, Any]:
        if not rows:
            return {"folds": [], "predictions": 0, "correct": 0, "accuracy": None}
        min_train = 1
        test_window = DEFAULT_TEST_WINDOW
        folds: list[dict[str, Any]] = []
        predictions = 0
        correct = 0
        i = min_train
        fold_no = 1
        while i < len(rows):
            train_rows = rows[:i]
            test_rows = rows[i : i + test_window]
            if not test_rows:
                break
            model = self._fit_model(train_rows)
            fold_preds = 0
            fold_correct = 0
            for row in test_rows:
                prob = self._predict_with_model(model, row["features"])
                pred = 1 if prob >= 0.5 else 0
                fold_preds += 1
                predictions += 1
                if pred == int(row["actual"]):
                    fold_correct += 1
                    correct += 1
            folds.append(
                {
                    "fold": fold_no,
                    "train_size": len(train_rows),
                    "test_size": len(test_rows),
                    "train_end_event_uid": train_rows[-1]["event_uid"],
                    "test_event_uids": [r["event_uid"] for r in test_rows],
                    "accuracy": (fold_correct / fold_preds) if fold_preds else None,
                }
            )
            i += test_window
            fold_no += 1
        return {
            "folds": folds,
            "predictions": predictions,
            "correct": correct,
            "accuracy": (correct / predictions) if predictions else None,
            "min_train_samples": min_train,
            "test_window": test_window,
        }

    def _walk_forward_summary_from_oof_rows(
        self,
        oof_rows: list[tuple[float, int, dict[str, Any]]],
        window: int | None = None,
    ) -> dict[str, Any]:
        """Summarize walk-forward folds from already-computed OOF rows."""
        test_window = max(1, int(window or DEFAULT_TEST_WINDOW))
        predictions = len(oof_rows)
        correct = sum(
            1 for p, actual, _ in oof_rows if (p >= 0.5) == bool(actual)
        )
        folds: list[dict[str, Any]] = []
        for fold_no, start in enumerate(range(0, predictions, test_window), 1):
            chunk = oof_rows[start : start + test_window]
            chunk_correct = sum(
                1 for p, actual, _ in chunk if (p >= 0.5) == bool(actual)
            )
            folds.append(
                {
                    "fold": fold_no,
                    "train_size": 1 + (fold_no - 1) * test_window,
                    "test_size": len(chunk),
                    "train_end_event_uid": str(chunk[0][2].get("event_uid", "")),
                    "test_event_uids": [str(row.get("event_uid", "")) for _, _, row in chunk],
                    "accuracy": chunk_correct / len(chunk) if chunk else None,
                }
            )
        return {
            "folds": folds,
            "predictions": predictions,
            "correct": correct,
            "accuracy": (correct / predictions) if predictions else None,
            "min_train_samples": 1,
            "test_window": test_window,
        }

    def _walk_forward_oof_rows(
        self, rows: list[dict[str, Any]], window: int | None = None
    ) -> list[tuple[float, int, dict[str, Any]]]:
        """Return out-of-fold (probability, actual, source row) triples."""
        test_window = int(window or DEFAULT_TEST_WINDOW)

        def _row_time(r: dict[str, Any]) -> tuple[datetime, str]:
            dt = _to_dt(r.get("event_start_at")) or _to_dt(r.get("observed_at"))
            return (dt or datetime.min.replace(tzinfo=timezone.utc), str(r.get("event_uid")))

        rows = sorted(
            (r for r in rows if r.get("actual") in (0, 1)),
            key=_row_time,
        )
        if test_window < 1 or not rows:
            return []
        out: list[tuple[float, int, dict[str, Any]]] = []
        for i in range(1, len(rows), test_window):
            train_rows = rows[:i]
            test_rows = rows[i : i + test_window]
            if not test_rows:
                break
            model = self._fit_model(train_rows)
            for row in test_rows:
                p = self._predict_with_model(model, row.get("features") or {})
                out.append((min(max(float(p), 1e-6), 1.0 - 1e-6), int(row["actual"]), row))
        return out

    def _walk_forward_oof(
        self, rows: list[dict[str, Any]], window: int | None = None
    ) -> list[tuple[float, int]]:
        """Return out-of-fold (probability, actual) pairs."""
        return [(p, actual) for p, actual, _ in self._walk_forward_oof_rows(rows, window)]

    def _write_model_run(
        self, run: ModelRun, metrics: dict[str, Any] | None = None
    ) -> None:
        try:
            metrics_json = json.dumps(metrics or {}, ensure_ascii=False, default=str)
        except Exception:
            logger.exception(
                "Failed to serialize metrics for model_run %s; writing empty metrics",
                run.run_id,
            )
            metrics_json = "{}"
        with self.repo.connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO model_runs(run_id, features_version, created_at, metrics_json)
                VALUES (?, ?, ?, ?)
                """,
                (run.run_id, run.features_version, run.created_at, metrics_json),
            )

    def _build_metrics(
        self,
        processed_rows: list[dict[str, Any]],
        new_rows: list[dict[str, Any]],
        wf: dict[str, Any],
        oof_rows: list[tuple[float, int, dict[str, Any]]] | None = None,
    ) -> dict[str, Any]:
        from math import log
        valid = [r for r in processed_rows if r.get("actual") in (0, 1)]

        def _row_time(r: dict[str, Any]) -> tuple[datetime, str]:
            dt = _to_dt(r.get("event_start_at")) or _to_dt(r.get("observed_at"))
            return (dt or datetime.min.replace(tzinfo=timezone.utc), str(r.get("event_uid")))

        rows = sorted(valid, key=_row_time)
        brier = logloss = roi = hit_rate = clv_avg = max_dd = None
        calib_bins: list[dict[str, Any]] = []
        bad_actual = self._count_bad_actual()
        if rows:
            # Train on the filtered rows only: otherwise bad "actual" values
            # (draws / unparsed scores) would leak into training targets.
            model = self._fit_model(rows)
            probs: list[float] = []
            actuals: list[int] = []
            for r in rows:
                p = self._predict_with_model(model, r.get("features") or {})
                p = min(max(float(p), 1e-6), 1 - 1e-6)
                probs.append(p)
                actuals.append(int(r["actual"]))
            brier = sum((p - a) ** 2 for p, a in zip(probs, actuals)) / len(rows)
            logloss = -sum(
                a * log(p) + (1 - a) * log(1 - p) for p, a in zip(probs, actuals)
            ) / len(rows)
            hit_rate = sum(
                1 for p, a in zip(probs, actuals) if (p >= 0.5) == bool(a)
            ) / len(rows)
            for i in range(10):
                lo, hi = i / 10, (i + 1) / 10
                bucket = [
                    (p, a) for p, a in zip(probs, actuals)
                    if (lo <= p < hi) or (i == 9 and p == 1.0)
                ]
                if bucket:
                    calib_bins.append({
                        "bin_lo": lo, "bin_hi": hi, "count": len(bucket),
                        "avg_pred": sum(p for p, _ in bucket) / len(bucket),
                        "avg_actual": sum(a for _, a in bucket) / len(bucket),
                    })
        edge_allowed = len(rows) >= 30
        if oof_rows is None:
            oof_rows = self._walk_forward_oof_rows(rows)
        oof = [(p, actual) for p, actual, _ in oof_rows]
        oof_report = calibration_report(oof)
        oof_hit_rate = (
            sum(1 for p, a in oof if (p >= 0.5) == bool(a)) / len(oof) if oof else None
        )
        oof_calibration_bins = list(oof_report.get("bins") or [])
        blend_pairs = [
            (p, float(row.get("market_p1") or p), actual)
            for p, actual, row in oof_rows
        ]
        blend_alpha = fit_blend_alpha(blend_pairs)
        blend_weight, blend_losses = fit_blend_weight_from_repository(self.repo)
        self._state["blend_weight"] = blend_weight
        calibration_breakpoints = fit_isotonic(
            [(p, actual) for p, actual in oof]
        )
        market_cmp = market_comparison(blend_pairs)
        stakes = []
        for row in rows:
            coverage = int(row.get("market_coverage") or 0)
            odds = row.get("offered_odds")
            market_p = row.get("market_p1")
            if coverage < 2 or not odds or market_p is None:
                continue
            try:
                odds_value = float(odds)
                p_value = float(market_p)
            except (TypeError, ValueError):
                continue
            if p_value * odds_value - 1.0 < MIN_EDGE_FOR_STAKE:
                continue
            stakes.append(kelly_fraction(p_value, odds_value))
        suggested_stake = max(stakes, default=0.0)
        metrics = {
            "samples": len(processed_rows),
            "new_samples": len(new_rows),
            "sports": sorted({str(r.get("sport")) for r in processed_rows}),
            "catboost_enabled": bool(self.settings.enable_catboost),
            "walk_forward": wf,
            "processed_event_uids": [str(r.get("event_uid")) for r in processed_rows],
            "brier": oof_report["brier"],
            "log_loss": oof_report["log_loss"],
            "oof_brier": oof_report["brier"],
            "oof_log_loss": oof_report["log_loss"],
            "oof_samples": oof_report["n"],
            "oof_hit_rate": oof_hit_rate,
            "blend_alpha": blend_alpha,
            "blend_weight": blend_weight,
            "blend_losses": blend_losses,
            "calibration_breakpoints": calibration_breakpoints,
            "market_comparison": market_cmp,
            "suggested_stake": suggested_stake,
            "roi": roi,
            "hit_rate": oof_hit_rate,
            "max_drawdown": max_dd,
            "clv": clv_avg,
            "calibration_bins": oof_calibration_bins,
            "oof_calibration_bins": oof_calibration_bins,
            "in_sample_brier": brier,
            "in_sample_log_loss": logloss,
            "in_sample_hit_rate": hit_rate,
            "in_sample_calibration_bins": calib_bins,
            "profit_by_market": {},
            "profit_by_league": {},
            "edge_report_allowed": edge_allowed,
            "min_edge_samples": 30,
            "bad_actual": bad_actual,
            "metrics_note": (
                "Brier/logloss/hit-rate/calibration — только out-of-fold; in_sample_* "
                "сохранены исключительно как диагностика. ROI/CLV/max drawdown требуют "
                "odds/closing на момент решения и могут быть n/a. Это симуляция, не "
                "рекомендация ставки."
            ),
        }
        if not edge_allowed:
            metrics["edge_warning"] = "minimum sample guard: need >= 30 resolved signals"
        return metrics

    def _count_bad_actual(self) -> int:
        try:
            events = {e.event_uid: e for e in self.repo.events_for_resolution()}
            bad = 0
            for row in self.repo.results():
                ev = events.get(str(row.get("event_uid")))
                if ev is None:
                    continue
                if self._actual_for_event(ev, row) is None:
                    bad += 1
            return bad
        except Exception:
            logger.exception("Failed to count bad_actual results")
            return 0

    def _score_distribution_rows(
        self,
        event: CanonicalEvent,
        p1_prob: float,
        run_id: str,
        observed_at: datetime,
        cached_results: Any | None = None,
    ) -> list[dict[str, Any]]:
        return build_score_distribution_rows(
            event,
            self.repo,
            p1_prob,
            run_id,
            observed_at,
            blend_weight=self._state.get("blend_weight"),
            cached_results=cached_results,
        )

    def _generate_predictions(
        self,
        run_id: str,
        model: Any,
        elo: dict[str, EloRating],
        glicko: dict[str, GlickoRating],
        alpha: float = 0.0,
        calibration_breaks: Sequence[tuple[float, float, float]] | None = None,
    ) -> list[dict[str, Any]]:
        events = self.repo.events_for_resolution()
        all_results = list(self.repo.results())
        results = {str(row["event_uid"]) for row in all_results}
        now = datetime.now(timezone.utc)
        preds: list[dict[str, Any]] = []
        for event in events:
            if event.event_uid in results:
                continue
            if len(event.participant_ids) < 2:
                continue
            start_at = _to_dt(event.start_at)
            if start_at is None:
                continue
            seconds_to_start = (start_at - now).total_seconds()
            if str(event.sport) != TENNIS_ONLY_SPORT:
                continue
            sport = TENNIS_ONLY_SPORT
            horizon_hours = 168
            if sport == "tennis":
                horizon_hours = max(
                    int(getattr(self.settings, "tennis_prediction_horizon_hours", 72)), 1
                )
            if seconds_to_start < -2 * 86400:
                continue
            if seconds_to_start > horizon_hours * 3600:
                continue
            p1, p2 = event.participant_ids[0], event.participant_ids[1]
            er = elo.setdefault(sport, EloRating())
            gr = glicko.setdefault(sport, GlickoRating())
            as_of = now
            try:
                features = build_features(
                    event, self.repo, as_of=as_of, cached_results=all_results
                )
            except Exception:
                logger.exception(
                    "build_features failed for event %s; using empty features",
                    event.event_uid,
                )
                features = {}
            features["elo_p1"] = float(er.probability(p1, p2))
            features["glicko_p1"] = float(gr.probability(p1, p2))
            p1_prob = self._predict_with_model(model, features)
            if model is None:
                p1_prob = (features["elo_p1"] + features["glicko_p1"]) / 2.0
            p1_prob = min(max(float(p1_prob), 1e-6), 1 - 1e-6)
            if calibration_breaks:
                p1_prob = float(
                    predict_isotonic(list(calibration_breaks), [p1_prob])[0]
                )
                p1_prob = min(max(p1_prob, 1e-6), 1 - 1e-6)
            try:
                for score_row in self._score_distribution_rows(
                    event, p1_prob, run_id, now, cached_results=all_results
                ):
                    self.repo.save_score_distribution(score_row)
            except Exception:
                logger.exception(
                    "score distribution failed for event %s; keeping legacy predictions",
                    event.event_uid,
                )
            snaps = [
                s for s in self.repo.last_snapshots(event.event_uid)
                if not bool(getattr(s, "is_live", False))
                and (dt := _to_dt(getattr(s, "observed_at", None))) is not None
                and dt < start_at
                and (start_at - dt).total_seconds() <= MARKET_PRIOR_MAX_AGE_HOURS * 3600
            ]
            decision_at = max((_to_dt(getattr(s, "observed_at", None)) for s in snaps), default=None)
            market_p1, market_coverage = self._market_p1_from_snapshots(snaps, start_at)
            grouped: dict[tuple[str, float | None], list[tuple[Any, float | None]]] = {}
            for snap in snaps:
                market = canonical_tennis_market(snap.market)
                raw_line = getattr(snap, "line", None)
                line = float(raw_line) if raw_line is not None else None
                handicap = market in {"game_handicap", "set_handicap", "set_game_handicap"}
                key = (market, abs(line) if handicap and line is not None else line)
                grouped.setdefault(key, []).append((snap, line))
            by_market: dict[tuple[str, float | None], dict[str, tuple[float, str | None]]] = {}
            for (market, _), entries in grouped.items():
                handicap = market in {"game_handicap", "set_handicap", "set_game_handicap"}
                p1_lines = [line for snap, line in entries if snap.outcome == "p1" and line is not None]
                if handicap and p1_lines:
                    line = p1_lines[0]
                elif handicap and entries and entries[0][1] is not None:
                    line = -entries[0][1]
                else:
                    line = None
                slot: dict[str, tuple[float, str | None]] = {}
                for snap, _ in entries:
                    cur = slot.get(snap.outcome)
                    if cur is None or snap.odds_decimal > cur[0]:
                        slot[snap.outcome] = (snap.odds_decimal, snap.bookmaker)
                by_market[(market, line)] = slot
            urgency = 1.0 / (1.0 + max(seconds_to_start, 0) / 3600)
            tennis_bonus = 0.2 if sport == "tennis" else 0.0
            by_market.setdefault(
                ("match_winner", None), by_market.get(("match_winner", None), {})
            )
            for (market, line), outcomes in by_market.items():
                market_probs = self._market_probs(
                    market, line, outcomes, p1_prob, model,
                    alpha=alpha,
                    market_p1=market_p1,
                    coverage_books=market_coverage,
                )
                if not market_probs:
                    continue
                conf = max(abs(p - 0.5) * 2 for p in market_probs.values())
                priority = urgency + tennis_bonus + conf * 0.1
                for outcome, prob in market_probs.items():
                    odds, bk = outcomes.get(outcome, (None, None))
                    preds.append({
                        "model_run_id": run_id,
                        "event_uid": event.event_uid,
                        "market": market,
                        "line": line,
                        "outcome": outcome,
                        "model_prob": min(max(float(prob), 1e-6), 1 - 1e-6),
                        "odds_decimal": odds,
                        "bookmaker": bk,
                        "observed_at": decision_at,
                        "event_start_at": start_at,
                        "is_research_only": True,
                        "_priority_score": priority,
                        "_seconds_to_start": seconds_to_start,
                        "_sport": sport,
                    })
        preds.sort(
            key=lambda r: (
                -float(r.get("_priority_score", 0.0)),
                float(r.get("_seconds_to_start", 10**12)),
                -float(r.get("model_prob", 0.0)),
            )
        )
        max_predictions = max(int(getattr(self.settings, "max_predictions", 2000)), 100)
        # Cap both total rows and per-event rows. The previous version only
        # capped events, so multi-market events could blow past the limit.
        per_event_cap = max(4, max_predictions // 100)
        kept: list[dict[str, Any]] = []
        per_event_count: dict[str, int] = {}
        for r in preds:
            uid = str(r["event_uid"])
            if per_event_count.get(uid, 0) >= per_event_cap:
                continue
            kept.append(r)
            per_event_count[uid] = per_event_count.get(uid, 0) + 1
            if len(kept) >= max_predictions:
                break
        for r in kept:
            r.pop("_priority_score", None)
            r.pop("_seconds_to_start", None)
            r.pop("_sport", None)
        return kept

    def step(self) -> ModelRun:
        snap_id, result_id = self._watermarks()

        with self._lock:
            state_snapshot = {
                "processed_rows": [
                    dict(r) for r in (self._state.get("processed_rows") or [])
                ],
                "elo": copy.deepcopy(self._elo),
                "glicko": copy.deepcopy(self._glicko),
                "last_run_id": self.last_run_id,
                "last_run_created_at": self._state.get("last_run_created_at"),
                "features_version": self._state.get("features_version"),
                "blend_alpha": self._state.get("blend_alpha", 0.0),
                "calibration_breakpoints": self._state.get("calibration_breakpoints"),
                "runs": self._state.get("runs", 0),
                "predictions_count": self._state.get("predictions_count", 0),
            }

        processed_rows = state_snapshot["processed_rows"]
        processed_uids = {str(r.get("event_uid")) for r in processed_rows}
        elo_next = state_snapshot["elo"]
        glicko_next = state_snapshot["glicko"]

        new_rows = self._collect_new_rows(elo_next, glicko_next, processed_uids)

        if not new_rows:
            model_next = self._fit_model(processed_rows)
            if state_snapshot["last_run_id"] is None:
                run = ModelRun(
                    run_id=str(uuid4()),
                    features_version=FEATURES_VERSION,
                    created_at=datetime.now(timezone.utc).isoformat(timespec="microseconds"),
                )
                oof_rows = self._walk_forward_oof_rows(processed_rows)
                metrics = self._build_metrics(
                    processed_rows, [], self._walk_forward(processed_rows),
                    oof_rows=oof_rows,
                )
                metrics["no_op"] = True
                self._write_model_run(run, metrics=metrics)
                preds = self._generate_predictions(
                    run.run_id, model_next, elo_next, glicko_next,
                    alpha=float(metrics.get("blend_alpha") or 0.0),
                    calibration_breaks=metrics.get("calibration_breakpoints"),
                )
                self.repo.save_predictions(preds)
                with self._lock:
                    self._model = model_next
                    self._elo = elo_next
                    self._glicko = glicko_next
                    self._state["last_run_id"] = run.run_id
                    self._state["last_run_created_at"] = run.created_at
                    self._state["features_version"] = run.features_version
                    self._state["blend_alpha"] = float(metrics.get("blend_alpha") or 0.0)
                    self._state["calibration_breakpoints"] = metrics.get("calibration_breakpoints")
                    self._state["runs"] = int(state_snapshot["runs"]) + 1
                    self._state["predictions_count"] = len(preds)
                    self._state["last_snapshot_id"] = snap_id
                    self._state["last_result_id"] = result_id
                    self._atomic_write_checkpoint()
                return run

            try:
                preds = self._generate_predictions(
                    str(state_snapshot["last_run_id"]), model_next, elo_next, glicko_next,
                    alpha=float(state_snapshot.get("blend_alpha") or 0.0),
                    calibration_breaks=state_snapshot.get("calibration_breakpoints"),
                )
                self.repo.save_predictions(preds)
                with self._lock:
                    # Persist ratings picked up during prediction generation
                    # (e.g. new sports/players), otherwise they would be lost.
                    self._elo = elo_next
                    self._glicko = glicko_next
                    self._state["predictions_count"] = len(preds)
                    self._state["last_snapshot_id"] = snap_id
                    self._state["last_result_id"] = result_id
                    self._atomic_write_checkpoint()
            except Exception:
                logger.exception("No-op prediction refresh failed")
            return ModelRun(
                run_id=str(state_snapshot["last_run_id"]),
                features_version=str(state_snapshot["features_version"]),
                created_at=str(
                    state_snapshot.get("last_run_created_at")
                    or datetime.now(timezone.utc).isoformat(timespec="microseconds")
                ),
            )

        for row in new_rows:
            observed_iso = _to_dt(row["observed_at"])
            start_iso = _to_dt(row["event_start_at"])
            processed_rows.append(
                {
                    "event_uid": row["event_uid"],
                    "sport": row["sport"],
                    "observed_at": observed_iso.isoformat() if observed_iso else None,
                    "event_start_at": start_iso.isoformat() if start_iso else None,
                    "features": row["features"],
                    "actual": int(row["actual"]),
                    "p1": row["p1"],
                    "p2": row["p2"],
                    "market_p1": row.get("market_p1", 0.0),
                    "market_coverage": int(row.get("market_coverage") or 0),
                    "offered_odds": row.get("offered_odds"),
                }
            )

        seen: set[str] = set()
        deduped: list[dict[str, Any]] = []
        for row in processed_rows:
            uid = str(row.get("event_uid"))
            if uid in seen:
                continue
            seen.add(uid)
            deduped.append(row)
        processed_rows = deduped

        oof_rows = self._walk_forward_oof_rows(processed_rows)
        wf = self._walk_forward_summary_from_oof_rows(oof_rows)
        model_next = self._fit_model(processed_rows)
        run = ModelRun(
            run_id=str(uuid4()),
            features_version=FEATURES_VERSION,
            created_at=datetime.now(timezone.utc).isoformat(timespec="microseconds"),
        )
        metrics = self._build_metrics(processed_rows, new_rows, wf, oof_rows=oof_rows)
        self._write_model_run(run, metrics=metrics)
        preds = self._generate_predictions(
            run.run_id, model_next, elo_next, glicko_next,
            alpha=float(metrics.get("blend_alpha") or 0.0),
            calibration_breaks=metrics.get("calibration_breakpoints"),
        )
        self.repo.save_predictions(preds)

        with self._lock:
            self._elo = elo_next
            self._glicko = glicko_next
            self._model = model_next
            self._state["last_run_id"] = run.run_id
            self._state["last_run_created_at"] = run.created_at
            self._state["features_version"] = run.features_version
            self._state["blend_alpha"] = float(metrics.get("blend_alpha") or 0.0)
            self._state["calibration_breakpoints"] = metrics.get("calibration_breakpoints")
            self._state["last_snapshot_id"] = snap_id
            self._state["last_result_id"] = result_id
            self._state["runs"] = int(state_snapshot["runs"]) + 1
            self._state["processed_event_uids"] = [
                str(r.get("event_uid")) for r in processed_rows
            ]
            self._state["processed_rows"] = processed_rows
            self._state["processed_count"] = len(processed_rows)
            self._state["predictions_count"] = len(preds)
            self._atomic_write_checkpoint()

        return run

    def start(self) -> None:
        if self._scheduler is not None:
            return
        scheduler = BackgroundScheduler()
        interval = max(int(getattr(self.settings, "poll_seconds", 90)), 1)
        scheduler.add_job(
            self.step,
            "interval",
            seconds=interval,
            max_instances=1,
            misfire_grace_time=60,
            coalesce=True,
        )
        scheduler.start()
        self._scheduler = scheduler

    def stop(self) -> None:
        scheduler = self._scheduler
        if scheduler is None:
            return
        scheduler.shutdown(wait=True)
        self._scheduler = None
