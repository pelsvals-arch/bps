"""Feature extraction for baseline models.

All features must be computed with information observed before the event
starts. Callers should pass events whose snapshots/results are filtered
by as_of/start to prevent future leakage.
"""
from __future__ import annotations
import json
from pathlib import Path

import math
from datetime import datetime, timedelta, timezone
from typing import Any

from betdash.db.repository import Repository
from betdash.normalize.models import CanonicalEvent
from betdash.normalize.registry import normalize_name


def _to_dt(value: str | datetime | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _parse_result_date(value: str | None) -> datetime | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    for fmt in (None, "%d/%m/%Y", "%d.%m.%Y"):
        try:
            if fmt is None:
                dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            else:
                dt = datetime.strptime(raw, fmt)
        except ValueError:
            continue
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    return None


def _winner_from_score(score: str) -> str | None:
    from betdash.tennis.score import tennis_winner_side
    return tennis_winner_side(str(score or ""))


def _norm_pid(value: str) -> str:
    from betdash.normalize.registry import normalize_name
    text = str(value or "")
    for prefix in ("name:", "unresolved:", "ambiguous:", "resolved:"):
        if text.startswith(prefix):
            text = text[len(prefix):]
            break
    return normalize_name(text)




_SACKMANN_PLAYER_ALIAS_MAP: dict[str, str] | None = None


def clear_sackmann_alias_cache() -> None:
    """Drop cached player aliases after the alias file changes."""
    global _SACKMANN_PLAYER_ALIAS_MAP
    _SACKMANN_PLAYER_ALIAS_MAP = None


def _sackmann_player_alias_map() -> dict[str, str]:
    global _SACKMANN_PLAYER_ALIAS_MAP
    if _SACKMANN_PLAYER_ALIAS_MAP is None:
        path = Path(__file__).resolve().parents[1] / "normalize" / "sackmann_aliases.json"
        raw = json.loads(path.read_text(encoding="utf-8"))
        result: dict[str, str] = {}
        for canonical, aliases in raw.items():
            for alias in aliases:
                key = normalize_name(alias)
                if key:
                    result.setdefault(key, canonical)
        _SACKMANN_PLAYER_ALIAS_MAP = result
    return _SACKMANN_PLAYER_ALIAS_MAP


def _sackmann_canonical_name(value: str) -> str:
    normalized = _norm_pid(value)
    if not normalized:
        return normalized
    canonical = _sackmann_player_alias_map().get(normalized)
    return normalized if canonical is None else normalize_name(canonical)


SACKMANN_CACHE_MAX_ENTRIES = 8
_SACKMANN_ROWS_CACHE: dict[tuple[str, str, int], list[tuple[Any, ...]]] = {}


def _remember_sackmann_rows(
    cache_key: tuple[str, str, int], rows: list[tuple[Any, ...]]
) -> None:
    db_key, cutoff, _ = cache_key
    for stale in [
        key for key in _SACKMANN_ROWS_CACHE
        if key[0] == db_key and key[1] == cutoff
    ]:
        del _SACKMANN_ROWS_CACHE[stale]
    while len(_SACKMANN_ROWS_CACHE) >= SACKMANN_CACHE_MAX_ENTRIES:
        _SACKMANN_ROWS_CACHE.pop(next(iter(_SACKMANN_ROWS_CACHE)))
    _SACKMANN_ROWS_CACHE[cache_key] = rows


def _sackmann_aliases(name: str) -> set[str]:
    n = _norm_pid(name)
    if not n:
        return set()
    parts = [x for x in n.split() if x]
    a = {n}
    if len(parts) >= 2:
        first, last = parts[0], parts[-1]
        a.add(f"{last} {first[0]}")
        a.add(f"{last} {first}")
        a.add(f"{first[0]} {last}")
    return a


def _tennis_sackmann_features(repo: Repository, p1: str, p2: str, start_at: datetime) -> dict[str, float]:
    p1 = _sackmann_canonical_name(p1)
    p2 = _sackmann_canonical_name(p2)
    cutoff = start_at.strftime("%Y%m%d")
    window_start = (start_at - timedelta(days=5 * 365)).strftime("%Y%m%d")
    cutoff_ord = start_at.date().toordinal()
    db_key = str(getattr(repo, "path", ""))
    try:
        with repo.connection() as conn:
            conn.execute("SELECT 1 FROM sackmann_matches LIMIT 1")
            total = int(
                conn.execute(
                    "SELECT COUNT(*) FROM sackmann_matches WHERE tourney_date < ? AND tourney_date >= ?",
                    (cutoff, window_start),
                ).fetchone()[0]
            )
    except Exception:
        return {}
    cache_key = (db_key, cutoff, total)
    rows = _SACKMANN_ROWS_CACHE.get(cache_key)
    if rows is None:
        with repo.connection() as conn:
            rows = conn.execute(
                """
                SELECT tourney_date,surface,best_of,winner_name,loser_name,
                       w_svpt,w_1stWon,w_2ndWon,l_svpt,l_1stWon,l_2ndWon,
                       is_retirement,winner_rank,loser_rank
                FROM sackmann_matches
                WHERE tourney_date < ? AND tourney_date >= ?
                ORDER BY tourney_date, tourney_id, match_num
                """,
                (cutoff, window_start),
            ).fetchall()
        _remember_sackmann_rows(cache_key, rows)
    from collections import defaultdict

    # Bayesian priors and an exponential recency decay (half-life = 1 year).
    # A player's service/return rate is a small-sample estimate, so pull it
    # toward a population prior and let recent matches dominate old ones.
    SRV_PRIOR = 0.62
    RET_PRIOR = 0.38
    RETIRE_PRIOR = 0.04
    SRV_SHRINK = 200.0
    RET_SHRINK = 200.0
    RETIRE_SHRINK = 20.0

    def _st():
        return {
            "svc_pts": 0, "svc_won": 0, "ret_pts": 0, "ret_won": 0,
            "svc_w": 0.0, "svc_won_w": 0.0, "ret_w": 0.0, "ret_won_w": 0.0,
            "matches_365": 0, "wins_365": 0, "matches_30": 0,
            "matches_total": 0, "retirements": 0,
            "surf_matches": 0, "surf_wins": 0, "elo": 1500.0, "last_date": None,
            "rank": None, "last_surface": "", "last_best_of": 3, "elo_surface": {},
        }

    stats = defaultdict(_st)

    def i(v):
        try:
            if v is None or str(v).strip() == "":
                return 0
            return int(float(v))
        except Exception:
            return 0

    K=32.0
    for r in rows:
        d = _parse_result_date(str(r["tourney_date"]))
        if d is None or d >= start_at:
            continue
        age_days = max(0, cutoff_ord - d.date().toordinal())
        recent = age_days <= 365
        in_30 = age_days <= 30
        recency_weight = 2.0 ** (-age_days / 365.0)
        retired = i(r["is_retirement"]) == 1
        w = _norm_pid(str(r["winner_name"] or ""))
        l = _norm_pid(str(r["loser_name"] or ""))
        surface = str(r["surface"] or "").lower().strip()
        best_of = i(r["best_of"])
        wrank = i(r["winner_rank"]) or None
        lr_rank = i(r["loser_rank"]) or None
        for name, won, is_w, rank in ((w, 1, True, wrank), (l, 0, False, lr_rank)):
            if not name:
                continue
            st = stats[name]
            if rank is not None:
                st["rank"] = rank
            if surface:
                st["last_surface"] = surface
            if best_of in (3, 5):
                st["last_best_of"] = best_of
            st["matches_total"] += 1
            if in_30:
                st["matches_30"] += 1
            if recent:
                st["matches_365"] += 1
                st["wins_365"] += won
            if retired and not is_w:
                st["retirements"] += 1
            st["last_date"] = d
            if is_w:
                svpt=i(r["w_svpt"]); s1=i(r["w_1stWon"]); s2=i(r["w_2ndWon"])
                os1=i(r["l_1stWon"]); os2=i(r["l_2ndWon"]); ospt=i(r["l_svpt"])
            else:
                svpt=i(r["l_svpt"]); s1=i(r["l_1stWon"]); s2=i(r["l_2ndWon"])
                os1=i(r["w_1stWon"]); os2=i(r["w_2ndWon"]); ospt=i(r["w_svpt"])
            if svpt > 0:
                st["svc_pts"] += svpt
                st["svc_won"] += s1 + s2
                st["svc_w"] += recency_weight * svpt
                st["svc_won_w"] += recency_weight * (s1 + s2)
            if ospt > 0:
                st["ret_pts"] += ospt
                st["ret_won"] += max(ospt - os1 - os2, 0)
                st["ret_w"] += recency_weight * ospt
                st["ret_won_w"] += recency_weight * max(ospt - os1 - os2, 0)
        # simple pre-event Elo update from Sackmann history
        if w and l:
            rw, rl = stats[w]["elo"], stats[l]["elo"]
            ew = 1.0/(1.0+10**((rl-rw)/400.0))
            stats[w]["elo"] = rw + K*(1.0-ew)
            stats[l]["elo"] = rl + K*(0.0-ew)
            if surface:
                sw = stats[w]["elo_surface"].get(surface, 1500.0)
                sl = stats[l]["elo_surface"].get(surface, 1500.0)
                es = 1.0/(1.0+10**((sl-sw)/400.0))
                stats[w]["elo_surface"][surface] = sw + K*(1.0-es)
                stats[l]["elo_surface"][surface] = sl + K*(0.0-es)
    evt_surface = (
        (stats.get(p1) or {}).get("last_surface")
        or (stats.get(p2) or {}).get("last_surface")
        or ""
    )
    evt_best_of = int(
        (stats.get(p1) or {}).get("last_best_of")
        or (stats.get(p2) or {}).get("last_best_of")
        or 3
    )

    def surface_rate(name, surface):
        if not name or not surface: return 0.5
        wins=tot=0
        aliases=_sackmann_aliases(name)
        for r in rows:
            d=_parse_result_date(str(r["tourney_date"]))
            if d is None or d>=start_at: continue
            if (cutoff_ord-d.date().toordinal())>365*3: continue
            if str(r["surface"] or "").lower().strip()!=surface: continue
            w=_norm_pid(str(r["winner_name"] or "")); l=_norm_pid(str(r["loser_name"] or ""))
            if w in aliases: wins+=1; tot+=1
            elif l in aliases: tot+=1
        return (wins/tot) if tot>=3 else 0.5

    def get(name):
        st = stats.get(name)
        if not st:
            return {
                "srv_win": SRV_PRIOR, "ret_win": RET_PRIOR,
                "retire_risk": RETIRE_PRIOR, "matches_365": 0.0, "matches_30": 0.0,
                "win_rate_365": 0.5, "elo": 1500.0, "surface_win_rate": 0.5,
                "rank": None, "elo_surface": {},
            }
        srv = (
            (st["svc_won_w"] + SRV_PRIOR * SRV_SHRINK) / (st["svc_w"] + SRV_SHRINK)
            if st["svc_w"] > 0 else SRV_PRIOR
        )
        ret = (
            (st["ret_won_w"] + RET_PRIOR * RET_SHRINK) / (st["ret_w"] + RET_SHRINK)
            if st["ret_w"] > 0 else RET_PRIOR
        )
        retire_risk = (
            (st["retirements"] + RETIRE_PRIOR * RETIRE_SHRINK)
            / (st["matches_total"] + RETIRE_SHRINK)
        )
        m365 = st["matches_365"]
        return {
            "srv_win": srv,
            "ret_win": ret,
            "retire_risk": retire_risk,
            "matches_365": float(m365),
            "matches_30": float(st["matches_30"]),
            "win_rate_365": (st["wins_365"] / m365) if m365 else 0.5,
            "elo": float(st["elo"]),
            "surface_win_rate": surface_rate(name, evt_surface),
            "rank": st["rank"],
            "elo_surface": st["elo_surface"],
        }

    a, b = get(p1), get(p2)

    def rank_diff(mine, theirs):
        if mine is None or theirs is None:
            return 0.0
        # Lower rank number is better; + means the player is ranked higher.
        return math.log((float(theirs) + 10.0) / (float(mine) + 10.0))

    def surface_elo(player):
        return float(player["elo_surface"].get(evt_surface, 1500.0))

    return {
        "surface": evt_surface, "best_of": evt_best_of,
        "p1_srv_win": a["srv_win"], "p2_srv_win": b["srv_win"],
        "p1_ret_win": a["ret_win"], "p2_ret_win": b["ret_win"],
        "p1_retire_risk": a["retire_risk"], "p2_retire_risk": b["retire_risk"],
        "p1_matches_365": a["matches_365"], "p2_matches_365": b["matches_365"],
        "p1_matches_30": a["matches_30"], "p2_matches_30": b["matches_30"],
        "p1_win_rate_365": a["win_rate_365"], "p2_win_rate_365": b["win_rate_365"],
        "p1_surface_win_rate": a["surface_win_rate"], "p2_surface_win_rate": b["surface_win_rate"],
        "p1_elo_sackmann": a["elo"], "p2_elo_sackmann": b["elo"],
        "p1_rank": float(a["rank"]) if a["rank"] is not None else 300.0,
        "p2_rank": float(b["rank"]) if b["rank"] is not None else 300.0,
        "p1_rank_diff": rank_diff(a["rank"], b["rank"]),
        "p2_rank_diff": rank_diff(b["rank"], a["rank"]),
        "p1_elo_hard": a["elo_surface"].get("hard", 1500.0),
        "p2_elo_hard": b["elo_surface"].get("hard", 1500.0),
        "p1_elo_clay": a["elo_surface"].get("clay", 1500.0),
        "p2_elo_clay": b["elo_surface"].get("clay", 1500.0),
        "p1_elo_grass": a["elo_surface"].get("grass", 1500.0),
        "p2_elo_grass": b["elo_surface"].get("grass", 1500.0),
        "p1_surface_elo": surface_elo(a), "p2_surface_elo": surface_elo(b),
        "p1_elo_blend": 0.6 * surface_elo(a) + 0.4 * a["elo"],
        "p2_elo_blend": 0.6 * surface_elo(b) + 0.4 * b["elo"],
    }

def build_features(
    event: CanonicalEvent,
    repo: Repository,
    as_of: datetime | None = None,
    cached_results: list[dict[str, Any]] | None = None,
) -> dict[str, float]:
    """Build a numeric feature dict for an event.

    Uses only data observed before ``event.start_at`` and before ``as_of``
    when provided, preventing future leakage.
    """
    start_at = _to_dt(event.start_at)
    if start_at is None:
        return {}

    if as_of is not None:
        as_of_dt = _to_dt(as_of)
        if as_of_dt is not None:
            start_at = min(start_at, as_of_dt)

    participants = tuple(str(p) for p in (event.participant_ids or ()))
    p1 = _norm_pid(participants[0]) if len(participants) > 0 else ""
    p2 = _norm_pid(participants[1]) if len(participants) > 1 else ""

    with repo.connection() as conn:
        snap_rows = conn.execute(
            """
            SELECT bookmaker, market, outcome, odds_decimal, observed_at
            FROM odds_snapshots
            WHERE event_uid = ? AND is_live = 0
            ORDER BY observed_at, id
            """,
            (str(event.event_uid),),
        ).fetchall()

    pre_start = []
    for row in snap_rows:
        observed_at = _to_dt(row["observed_at"])
        if observed_at is None or observed_at >= start_at:
            continue
        pre_start.append(row)

    latest_by_key: dict[tuple[str, str, str], Any] = {}
    for row in pre_start:
        key = (
            str(row["bookmaker"]),
            str(row["market"]),
            str(row["outcome"]),
        )
        latest_by_key[key] = row

    p1_prices = [
        _safe_float(row["odds_decimal"])
        for row in latest_by_key.values()
        if str(row["outcome"]) == "p1"
        and str(row["market"]) in {"match_winner", "moneyline", "winner"}
    ]
    p2_prices = [
        _safe_float(row["odds_decimal"])
        for row in latest_by_key.values()
        if str(row["outcome"]) == "p2"
        and str(row["market"]) in {"match_winner", "moneyline", "winner"}
    ]

    p1_best = max(p1_prices) if p1_prices else 0.0
    p2_best = max(p2_prices) if p2_prices else 0.0
    p1_implied = (1.0 / p1_best) if p1_best > 1.0 else 0.0
    p2_implied = (1.0 / p2_best) if p2_best > 1.0 else 0.0
    # Consensus only makes sense when both sides of the market are quoted.
    # With a single leg, the previous version returned 1.0 for the quoted
    # side, which the model learned as "guaranteed win".
    if p1_implied > 0.0 and p2_implied > 0.0:
        p1_consensus = p1_implied / (p1_implied + p2_implied)
    else:
        p1_consensus = 0.5

    results = cached_results if cached_results is not None else repo.results()
    event_day = start_at.date()
    history: list[dict[str, Any]] = []
    for row in results:
        row_dt = _parse_result_date(row.get("event_date"))
        if row_dt is None or row_dt.date() >= event_day:
            continue
        history.append(row)

    def _form(pid: str) -> float:
        wins = 0
        total = 0
        for row in history:
            pa = _norm_pid(str(row.get("participant_a") or ""))
            pb = _norm_pid(str(row.get("participant_b") or ""))
            side = _winner_from_score(str(row.get("score") or ""))
            if side is None:
                continue
            if pid and pid == pa:
                total += 1
                if side == "left":
                    wins += 1
            elif pid and pid == pb:
                total += 1
                if side == "right":
                    wins += 1
        return (wins / total) if total else 0.5

    def _last_play_day(pid: str) -> datetime | None:
        days: list[datetime] = []
        for row in history:
            pa = _norm_pid(str(row.get("participant_a") or ""))
            pb = _norm_pid(str(row.get("participant_b") or ""))
            if pid and pid in {pa, pb}:
                dt = _parse_result_date(row.get("event_date"))
                if dt is not None:
                    days.append(dt)
        return max(days) if days else None

    def _rest_days(pid: str) -> float:
        last_dt = _last_play_day(pid)
        if last_dt is None:
            return 30.0
        delta = start_at.date().toordinal() - last_dt.date().toordinal()
        return float(max(delta, 0))

    h2h_p1_wins = 0
    h2h_total = 0
    for row in history:
        pa = _norm_pid(str(row.get("participant_a") or ""))
        pb = _norm_pid(str(row.get("participant_b") or ""))
        if {pa, pb} != {p1, p2}:
            continue
        side = _winner_from_score(str(row.get("score") or ""))
        if side is None:
            continue
        h2h_total += 1
        winner = pa if side == "left" else pb
        if winner == p1:
            h2h_p1_wins += 1

    feats = {
        "p1_form": float(_form(p1)),
        "p2_form": float(_form(p2)),
        "p1_rest_days": float(_rest_days(p1)),
        "p2_rest_days": float(_rest_days(p2)),
        "surface": 0.0,
        "patch": 0.0,
        "map": 0.0,
        "h2h_p1": float(h2h_p1_wins / h2h_total) if h2h_total else 0.5,
        "market_p1_consensus": float(p1_consensus),
        "coverage_count": float(len({str(r["bookmaker"]) for r in pre_start})),
    }
    if str(event.sport).lower() == "tennis":
        tennis_feats = _tennis_sackmann_features(repo, p1, p2, start_at)
        surface_name = tennis_feats.pop("surface", "")
        feats.update(tennis_feats)
        feats["surface_name"] = str(surface_name or "")
    return feats