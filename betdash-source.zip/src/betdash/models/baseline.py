"""Baseline rating models.

Ratings are per-sport in the trainer; these classes hold rating state
and provide probability(a, b).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from math import isfinite, pi, sqrt


def score_margin(score: str | None) -> float:
    """Total game margin from a tennis score such as ``6-4 7-5``.

    Tiebreak numbers are ignored; only pairs of set scores contribute.
    Missing or unparseable scores return 0.0 (neutral WElo weight).
    """
    clean = re.sub(r"\([^)]*\)", " ", str(score or ""))
    nums = [int(n) for n in re.findall(r"\d+", clean)]
    return float(sum(abs(nums[i] - nums[i + 1]) for i in range(0, len(nums) - 1, 2)))


def _welo_weight(margin: float | None) -> float:
    """Normalized Kovalchik WElo weight, bounded for local K=20 stability."""
    try:
        value = max(0.0, float(margin))
    except (TypeError, ValueError):
        return 1.0
    if not isfinite(value):
        return 1.0
    return min(2.0, max(0.75, ((value + 5.0) / 5.0) ** 0.4))


@dataclass
class EloRating:
    k: float = 20.0
    base: float = 1500.0
    ratings: dict[str, float] = field(default_factory=dict)

    def get(self, player: str) -> float:
        return float(self.ratings.get(player, self.base))

    def probability(self, a: str, b: str) -> float:
        ra = self.get(a)
        rb = self.get(b)
        return 1.0 / (1.0 + 10 ** ((rb - ra) / 400.0))

    def update(
        self, a: str, b: str, score_a: float, weight: float = 1.0
    ) -> None:
        # Clamp to [0, 1] to keep rating state bounded even if callers pass
        # an out-of-range value by mistake. NaN is treated as a draw.
        try:
            score = float(score_a)
        except (TypeError, ValueError):
            score = 0.5
        score = 0.5 if not isfinite(score) else min(max(score, 0.0), 1.0)
        try:
            safe_weight = min(2.0, max(0.75, float(weight)))
        except (TypeError, ValueError):
            safe_weight = 1.0
        if not isfinite(safe_weight):
            safe_weight = 1.0
        pa = self.probability(a, b)
        ra = self.get(a)
        rb = self.get(b)
        step = self.k * safe_weight
        self.ratings[a] = ra + step * (score - pa)
        self.ratings[b] = rb + step * ((1.0 - score) - (1.0 - pa))


@dataclass
class GlickoState:
    rating: float = 1500.0
    rd: float = 350.0


@dataclass
class GlickoRating:
    """Lightweight Glicko-like rating for baseline probabilities.

    Uses Glicko-1 style g(RD) scaling with fixed volatility for MVP.
    update() uses a simplified heuristic (RD *= 0.98) rather than the
    full Glicko-1 formula with d^2 and volatility.
    """

    base: float = 1500.0
    q: float = 0.00575646273  # ln(10) / 400
    ratings: dict[str, GlickoState] = field(default_factory=dict)

    def get(self, player: str) -> GlickoState:
        state = self.ratings.get(player)
        if state is None:
            state = GlickoState(rating=self.base, rd=350.0)
            self.ratings[player] = state
        return state

    def _peek(self, player: str) -> GlickoState:
        """Read-only accessor: does not create state on lookup."""
        state = self.ratings.get(player)
        if state is None:
            return GlickoState(rating=self.base, rd=350.0)
        return state

    @staticmethod
    def _g(rd: float, q: float) -> float:
        return 1.0 / sqrt(1.0 + (3.0 * q * q * rd * rd) / (pi * pi))

    def probability(self, a: str, b: str) -> float:
        ra = self._peek(a)
        rb = self._peek(b)
        g = self._g(sqrt(ra.rd * ra.rd + rb.rd * rb.rd), self.q)
        return 1.0 / (1.0 + 10 ** (-g * (ra.rating - rb.rating) / 400.0))

    def update(self, a: str, b: str, score_a: float) -> None:
        score_a = min(max(float(score_a), 0.0), 1.0)
        pa = self.probability(a, b)
        ra = self.get(a)
        rb = self.get(b)
        k = 24.0
        ra.rating = ra.rating + k * (score_a - pa)
        rb.rating = rb.rating + k * ((1.0 - score_a) - (1.0 - pa))
        ra.rd = max(30.0, ra.rd * 0.98)
        rb.rd = max(30.0, rb.rd * 0.98)