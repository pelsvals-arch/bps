"""Personal bet journal: records, settles, and reports real money bets."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from betdash.db.repository import Repository

logger = logging.getLogger(__name__)


class BetJournal:
    def __init__(self, repo: Repository):
        self.repo = repo

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def current_bankroll(self) -> float:
        with self.repo.connection() as conn:
            row = conn.execute("SELECT amount FROM bankroll WHERE id = 1").fetchone()
        return float(row["amount"]) if row else 0.0

    def _set_bankroll(self, amount: float) -> None:
        with self.repo.connection() as conn:
            conn.execute(
                "UPDATE bankroll SET amount = ?, updated_at = ? WHERE id = 1",
                (float(amount), self._now()),
            )
            conn.commit()

    def open_positions(self) -> list[dict[str, Any]]:
        with self.repo.connection() as conn:
            rows = conn.execute(
                "SELECT * FROM bets WHERE settled_at IS NULL ORDER BY placed_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def place(
        self,
        prediction_id: str,
        stake: float,
        odds_taken: float,
        bookmaker: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        """Record a real bet. Stake is subtracted from bankroll immediately."""
        if stake <= 0:
            raise ValueError("stake must be > 0")
        if odds_taken <= 1.0:
            raise ValueError("odds must be > 1.0")

        with self.repo.connection() as conn:
            pred = conn.execute(
                """
                SELECT prediction_id, event_uid, market, line, outcome, bookmaker
                FROM predictions WHERE prediction_id = ?
                """,
                (prediction_id,),
            ).fetchone()
        if pred is None:
            raise ValueError(f"prediction_id {prediction_id} not found")

        bankroll_before = self.current_bankroll()
        if stake > bankroll_before:
            raise ValueError(
                f"stake {stake} exceeds bankroll {bankroll_before}"
            )
        bankroll_after = bankroll_before - stake

        bet = {
            "bet_id": str(uuid4()),
            "prediction_id": prediction_id,
            "event_uid": pred["event_uid"],
            "market": pred["market"],
            "line": pred["line"],
            "outcome": pred["outcome"],
            "stake": float(stake),
            "odds_taken": float(odds_taken),
            "bookmaker": bookmaker or pred["bookmaker"],
            "placed_at": self._now(),
            "settled_at": None,
            "result": None,
            "pnl": None,
            "bankroll_before": bankroll_before,
            "bankroll_after": bankroll_after,
            "notes": notes,
        }
        with self.repo.connection() as conn:
            conn.execute(
                """
                INSERT INTO bets(bet_id, prediction_id, event_uid, market, line, outcome,
                                 stake, odds_taken, bookmaker, placed_at, settled_at, result,
                                 pnl, bankroll_before, bankroll_after, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, ?, ?, ?)
                """,
                (
                    bet["bet_id"], bet["prediction_id"], bet["event_uid"], bet["market"],
                    bet["line"], bet["outcome"], bet["stake"], bet["odds_taken"],
                    bet["bookmaker"], bet["placed_at"], bet["bankroll_before"],
                    bet["bankroll_after"], bet["notes"],
                ),
            )
            conn.commit()
        self._set_bankroll(bankroll_after)
        return bet

    def settle(self, bet_id: str, won: bool, notes: str | None = None) -> dict[str, Any]:
        with self.repo.connection() as conn:
            row = conn.execute("SELECT * FROM bets WHERE bet_id = ?", (bet_id,)).fetchone()
        if row is None:
            raise ValueError(f"bet {bet_id} not found")
        if row["settled_at"] is not None:
            raise ValueError(f"bet {bet_id} already settled")

        stake = float(row["stake"])
        odds = float(row["odds_taken"])
        pnl = (odds - 1.0) * stake if won else -stake
        bankroll_before = self.current_bankroll()
        bankroll_after = bankroll_before + (stake + pnl if won else 0.0)

        settled_at = self._now()
        with self.repo.connection() as conn:
            conn.execute(
                """
                UPDATE bets SET settled_at = ?, result = ?, pnl = ?,
                                bankroll_after = ?, notes = COALESCE(?, notes)
                WHERE bet_id = ?
                """,
                (settled_at, 1 if won else 0, pnl, bankroll_after, notes, bet_id),
            )
            conn.commit()
        self._set_bankroll(bankroll_after)
        return {**dict(row), "settled_at": settled_at, "result": 1 if won else 0,
                "pnl": pnl, "bankroll_after": bankroll_after}

    def report(self) -> dict[str, Any]:
        with self.repo.connection() as conn:
            rows = conn.execute(
                "SELECT * FROM bets WHERE settled_at IS NOT NULL ORDER BY settled_at"
            ).fetchall()

        n = len(rows)
        if n == 0:
            return {"n_bets": 0, "bankroll": self.current_bankroll(), "message": "no settled bets"}

        total_stake = sum(float(r["stake"]) for r in rows)
        total_pnl = sum(float(r["pnl"] or 0) for r in rows)
        wins = sum(1 for r in rows if r["result"] == 1)
        roi = total_pnl / total_stake if total_stake > 0 else None

        equity = [float(rows[0]["bankroll_before"])]
        for r in rows:
            equity.append(float(r["bankroll_after"]))
        peak = equity[0]
        max_dd = 0.0
        for v in equity:
            peak = max(peak, v)
            if peak > 0:
                max_dd = max(max_dd, (peak - v) / peak)

        with self.repo.connection() as conn:
            clv_rows = conn.execute(
                """
                SELECT p.clv FROM bets b
                JOIN predictions p ON p.prediction_id = b.prediction_id
                WHERE b.settled_at IS NOT NULL AND p.clv IS NOT NULL
                """
            ).fetchall()
        clvs = [float(r["clv"]) for r in clv_rows if r["clv"] is not None]
        avg_clv = sum(clvs) / len(clvs) if clvs else None
        pos_clv_pct = sum(1 for c in clvs if c > 0) / len(clvs) if clvs else None

        return {
            "n_bets": n,
            "wins": wins,
            "hit_rate": wins / n,
            "total_staked": total_stake,
            "total_pnl": total_pnl,
            "roi": roi,
            "max_drawdown": max_dd,
            "avg_clv": avg_clv,
            "positive_clv_pct": pos_clv_pct,
            "bankroll": self.current_bankroll(),
        }
