"""CLI entry point for betdash."""
from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

import typer

from betdash.config import Settings
from betdash.db.repository import Repository

app = typer.Typer(help="betdash personal betting/research system")


def _repo() -> Repository:
    return Repository(Settings().db_path)


@app.command("check")
def check_cmd() -> None:
    """Print system status JSON."""
    settings = Settings()
    repo = Repository(settings.db_path)
    with repo.connection() as conn:
        adapters = [dict(r) for r in conn.execute("SELECT * FROM adapter_health ORDER BY bookmaker").fetchall()]
        preds = conn.execute("SELECT COUNT(*) c FROM predictions").fetchone()["c"]
        snaps = conn.execute("SELECT COUNT(*) c FROM odds_snapshots").fetchone()["c"]
    typer.echo(json.dumps({
        "ok": True,
        "workers_started": False,
        "adapters": adapters,
        "training": {"started": False, "last_run_id": None},
        "predictions": preds,
        "snapshots": snaps,
        "db_path": settings.db_path,
    }, default=str))


@app.command("tray")
def tray_cmd(no_autostart_dashboard: bool = typer.Option(False, "--no-autostart-dashboard")) -> None:
    from betdash.app.tray import TrayController
    TrayController(Settings(), autostart_dashboard=not no_autostart_dashboard).run()


@app.command("refresh-closing")
def refresh_closing_cmd() -> None:
    from betdash.backtest.closing import refresh_closing_lines
    n = refresh_closing_lines(_repo())
    typer.echo(f"closing lines refreshed: {n}")


@app.command("refresh-clv")
def refresh_clv_cmd() -> None:
    from betdash.backtest.clv import backfill_clv
    n = backfill_clv(_repo())
    typer.echo(f"clv backfilled: {n}")


@app.command("clv")
def clv_cmd() -> None:
    from betdash.backtest.clv import clv_report
    typer.echo(json.dumps(clv_report(_repo(), min_samples=20), indent=2, default=str))


@app.command("signals")
def signals_cmd(limit: int = 20, min_edge: float = 0.03) -> None:
    repo = _repo()
    with repo.connection() as conn:
        rows = conn.execute("""
            SELECT prediction_id, event_uid, market, line, outcome, model_prob, odds_decimal, clv
            FROM predictions WHERE odds_decimal IS NOT NULL AND model_prob > 0
            ORDER BY observed_at DESC, model_prob DESC LIMIT 2000
        """).fetchall()
    seen, out = set(), []
    for r in rows:
        key = (r["event_uid"], r["market"], r["line"], r["outcome"])
        if key in seen: continue
        seen.add(key)
        odds = float(r["odds_decimal"])
        if odds <= 1: continue
        implied = 1.0 / odds
        edge = float(r["model_prob"]) - implied
        if edge >= min_edge:
            out.append({"prediction_id": r["prediction_id"], "event": r["event_uid"], "market": r["market"],
                        "line": r["line"], "outcome": r["outcome"], "model_p": round(float(r["model_prob"]), 4),
                        "market_implied": round(implied, 4), "edge_pct": round(edge * 100, 2), "odds": odds, "clv": r["clv"]})
        if len(out) >= limit: break
    typer.echo(json.dumps(out, indent=2, default=str))


@app.command("bet")
def bet_cmd(prediction_id: str, stake: float, odds: float, bookmaker: Optional[str] = None, notes: Optional[str] = None) -> None:
    from betdash.bets.journal import BetJournal
    b = BetJournal(_repo()).place(prediction_id, stake, odds, bookmaker, notes)
    typer.echo(f"placed {b['bet_id']} stake={stake} odds={odds} bankroll={b['bankroll_after']:.2f}")


@app.command("settle")
def settle_cmd(bet_id: str, won: bool = typer.Option(..., "--won/--lost"), notes: Optional[str] = None) -> None:
    from betdash.bets.journal import BetJournal
    b = BetJournal(_repo()).settle(bet_id, won, notes)
    typer.echo(f"settled {bet_id} result={'win' if won else 'loss'} pnl={b['pnl']:.2f} bankroll={b['bankroll_after']:.2f}")


@app.command("pending")
def pending_cmd() -> None:
    from betdash.bets.journal import BetJournal
    typer.echo(json.dumps(BetJournal(_repo()).open_positions(), indent=2, default=str))


@app.command("report")
def report_cmd() -> None:
    from betdash.bets.journal import BetJournal
    typer.echo(json.dumps(BetJournal(_repo()).report(), indent=2, default=str))


@app.command("set-bankroll")
def set_bankroll_cmd(amount: float) -> None:
    from betdash.bets.journal import BetJournal
    BetJournal(_repo())._set_bankroll(amount)
    typer.echo(f"bankroll set to {amount:.2f}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--tray", action="store_true")
    parser.add_argument("--no-autostart-dashboard", action="store_true")
    parser.add_argument("--ingest-tennis")
    parser.add_argument("--create-missing-events", action="store_true")
    args, remaining = parser.parse_known_args(list(sys.argv[1:] if argv is None else argv))

    if args.check:
        check_cmd()
        return 0
    if args.tray:
        tray_cmd(no_autostart_dashboard=args.no_autostart_dashboard)
        return 0
    if args.ingest_tennis:
        from betdash.results.ingest import ingest_tennis_results_report

        settings = Settings()
        repo = Repository(settings.db_path)
        report = ingest_tennis_results_report(
            args.ingest_tennis, repo, create_missing_events=bool(args.create_missing_events)
        )
        payload = report.as_dict()
        payload["db_path"] = settings.db_path
        payload["create_missing_events"] = bool(args.create_missing_events)
        print(json.dumps(payload, default=str, ensure_ascii=False, indent=2))
        return 0
    if remaining:
        app(args=remaining)
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
