"""Live data clients."""

from betdash.live.sofascore import fetch_live_events, fetch_live_events_cached

__all__ = ["fetch_live_events", "fetch_live_events_cached"]
