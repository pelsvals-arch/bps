"""Tiny public SofaScore live-events client (no API key)."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from typing import Any
from urllib.request import urlopen

BASE_URL = "https://api.sofascore.com/api/v1"
_TIMEOUT = 5
_SUPPORTED = {"tennis"}
_LIVE_CACHE: dict[str, tuple[float, list[dict[str, Any]]]] = {}


def _clear_live_cache() -> None:
    _LIVE_CACHE.clear()


def _name(team: dict[str, Any]) -> str:
    translations = team.get("fieldTranslations") or {}
    translated = (translations.get("nameTranslation") or {}).get("ru")
    return str(translated or team.get("name") or "")


def _row(event: dict[str, Any]) -> dict[str, Any]:
    event_id = event.get("id")
    start = event.get("startTimestamp")
    start_at = (
        datetime.fromtimestamp(int(start), timezone.utc).isoformat()
        if isinstance(start, (int, float)) or str(start or "").isdigit()
        else ""
    )
    return {
        "event_id": event_id,
        "start_at": start_at,
        "home": _name(event.get("homeTeam") or {}),
        "away": _name(event.get("awayTeam") or {}),
        "home_score": (event.get("homeScore") or {}).get("current"),
        "away_score": (event.get("awayScore") or {}).get("current"),
        "status": str((event.get("status") or {}).get("description") or ""),
        "tournament": str((event.get("tournament") or {}).get("name") or ""),
        "url": f"https://www.sofascore.com/event/{event_id}",
    }


def _load_live_events(sport: str, opener: Any) -> list[dict[str, Any]]:
    if str(sport).casefold() not in _SUPPORTED:
        return []
    url = f"{BASE_URL}/sport/{sport}/events/live"
    with opener(url, timeout=_TIMEOUT) as response:
        payload = json.loads(response.read().decode("utf-8"))
    events = payload.get("events") or []
    return [_row(event) for event in events if isinstance(event, dict)]


def fetch_live_events(sport: str, opener: Any = urlopen) -> list[dict[str, Any]]:
    """Fetch live events, returning an empty list on any network/parse error."""
    try:
        return _load_live_events(sport, opener)
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        return []


def _now_value(now: Any) -> float:
    if now is None:
        return time.monotonic()
    if callable(now):
        return float(now())
    return float(now)


def _cached_rows(rows: list[dict[str, Any]], stale: bool) -> list[dict[str, Any]]:
    return [dict(row, _stale=stale) for row in rows]


def fetch_live_events_cached(
    sport: str,
    opener: Any = urlopen,
    ttl_seconds: float = 30,
    max_fallback_age_seconds: float = 300,
    now: Any = None,
) -> list[dict[str, Any]]:
    """Fetch live events with a short TTL and a bounded last-good fallback."""
    key = str(sport).casefold()
    current = _now_value(now)
    ttl = max(0.0, float(ttl_seconds))
    max_fallback_age = max(0.0, float(max_fallback_age_seconds))
    cached = _LIVE_CACHE.get(key)
    if cached is not None and current - cached[0] < ttl:
        return _cached_rows(cached[1], False)
    try:
        rows = _load_live_events(sport, opener)
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        if cached is not None and current - cached[0] <= ttl + max_fallback_age:
            return _cached_rows(cached[1], True)
        return []
    stored = _cached_rows(rows, False)
    _LIVE_CACHE[key] = (current, stored)
    return _cached_rows(stored, False)
