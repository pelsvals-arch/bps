"""Generate bookmaker aliases from Sackmann player names."""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

from betdash.db.repository import Repository

DEFAULT_ALIAS_PATH = Path(__file__).resolve().parent / "sackmann_aliases.json"


def sackmann_alias_variants(name: str) -> set[str]:
    """Return common club/bookmaker spellings for a canonical player name."""
    parts = str(name or "").strip().split()
    if len(parts) < 2:
        return {str(name).strip()} if str(name).strip() else set()
    first, last = parts[0], parts[-1]
    return {
        f"{first} {last}",
        f"{first[0]} {last}",
        f"{first[0]}. {last}",
        f"{last} {first}",
        f"{last} {first[0]}",
        f"{last} {first[0]}.",
        last,
        f"{last}{first[0]}",
        f"{last}{first[0]}.",
    }


def _sackmann_player_counts(repo: Repository) -> list[tuple[str, int]]:
    with sqlite3.connect(repo.path) as conn:
        rows = conn.execute(
            """
            SELECT name, COUNT(*) FROM (
                SELECT winner_name AS name FROM sackmann_matches
                UNION ALL SELECT loser_name AS name FROM sackmann_matches
            ) WHERE name IS NOT NULL AND TRIM(name) <> ''
            GROUP BY name ORDER BY COUNT(*) DESC, name
            """
        ).fetchall()
    return [(str(name).strip(), int(count)) for name, count in rows]


def generate_sackmann_aliases(
    repo: Repository, limit: int | None = None
) -> dict[str, list[str]]:
    """Build canonical Sackmann name -> sorted alias list."""
    counts = _sackmann_player_counts(repo)
    if limit is not None:
        counts = counts[: max(0, int(limit))]
    return {name: sorted(sackmann_alias_variants(name)) for name, _ in counts}


def write_sackmann_aliases(
    repo: Repository,
    path: str | Path | None = None,
    limit: int | None = None,
) -> Path:
    """Write generated aliases while preserving existing manual overrides."""
    target = Path(path) if path is not None else DEFAULT_ALIAS_PATH
    existing: dict[str, list[str]] = {}
    if target.exists():
        try:
            loaded = json.loads(target.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                existing = {
                    str(k): [str(v) for v in values]
                    for k, values in loaded.items()
                    if isinstance(values, list)
                }
        except (OSError, ValueError):
            existing = {}
    aliases = generate_sackmann_aliases(repo, limit=limit)
    for canonical, manual in existing.items():
        if canonical not in aliases:
            continue
        aliases[canonical] = sorted(set(aliases[canonical]) | set(manual))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(aliases, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    # Imported lazily: both modules import this one during startup.
    from betdash.analytics.prediction_links import clear_alias_cache
    from betdash.models.features import clear_sackmann_alias_cache

    clear_alias_cache()
    clear_sackmann_alias_cache()
    return target


def main(argv: list[str] | None = None) -> int:
    """Regenerate the Sackmann alias file from the configured database."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", help="SQLite database path")
    parser.add_argument("--output", help="Alias JSON output path")
    parser.add_argument("--limit", type=int, default=5000, help="Number of frequent players")
    args = parser.parse_args(argv)
    from betdash.config import Settings

    db_path = args.db or Settings().db_path
    target = Path(args.output) if args.output else DEFAULT_ALIAS_PATH
    write_sackmann_aliases(Repository(str(db_path)), target, limit=args.limit)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
