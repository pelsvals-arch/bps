# Downloaded agent skills

Curated from the three catalogues reviewed on 2026-11-27:

- <https://cursor.directory/>
- <https://opencode.im/categories/mcp-integrations>
- <https://www.kimi.ai/ru/resources/opencode-skills>

Only tools that fill a real gap in this project were installed. Skills already
available in this OpenCode environment were not duplicated.

## Installed

| Skill | Source | Why |
|---|---|---|
| `architecture-diagram` | [Cocoon-AI/architecture-diagram-generator](https://github.com/Cocoon-AI/architecture-diagram-generator) | Generates self-contained HTML/SVG architecture diagrams for `docs/` and review packages. MIT. |
| `contextual-commits` | [berserkdisruptors/contextual-commits](https://github.com/berserkdisruptors/contextual-commits) | Preserves intent, decisions, rejected alternatives and constraints in commit bodies, so later sessions do not re-litigate them. MIT. |

## Reviewed and skipped

| Candidate | Reason |
|---|---|
| Understand-Anything | Overlaps with the already-installed `graphify`; 56 MB and token-heavy. |
| Deep-Research skills | Already installed (`research`, `research-deep`, `research-report`, ...). |
| Skill Optimizer | Already installed (`skill-miner`, `skill-personalizer`, `skill-generalizer`). |
| Awesome Agent Skills | Catalogue, not a tool. Its relevant DuckDB, Firecrawl, Playwright and webapp-testing entries are already installed. |
| SuperPM, Cortex, Agent Smith, Agent Skills Framework | Generic product/agent frameworks, not betting or data work. |
| Cursor Data Analyst / Python / Web Scraping rules | Generic IDE rule text; the project already has stronger TDD, data and browser skills. |
| OpenCode.im Exa search | Requires an API key; Firecrawl and `websearch` already cover research. |
| OpenCode.im Playwright / Chromium | Redundant with the built-in `browse` browser and `webapp-testing`. |
| OpenCode.im Context7 | Already configured as an MCP server. |
| OpenCode.im agent-steward | Redundant with the built-in `automation` tool. |
| OpenCode.im Composio | Requires a consumer key and external accounts. |

No betting- or sports-odds-specific MCP/skill was present in these catalogues.
The live-score path remains the SofaScore API plus the existing bookmaker
adapters.
