---
name: contextual-commits
description: Write git commit messages that preserve the reasoning behind a change. Use when committing code, especially after a long agent session, so future sessions inherit intent, decisions, rejected alternatives, constraints, and non-obvious learnings instead of only the diff.
---

# Contextual Commits

Extend Conventional Commits with typed action lines in the commit body. The
subject says **what** changed; the body says **why** and what was ruled out.

Read `SPEC.md` for the full v0.1.0 rules and grammar.

## Format

```text
type(scope): subject

intent(scope): what the user wanted and why
decision(scope): what was chosen when alternatives existed
rejected(scope): what was discarded — and why
constraint(scope): a hard limit that shaped the implementation
learned(scope): a non-obvious fact that prevents a future mistake
```

Use only the lines that carry signal the diff cannot show. A typo fix needs
none. Never invent context you cannot support from the session or the code.

## Rules that matter most

- The subject line MUST remain a valid Conventional Commit.
- Action lines go in the body, one per line, after the blank line.
- `scope` is lowercase alphanumeric plus hyphens, and consistent across commits.
- `rejected` MUST include the reason.
- Do not restate what the diff already shows.
- When prior context is unavailable, only `decision` may be inferred from a
  clear technical choice. Do not fabricate `intent`, `rejected`, `constraint`,
  or `learned`.

## Project use

This repository already uses TDD and ledger rulings. Put the durable decisions
from the ledger into the commit body so they survive session compaction:

```text
fix(tennis): preserve unknown players in Sackmann lookup

intent(tennis): keep bookmaker names usable when no alias exists
decision(tennis): fall back to the normalized input name instead of None
rejected(tennis): raising on unknown players — one unknown name should not
  discard the whole event's features
learned(tennis): stats keys are normalized Sackmann names, so aliases must
  resolve to that same normalized form
```
