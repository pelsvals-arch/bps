# Collector throughput and endpoint spike design

> Status: approved by user; user chose A+B and said «делай».

## Intent

User approved priorities A and B: first speed up the current collector without changing data sources, then run a narrow Winline/Fonbet endpoint spike to see whether hidden delta/WebSocket endpoints can reduce polling further.

## Current state

`Collector.poll_once()` holds a global lock, fetches adapters sequentially, normalizes each `RawOdd` one by one, calls `upsert_canonical_event()` inside the normalization loop, and calls `save_snapshots()` once per adapter. Scheduler polling is 90 seconds. `if raw.is_live: continue` remains unchanged.

## Goals

1. Fetch adapters concurrently with a bounded `ThreadPoolExecutor`.
2. Normalize and write snapshots in batches, with one canonical-event upsert per unique event.
3. Preserve deterministic snapshot ordering and current tennis-only normalization.
4. Add tests proving concurrency, batching and deduplication.
5. Document a bounded Winline/Fonbet endpoint spike without making mobile apps a runtime dependency.

## Non-goals

- No mobile emulator, Frida, cert-pinning bypass or account credentials in runtime.
- No paid API.
- No live odds ingestion or live prediction model.
- No change to adapter fetch semantics beyond calling them concurrently.

## Approaches

- A: optimize current pipeline. Safe, no new dependency, immediate latency reduction. Recommended first.
- B: one-off endpoint spike. Potentially larger gain, but uncertain and per-book; done after A.
- C: mobile app as runtime source. Rejected: likely same backend, ToS/pinning risk, no stable contract.

## Decisions

1. Default `max_workers = min(4, len(adapters))`; preserve adapter order when merging fetched snapshots.
2. Fetch failures remain isolated per adapter and are recorded in adapter health as today.
3. Canonical events are collected into a dict keyed by `event_uid`, then upserted once per unique event.
4. Snapshots are written in one `save_snapshots()` call for the whole poll after all fetches complete.
5. Duplicate snapshots are removed by stable key before saving.
6. B spike is read-only R&D: compare public reverse-engineered endpoints against current adapter output for one event; if blocked or unstable, record the finding and stop.

## Verification

- RED→GREEN tests with fake adapters, fake repository and timing/event barriers.
- Full suite green before commit.
- Spike output written to `docs/research/2026-11-27-collector-endpoint-spike.md` only if it produces verified evidence.
