# Review-driven hardening design

Дата: 2026-11-28

## Intent and why

Свежие ревью Qwen и DeepSeek показали, что главная проблема — не отсутствие моделей, а разорванный контур: сохранённые прогнозы не имеют совпадающих результатов, score parser не везде используется, а surface/best_of и алиасы игроков не доходят до score-engine. Нужно починить контур измерения качества, затем улучшать модели.

## Goals

- Автоматически строить алиасы Sackmann для bookmaker-имен.
- Связывать predictions с results по каноническим участникам и дате.
- Использовать `parse_tennis_score`/`resolve_tennis_market` вместо старого `winner_side_from_score`.
- Передавать `surface` и `best_of` в score-engine_context.
- Сделать Markov serve-aware и устранить O(n²) в blend weight.
- Зафиксировать поддерживаемую версию Python.

## Non-goals

- Не добавлять live-кэфы и in-play ставки.
- Не менять CLV/closing логику.
- Не возвращать не-теннисные дисциплины.
- Не использовать платные API.

## Approaches

1. Исправить только модели — rejected: метрики останутся пустыми.
2. Исправить контур данных, затем модели — выбрано:результаты станут измеримыми, а улучшения — проверяемыми.
3. Полная замена pipeline — rejected: слишком рискованно.

## Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD: production change только после красного теста.
- Existing tests and public APIs stay green; no new runtime dependencies.
- Docs and answers in Russian.

## Decisions

1. **Aliases.** Generate `normalize/sackmann_aliases.json` from distinct Sackmann names using `F Last`, `F. Last`, `Last F`, `Last F.`, preserving hand overrides.
2. **Outcome link.** Add `prediction_result_links(prediction_event_uid, result_event_uid, confidence, PRIMARY KEY(...))`; match by normalized participant pair and UTC date. `backfill_prediction_outcomes()` uses linked results when direct event_uid match is absent.
3. **Score parser.** Replace score-derived winner decisions in four call sites with `parse_tennis_score` + `resolve_tennis_market`; keep the old helper only as fallback.
4. **Context.** Add `surface` and `best_of` to feature context from Sackmann result rows and use them in empirical/Markov providers.
5. **Markov.** Use separate `p1_hold`/`p2_hold` probabilities from serve stats; tiebreak as a separate state; keep deterministic simulation.
6. **Performance.** Reuse one `_walk_forward_oof_rows` pass; index blend pairs by event_uid instead of nested scans.
7. **Python.** Pin `requires-python = ">=3.12,<3.13"`.

## What is left to the builder

Implementation plan with seven TDD tasks and one verification task.
