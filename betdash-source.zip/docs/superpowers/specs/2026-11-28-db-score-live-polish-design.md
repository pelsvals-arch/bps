# DB boundary, score-market and live-cache polish design

## Intent

Пользователь выбрал порядок `A>B>C делай` после ревью Z.ai и cross-engine проверок.

- **A**: убрать зависимость runtime-кода от приватного `Repository._connect()` и дублирование DDL.
- **B**: показывать канонический рынок в score-derived markets.
- **C**: кэшировать публичный SofaScore live-ответ на короткий TTL и сохранять последний удачный результат при сетевой ошибке.

## Goals

- Публичный способ открывать соединение с БД — `Repository.connection()`.
- DDL `prediction_result_links` живёт только в `db/schema.sql`.
- В UI score-рынков видно канонический рынок для алиасов `total_points` и `spread`.
- Live scoreboard не запрашивает SofaScore на каждый rerun и не очищается при одной временной ошибке.

## Non-goals

- Не менять прогнозную модель, веса и калибровку.
- Не добавлять платные API, live-кэфы БК и in-play модель.
- Не трогать посторонние незакоммиченные файлы в worktree.
- Не менять tennis-only инварианты и московское время.

## Constraints

- Работа в `.worktrees/impl`, ветка `impl`.
- TDD RED→GREEN для каждой задачи.
- Полный `pytest` зелёный перед каждым коммитом.
- Публичный live API остаётся неофициальным и без ключа.

## Decisions

1. `connection()` становится настоящим `@contextmanager`; `_connect()` остаётся только как обратная совместимость внутри `Repository`.
2. Все вызовы вне `Repository` используют `repo.connection()`.
3. Runtime-создание `prediction_result_links` удаляется: `init_db()` уже исполняет `schema.sql`.
4. Score-рынки сохраняют исходный `market` и добавляют `market_canonical`.
5. Live-кэш хранит последний удачный ответ по спорту; TTL по умолчанию 30 секунд; при ошибке возвращается последний удачный ответ.

## Verification

- Статический тест: вне `db/repository.py` нет `_connect()`.
- Функциональный тест: legacy БД получает `prediction_result_links` через `init_db()`.
- Тесты score-market для `total_points`/`spread` и канонического имени.
- Тесты live-cache: hit, TTL, error fallback.
- Полный suite и smoke health дашборда.
