# Weighted and surface-aware Elo — design

Date: 2026-11-27
Status: черновик на утверждение
Follows: `2026-11-27-tennis-only-design.md`

## Intent

После tennis-only чистки улучшить tennis-прогнозы за счёт двух вещей, которые уже подтверждены Sackmann-данными и не требуют внешних API: учитывать маржу победы в Elo (WElo) и делать поверхностный Elo/Cross-surface blend явной фичей модели.

## Why

Сейчас trainer обновляет Elo только по факту победы/поражения, поэтому разгром `6-0 6-0` и тай-брейк `7-6 7-6` дают одинаковый сдвиг рейтинга. При этом Sackmann-фичи уже считают surface Elo и `elo_blend`, но модель получает их как отдельные значения `p1_*`/`p2_*`, без явной разницы. Для тенниса это теряет сигнал о качестве победы и о пригодности игрока к конкретному покрытию.

## Goals

1. `EloRating` поддерживает margin-weighted update.
2. Trainer извлекает маржу из счёта результата и передаёт её в update.
3. `build_features()` возвращает явные diff-фичи для surface Elo и blended Elo.
4. `FEATURES_VERSION` повышается, чтобы stale checkpoint не подмешивал старые rating-состояния.
5. Тесты RED→GREEN, полный suite зелёный.

## Non-goals

- Market prior blending (это шаг C).
- OOF-оценка и калибровка (это шаг A).
- Новые данные, внешние API, MCP, live-кэфы.
- Замена Elo/Glicko на другую рейтинговую модель.
- Изменение Sackmann ingest или схемы БД.

## Anti-goals

- Сделать WElo-вес настолько большим, чтобы рейтинги расходились на коротких сериях.
- Добавить фичи с утечкой будущего: все значения считаются только по матчам до `start_at`.
- Трогать посторонние untracked-файлы.

## Constraints

- Worktree `.worktrees/impl`, ветка `impl`.
- TDD: каждый production change подтверждён упавшим тестом.
- Полный `pytest` зелёный.
- Имена фич стабильны и добавляются, а не переименовывают существующие.

## Approaches

### A. WElo + явные surface diff-фичи (chosen)

Добавить вес маржи в `EloRating.update()` и передавать его из trainer. Добавить diff-фичи surface/blend Elo в `build_features()`. Это минимальное изменение, которое использует уже загруженные данные и делает сигнал доступным логистической регрессии.

### B. Только surface Elo из Sackmann

Surface Elo уже считается в `features.py`; повторно добавлять его бессмысленно. Отклонено: не даёт нового сигнала apart от уже существующих `p1_surface_elo`/`p2_surface_elo`.

### C. Заменить Elo на Glicko/Bradley–Terry

Более сложная модель, но без OOF-оценки (шаг A) нельзя доказать, что она лучше. Отклонено: преждевременная сложность.

## Decisions

1. **WElo-вес.** `weight = clamp(1 + 0.15 * margin, 0.75, 2.0)`, где `margin` — разница выигранных/проигранных геймов, считаемая из счёта; при пустом/неразбираемом счёте `weight = 1.0`. Кэп 2.0 защищает от выбросов вроде `6-0 6-0`.
2. **Маржа из existing score parser.** Используется `BacktestEngine.winner_side_from_score()` и отдельный helper для разбора геймов; при неоднозначном счёте вес нейтральный.
3. **Diff-фичи.** Добавляются `p1_surface_elo_diff`, `p2_surface_elo_diff`, `p1_elo_blend_diff`, `p2_elo_blend_diff` как `mine - other`; существующие абсолютные фичи остаются.
4. **Features version.** `FEATURES_VERSION` меняется на `baseline-v2`, чтобы trainer пересобрал состояния и не смешал старые веса.
5. **Glicko не меняется.** Он остаётся вторым baseline-источником; WElo применяется только к Elo, чтобы изолировать эффект.

## How it will be done

- `src/betdash/models/baseline.py`: `EloRating.update(a, b, score_a, *, weight=1.0)`.
- `src/betdash/models/trainer.py`: helper `_score_margin(score) -> float`; `_collect_new_rows()` передаёт `weight` в `er.update(...)`; bump `FEATURES_VERSION`.
- `src/betdash/models/features.py`: четыре diff-фичи на основе уже считаемых `elo_hard/clay/grass`, `surface_elo`, `elo_blend`.
- Tests: WElo update changes rating more for dominant win; invalid score uses neutral weight; diff features expose `mine - other`; full suite green.
- After B, step C (market prior blending) and step A (OOF evaluation) are separate designs/plans.

## What is left to the builder

Разбить на задачи в плане: сначала Elo/weight helper, затем diff-фичи и version bump, затем полный прогон и коммит. Точные границы тестов определяет план.
