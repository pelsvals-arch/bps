# Live cache and forecast quality design

**Status:** approved by user choice `A>C` on 2026-11-28.

## Intent

Harden the live scoreboard cache and make forecast quality measurable from the real database, without claiming stored predictions are out-of-sample.

## Goals

- Live cache uses a monotonic clock and returns copies, not internal mutable rows.
- Failed refresh reuses last-good rows only within a bounded fallback window and marks them stale.
- Dashboard shows a stale warning for fallback rows.
- Legacy databases missing `prediction_result_links` are repaired by `init_db()` and can then link predictions to results.
- Report computes Brier/log-loss for settled stored predictions and compares model with market implied probabilities when both outcomes are available.
- Report is explicitly labelled as historical settled predictions, not guaranteed OOF.

## Non-goals

- No paid data source, live odds, in-play model, CLI rewrite, retraining, or calibration change.
- Existing unrelated dirty tracked files are not part of this work.

## Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD: every production change has a failing test first.
- Full `pytest` suite stays green.
- `fetch_live_events()` stays backward compatible.

## Decisions

### A — live cache

- Keep `_LIVE_CACHE` keyed by normalized sport.
- Cache entry stores monotonic timestamp and rows.
- Default clock is `time.monotonic()`; injected `now` remains available for tests.
- Fallback on refresh error is allowed only while `current - cached_at <= ttl_seconds + max_fallback_age_seconds` (default 300s), otherwise return `[]`.
- Fresh rows are marked `_stale = False`; fallback rows `_stale = True`.
- All returned rows are shallow copies.

### C — forecast quality

- New `analytics/forecast_quality.py` with `forecast_quality_report(repo)`.
- It runs `link_prediction_results()` and `backfill_prediction_outcomes()`, then reads `prediction_outcomes`.
- Model Brier/log-loss uses `calibration_report()`.
- Market probability is derived from paired `odds_decimal` values by normalizing `1/odds` across the two outcomes; incomplete pairs are excluded from market comparison.
- Report includes `sample_type="historical_settled_predictions_not_oof"` and a warning string.

## Verification

Targeted tests, full suite, Streamlit health, and no changes to unrelated dirty files.
