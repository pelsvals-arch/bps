# Tennis-only focus — design

Date: 2026-11-27
Status: draft for approval
Supersedes: four-sport scope of `2026-11-26-betting-dashboard-design.md`

## Intent

Сфокусироваться на одном виде спорта — теннисе. Пользователь хочет оставить только данные и код, связанные с теннисом, чтобы остальные данные не мешали и чтобы оптимизации и ошибки в анализе и прогнозировании стали более явными. Ближайшая цель — **не «победить рынок»**, а получить чистый tennis-only проект, в котором быстрее видны причины ошибок и эффект изменений.

## Why

Сейчас проект одновременно обрабатывает tennis, basketball, dota2 и cs2. Это размывает диагностику: метрики, CLV, фичи и дашборд смешивают дисциплины с разной динамикой и разным качеством данных. После P0–P3 стало ясно, что даже честный CLV искажён историческими не-теннисными снапшотами, а калибровка заблокирована несовпадением прогнозов и результатов. Узкий фокус делает эти эффекты наблюдаемыми.

## Goals

1. Рабочая БД содержит только tennis-данные; не-теннисные строки удалены.
2. Код принимает и выдаёт только tennis: адаптеры, нормализация, trainer, backtest, dashboard.
3. Тесты и фикстуры описывают только tennis-сценарии.
4. Полный `pytest` зелёный после чистки.
5. Архив не-теннисных данных существует только до верификации и затем удаляется.

## Non-goals

- Новая модель, новый edge-таргет или обещание положительного ROI в этой задаче.
- Live-ingest и in-play прогнозы.
- Внешние платные API и новые MCP-интеграции.
- Удаление или перестройка `sackmann_matches` (7 501 725 матчей — чистый теннис).
- Dropping колонки `sport` из схемы: это совместимость с существующими БД и чекпоинтами.

## Anti-goals

- Оставить не-теннисные строки в рабочей БД «под фильтром».
- Оставить не-теннисные ветки в адаптерах и метриках.
- Удалить архив до зелёного прогона и DB-аудита.
- Модифицировать посторонние untracked-файлы (`bets/`, `cli.py`, code dumps, `egg-info`).

## Constraints

- Работа в worktree `.worktrees/impl`, ветка `impl`.
- TDD: каждый change подтверждён тестом, который сначала упал.
- Полный suite должен остаться зелёным.
- Архив → удаление из рабочей БД → верификация → удаление архива.
- Исторические документы сохраняются как record, но помечаются做为 superseded новым дизайном.

## Current state (audit)

| Таблица | Tennis | Не-теннис |
|---|---:|---:|
| `canonical_events` | 34 407 | 769 basketball |
| `odds_snapshots` | 4 046 748 | 1 996 356 basketball |
| `predictions` | 19 120 | 6 406 basketball |
| `results` | 32 930 | 0 |
| `closing_lines` | 9 132 | 2 968 basketball |
| `closing_lines_book` | 25 058 | 7 864 basketball |
| `events`, `participants`, `market_types`, `bets`, `feature_values`, `event_aliases` | 0 | 0 |
| `sackmann_matches` | 7 501 725 | 0 |

Есть также **65 236 `odds_snapshots` без строки в `canonical_events`** (328 событий `bettery`/`fonbet`/`pari`, 2026-11-26). Их вид спорта неопределим: sport хранится только в `canonical_events`. Dota 2 и CS2 уже отсутствуют в `canonical_events`, но их ветки остались в коде, тестах и доках.

## Approaches

### A → B (chosen)

Архивировать не-теннисные строки в отдельный SQLite-файл, удалить их из рабочей БД, сделать `VACUUM`, перевести код на tennis-only, прогнать тесты и аудит, затем удалить архив. Даёт безопасный переход и в итоге чистое состояние без лишних данных.

### B directly

Сразу удалить без архива. Меньше места и шагов, но不可逆. Отклонено: пользователь выбрал сначала A.

### C — logical isolation only

Оставить строки и фильтровать по `sport == "tennis"` в коде. Не удаляет данные, поэтому не satisfies цель «остальные данные не мешают» на уровне данных и оставляет соблазн случайно прочитать чужие строки. Отклонено.

## Decisions

1. **Архив — временный.** Он создаётся для безопасного перехода и удаляется отдельным коммитом после зелёного suite и DB-аудита. Это вариант A с запланированным переходом в B.
2. **Колонка `sport` остаётся.** Она будет всегда содержать `tennis`. Замена схемы на без-спортовую модель увеличила бы риск и не нужна для фокуса.
3. **Состояние рейтингов остаётся keyed by sport.** Формат чекпоинта не меняется, но ключ жёстко ограничивается одним `"tennis"`; сам файл чекапоинта дополнительно очищается от чужих ключей (см. п. 9).
4. **Sackmann и турниры не трогаются.** Это tennis-данные и основа будущих фич.
5. **Старый spec/plan не переписывается задним числом.** К нему добавляется note, что four-sport scope superseded этим дизайном; он остаётся историческим record.
6. **Орфанные снапшоты считаются не-теннисными.** Их 65 236, sport у них неопределим. Они попадают в архив и удаляются из рабочей БД. Аудит требует отсутствия любых `odds_snapshots.event_uid` без `canonical_events`, а не только «новых» сирот. Потеря допустима; архив даёт откат до финального удаления.
7. **Перед миграцией останавливаем писателей.** Сейчас запущен Streamlit на :8501 (PID ~128995). Останавливаем процесс, делаем `PRAGMA wal_checkpoint(TRUNCATE)`, затем архивируем/удаляем/VACUUM. После миграции поднимаем дашборд заново для smoke-теста.
8. **Убираем только реально не-теннисные рыночные ветки.** В `trainer._market_probs()` и реестре удаляются `map_winner`, `total_maps`, `map_handicap`, а также `by_sport` из CLV-отчёта. Рынки `total_points`, `total_games`, `spread`, `set_handicap` остаются: часть теннисных линий приходит именно так.
9. **Чекапоинт очищается, а не только фильтруется.** В `data/checkpoints/trainer_checkpoint.json` есть `elo`/`glicko` ключи `basketball`. Добавляется миграция: оставляем только `"tennis"` и проверяем, что чужих ключей нет.

## How it will be done

### 1. Data migration (TDD)

Новый тест на tmp SQLite:

- создаёт минимальную схему с `canonical_events`, `odds_snapshots`, `predictions`, `closing_lines`, `closing_lines_book`;
- вставляет tennis-строки, basketball-строки и снапшот с `event_uid`, отсутствующим в `canonical_events`;
- запускает `archive_and_purge_non_tennis(repo, archive_path)`;
- проверяет, что архив содержит basketball-зависимые и орфанные строки;
- проверяет, что рабочая БД содержит только tennis и не имеет сиротских `event_uid`.

Перед запуском миграции на реальной БД останавливаем Streamlit (:8501), делаем `PRAGMA wal_checkpoint(TRUNCATE)` и только затем копируем/удаляем/VACUUM. После миграции процесс поднимается заново.

Миграция копирует и удаляет dependent rows по `event_uid` из: `odds_snapshots`, `predictions`, `results`, `closing_lines`, `closing_lines_book`, `event_aliases`, `feature_values`, `bets`, `events`. `canonical_events` фильтруется по `sport != 'tennis'`; снапшоты без `canonical_events` тоже архивируются и удаляются. `sackmann_matches`, `tournaments`, `adapter_health`, `bankroll`, `model_runs` не трогаются. После удаления — `VACUUM`.

Отдельная миграция чекапоинта: `data/checkpoints/trainer_checkpoint.json` — оставляет только ключ `"tennis"` в `elo`/`glicko`, сохраняя остальные поля без изменений.

### 2. Runtime code

- `src/betdash/normalize/registry.py`: `MVP_SPORTS = {"tennis"}`; `canon_sport()` узнаёт только tennis-алиасы; всё остальное становится неизвестным видом спорта.
- Адаптеры `winline`, `marathon`, `betboom`, `json_family`:supported sports и alias tables сводятся к tennis; sport-id branches для basketball/dota/cs2 удаляются. Адаптеры остаютсяsources кэфов, но отдают только tennis.
- `ingest/collector.py`: existing `canonical_outcome()` и `is_live` branch сохраняются; не-теннисные `RawOdd` отбрасываются нормализатором.
- `models/trainer.py`: один разрешённый sport key `"tennis"`; убираются branch'и выбора sport; horizon остаётся tennis-only. Из `_market_probs()` и реестра удаляются `map_winner`, `total_maps`, `map_handicap`; `total_points`, `total_games`, `spread`, `set_handicap` остаются как tennis-рынки.
- `backtest/engine.py`: публичный `run()` работает только с tennis; явный sport-параметр удаляется или становится фиксированным `"tennis"`.
- `backtest/clv.py`: удаляется агрегация `by_sport`; отчёт становится tennis-only.
- `app/dashboard.py`: удалён selectbox «Спорт»; заголовки и сортировки — tennis-only; бэктест-лаба запускается без sport-выбора.

Конкретные сигнатуры и границы задач оставляются `writing-plans`.

### 3. Tests and fixtures

- Удалить basketball/dota/cs2/NBA кейсы из `tests/adapters/`, `tests/normalize/`, `tests/models/`, `tests/backtest/`.
- Добавить assertions, что не-теннисный `RawOdd` игнорируется.
- Обновить фикстуры adapters/fixtures до tennis-only.
- Сохранить все Sackmann/tennis feature tests.

### 4. Docs

- Новый spec — этот файл.
- В `2026-11-26-betting-dashboard-design.md` и плане добавить короткую строку: scope superseded by tennis-only design.
- README/текущие описания, если упоминают четыре дисциплины, привести к tennis-only.

### 5. Verification

- `PYTHONPATH=src .venv/bin/pytest -q` — зелёный.
- DB audit: `SELECT DISTINCT sport FROM canonical_events` → `tennis`; `COUNT(*)` по не-теннисным dependent rows → 0; `COUNT(*)` сиротских `odds_snapshots` → 0.
- Проверка чекапоинта: `elo`/`glicko` содержат только `"tennis"`.
- grep-аудит: в `src/` и `tests/` нет basketball/dota/cs2/nba/football/hockey/map_* как активных сценариев.
- Smoke: поднять заново Streamlit и убедиться, что дашборд открывается без sport selector.

### 6. Archive removal

Отдельный коммит после успешной верификации: удалить `data/archive/non-tennis-2026-11-27.sqlite`. Архив не является частью финального проекта.

## What is left to the builder

Разбить на задачи в плане: сначала тест миграции и сама миграция, затем код, затем тесты/доки, затем финальный аудит и отдельное удаление архива. Точные имена функций и коммит-границы определяются на этапе планирования.
