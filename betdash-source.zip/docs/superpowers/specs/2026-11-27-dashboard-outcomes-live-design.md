# Dashboard accuracy, live scoreboard and time design

> Status: approved by user in chat: «делай все и скорректируй в дашборде время матчей показывает непонятно что если надо выбрать часовой пояс выбирай москву».

## Intent

Пользователь хочет видеть не только прогнозы, но и их фактическую точность, текущие матчи и понятное время матчей. Сейчас в БД 2000 прогнозов, 32930 результатов, но пересечений по `event_uid` — 0; время в дашборде выводится как ISO UTC.

## Goals

1. Связать `predictions` с `results` и писать Brier/log-loss/hit-rate/CLV в таблицу `prediction_outcomes`.
2. Добавить live scoreboard SofaScore для tennis/basketball/esports без платных ключей.
3. Показывать время в дашборде в формате `dd.mm HH:MM MSK`.
4. Убрать дубли market_depth и неоднозначный `best_bookmaker`.

## Non-goals

- Не менять tennis-only ограничение для прогнозов и не добавлять платные API.
- Не сохранять live-кэфы БК; live scoreboard показывает только счёт/статус.
- Не добаввлять новые runtime-зависимости.

## Constraints

- Worktree `.worktrees/impl`, branch `impl`, TDD RED→GREEN, коммит после каждой задачи.
- `zoneinfo.ZoneInfo("Europe/Moscow")` из стандартной библиотеки.
- SofaScore endpoint: `https://api.sofascore.com/api/v1/sport/{sport}/events/live`.
- Результаты для accuracy берутся только для `match_winner`, `outcome in {p1,p2}`.

## Decisions

1. Evaluator идемпотентен: `prediction_outcomes` имеет UNIQUE по `prediction_id`, повторный запуск обновляет строки.
2. Направление результата приводится к каноническому порядку участников через `canonical_outcome`.
3. Live client не падает в дашборд: сетевые ошибки дают пустой список и health/degraded-статус.
4. Время форматируется централизованно и применяется ко всем колонкам времени в дашборде.
5. market_depth остаётся одной строкой на `(event_uid, market, line)`, но без обрезки до 20 событий и с явным `best_bookmaker` для выбранного лучшего исхода.
