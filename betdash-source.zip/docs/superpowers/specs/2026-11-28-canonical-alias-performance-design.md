# Canonical markets and aliases design

**Status:** recommended A→B→C chosen on 2026-11-28.

## Intent

Close verified gaps left after chat reviews: `game_handicap` canonicalization, stale Sackmann aliases, expensive repository connections, prediction-path result scans, and the accuracy screen not using the new measurement helpers.

## Decisions

- `game_handicap` becomes the canonical tennis market. `spread` remains an input alias; `set_handicap` remains separate.
- Trainer and market resolver must treat `game_handicap` as a supported tennis market.
- Marathon `MTCH_HB`/`MTCH_HBP` maps to `game_handicap`, not `spread`.
- Alias file is regenerated from Sackmann with common bookmaker spellings; a CLI entrypoint makes regeneration repeatable.
- `Repository.connection()` caches schema-readiness per database path so repeated connections do not rerun DDL/PRAGMA checks. Expensive backfills stay in explicit migration commands.
- Prediction generation passes `cached_results`, like ingest does.
- Accuracy screen calls link/settle/quality helpers and shows a warning when no settled predictions exist.

## Constraints

- Worktree `.worktrees/impl`, branch `impl`, TDD with failing tests first, full pytest suite green, unrelated dirty files untouched.

## Non-goals

- No CLI redesign, new paid APIs, live odds, model retraining, or changes to unrelated markets.
