# Score-engine integration design

Дата: 2026-11-28

## Intent and why

Выбрано совместное использование трёх слоёв: A — подключение эмпирического score-engine к прогнозам и дашборду, B — point-level Markov simulator, C — честная OOF-оценка accuracy и value. Все три слоя возвращают распределение по score atoms `dict[ScoreAtom, float]`, поэтому могут работать вместе как провайдеры и смесь.

Сейчас score-distribution библиотека изолирована: парсер, market resolver, эмпирическое распределение и evaluation есть, но они не влияют на прогнозы и не видны в дашборде.

## Goals

- Генерировать распределения счёта `empirical` и `markov` для tennis-событий.
- Хранить оба распределения и их смесь рядом с `model_run`/`event_uid`.
- Выводить рынки через `market_probabilities`.
- Обучать вес смеси `w` на OOF-данных по log loss/Brier, а не вручную.
- Показывать в дашборде `empirical`, `markov`, `blend` и производные рынки с best bookmaker.
- Сохранить разделение accuracy и value; не обещать прибыль без линии и OOF.

## Non-goals

- Не менять текущие `predictions`, `prediction_outcomes`, CLV и trainer OOF-метрики.
- Не делать автоматические ставки.
- Не возвращать не-теннисные дисциплины.
- Не использовать платные API и новые runtime-зависимости.

## Approaches

1. **Только empirical (A)** — быстро, но зависит от похожести истории.
2. **Только Markov (B)** — структурно корректно, но требует калибровки `P(server wins point)`.
3. **A+B+C вместе** — выбрано: два провайдера с общим контрактом, OOF-сравнение и взвешенная смесь. Устойчивее, чем любая отдельная модель.

## Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD: production change только после красного теста.
- Источники истории: `sackmann_matches`, `results`, `canonical_events`, `odds_snapshots`.
- Язык документов и ответов — русский; код остаётся на английском, как в репозитории.

## Decisions

1. **Хранение.** Новая таблица `score_distributions(event_uid, model_run_id, provider, observed_at, distribution_json, p1_prob, PRIMARY KEY(event_uid, model_run_id, provider))`; `provider` принимает `empirical`, `markov`, `blend`.
2. **Empirical provider.** Адаптер читает `sackmann_matches` по surface/best_of/round/tourney_level и дате строго до события, ориентирует score в сторону канонического p1 и вызывает `empirical_score_distribution`.
3. **Markov provider.** `markov_score_distribution(p1_point_prob, p2_point_prob, best_of, simulations)` симулирует геймы/сеты до нужного best_of и возвращает частоты score atoms; `p_point` калибруется из serve-статистики Sackmann.
4. **Blend.** `blend_score_distributions(empirical, markov, weight)` — нормализованная смесь; вес подбирается по OOF log loss и сохраняется в run metrics.
5. **Evaluation.** Для каждого провайдера отдельно считаются accuracy (Brier/log loss) и value (EV только при валидной de-vigged market probability). Отсутствие market probability означает `value_ev=None`.
6. **Dashboard.** Новый экран показывает три распределения и market probabilities от выбранного; одна строка на матч/рынок с best bookmaker.

## What is left to the builder

Implementation plan с TDD-задачами: storage/repository, empirical provider, Markov provider, blend/OOF weight, trainer wiring, dashboard screen, verification.
