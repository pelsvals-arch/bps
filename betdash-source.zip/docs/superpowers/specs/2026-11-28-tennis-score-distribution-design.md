# Tennis score-distribution design

Дата: 2026-11-28

## Intent and why

Вы предложили перенести центр тяжести BetDash с набора независимых бинарных прогнозов на единую вероятностную модель теннисного матча. Идея: сначала получить распределение возможных счетов матча — по сетам и по геймам внутри сетов — а уже из него вывести все рынки: победа в матче, фора по геймам, фора по сетам, фора в сете, тотал в сете, тотал матча, комбинации «победа + тотал».

Это правильный вектор, потому что рынки теннисного матча не независимы. Если `P(win)` и `P(total > line)` считать отдельными моделями, они могут быть внутренне противоречивы. Joint distribution даёт согласованные маргинальные и joint-вероятности, а также позволяет честно оценивать два разных качества:

1. **Accuracy/result quality** — насколько распределение совпадает с реальностью: log loss, Brier, calibration, likelihood счёта, точность производных рынков.
2. **Value/betting quality** — даёт ли распределение edge против de-vigged линии букмекера: EV, CLV, селективность, Kelly.

Высокий accuracy не гарантирует прибыль: рынок может быть точнее модели. Прибыль требует сравнения с линией и calibration на out-of-fold данных.

## Goals

- Создать единую score-first архитектуру как fundamental source для всех tennis-рынков.
- Обеспечить внутреннюю согласованность вероятностей между рынками.
- Поддержать вывод комбинированных рынков через joint probability, а не произведение маргиналов.
- Разделить оценку качества модели и оценку вэлью против рынка.
- Сохранить tennis-only фокус и текущий локальный стек без платных API.

## Non-goals

- Не обучать отдельную модель на каждый рынок.
- Не делать точный счёт сета главной целевой переменной первого прототипа.
- Не запускать мобильные приложения букмекеров, не обходить cert pinning и не использовать платные API как runtime-источник.
- Не делать автоматические ставки.
- Не превращать live scoreboard в источник модели:拥抱 pre-match данные и历史 scorelines.
- Не менять текущую систему CLV/calibration без отдельного обоснования; score-engine должен подключаться к существующей OOF-оценке.

## Anti-goals

- Чёрный ящик-классификатор на 784+ scorelines: переобучение, редкие классы, некалибруемость, невозможность debug.
- Несогласованные independent heads без joint layer.
- Любая схема, где market probability можно получить без явного market/line resolver.
- Использование пост-матчевой информации в до-матчевых фичах.

## Constraints

- Работа ведётся в worktree `.worktrees/impl`, ветка `impl`.
- TDD: каждый production change имеет тест, который сначала наблюдается красным.
- Теннис-only: не возвращать баскетбол/dota/cs2 в runtime-код.
- Без новых runtime-зависимостей и без платных сервисов.
- Источники данных: существующие `results`, `sackmann_matches`, `odds_snapshots`, `canonical_events`; Sackmann уже содержит set-level счета и serve-статистику.
- Язык документации и ответов пользователя — русский.

## Decisions

### Решение 1 — Joint distribution, а не point forecast

Модель возвращает распределение по score atoms, а не один счёт. Все рынки вычисляются как агрегацию/joint projection этого распределения.

### Решение 2 — Два evaluation axes

Для каждого прототипа считаем:
- result metrics: OOF log loss/Brier/calibration по distribution и производным market probabilities;
- value metrics: EV/CLV/market comparison против de-vigged closing или пре-match линии, где доступна корректная(bookmaker, outcome, line, observed_at) привязка.

### Решение 3 — Порядок P0 → P1 → P2

- **P0 — score/market foundation.** Новый `src/betdash/tennis/score.py` парсит tennis score в структуру: set pairs, winner side, totals, completed/walkover/retirement/match-tiebreak. Новый `src/betdash/tennis/markets.py` разрешает market+line в предикат над score distribution: winner, set handicap, game handicap, set total, match total, combined winner+total, exact set score.
- **P1 — empirical score distribution MVP.** Для matcа находим похожие исторические матчи по surface/best_of/Elo-gap/tournament level/round, строим сглаженное распределение score atoms, затем сдвигаем/калибруем его под текущую оценку силы. Это быстрый рабочий score-engine, который уже produce все рынки.
- **P2 — point-level Markov simulator.** Моделируется одна калибруемая величина `P(server wins point)`, из неё выводится `P(hold game)`, затем симуляция set/match (например, 100 000 прогонов) и distribution scorelines. Это правильная долгосрочная реализация, но дороже по данным и калибровке.

### Решение 4 — Не начинать с exact set score как главной цели

Порядок рынков по приоритету:
1. match winner;
2. set score 2:0/2:1/1:2/0:2 и total sets;
3. total games;
4. game handicap;
5. set handicap;
6. set total и handicap inside set;
7. combined winner + total;
8. exact set score.

### Решение 5 — Калибруемость важнее сложности

Одна калибруемая point-level вероятность в P2 предпочтительнее сотен редких scoreline-классов. В P1 требуется shrinkage/smoothing по похожим матчам и обязательная OOF-калибровка перед value-выводами.

## Interfaces to preserve

Предполагаемые публичные контракты для будущего плана:

- `parse_tennis_score(score: str, comment: str = "") -> TennisScore | None`
- `TennisScore` fields: `sets`, `sets_left`, `sets_right`, `games_left`, `games_right`, `completed`, `walkover`, `retirement`, `match_tiebreak`, `winner_side`, `totals_reliable`
- `resolve_tennis_market(market: str, line: float | None, outcome: str, score: TennisScore, participant_side: str) -> float` — результат 1/0/0.5 для push/void.
- `market_probabilities(distribution: Mapping[ScoreAtom, float], market: str, line: float | None) -> dict[str, float]`
- `score_distribution(...) -> dict[ScoreAtom, float]`
- `valuation_report(...) -> dict[str, float | int]` — accuracy/value split.

Точные имена и типы оптимизируются на этапе writing-plans, но контракт остаётся: parser → distribution → market probabilities → two evaluations.

## Validation

- Parser: tiebreak `7-6(4)`, retirement, walkover, match tiebreak, BO3/BO5, malformed score.
- Distribution: сумма вероятностей = 1; все market probabilities в [0,1]; комбо market — joint, не product marginals.
- Result quality: OOF Brier/log loss/calibration по market probabilities и по score bins.
- Value quality: EV/CLV/market comparison на корректно привязанных линиях; отсутствие coverage → no bet/no value claim.
- Integration: дашборд показывает одну строку на матч/рынок с best bookmaker и distribution-derived probability.

## What is left to the builder

Написать implementation plan с TDD-задачами для P0 и P1,чётко определив файлы, тесты и commit boundaries. P2 оформить как отдельный последующий план/спайк после того, как P0/P1 зафиксируют parser и market resolver.
