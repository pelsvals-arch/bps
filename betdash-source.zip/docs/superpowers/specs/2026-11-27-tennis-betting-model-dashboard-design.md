# Tennis Betting Model & Dashboard — Design

**Status:** proposed  
**Date:** 2026-11-27  
**Scope:** model math adaptation + one-row-per-match dashboard view

## Intent and why

Пользователь попросил: «поищи в интернете книги о ставках на спорт и на теннис, известные модели ML модели Ai модели которые описывают ставки на теннис, поищи необходимые математические формулы, главное адаптировать наши расчеты, чтобы из них вытекали адекватные прогнозы, чтобы мы каждый матч предсказывали и получали какую либо точность, также надо поправить в дашборде, не нужно один и тот же матч выводить от каждого букмекера, достаточно лишь показать у какого букмекера предлагается коэфициент выше».

Цель — не «гарантированная точность каждый матч» (её не даёт ни одна модель), а честные, откалиброванные вероятности и измеримая OOF-точность на каждом матче. Вторая цель — убрать из дашборда дублирование одного матча по букмекерам: одна строка = матч + рынок, лучший кэф и букмекер.

## Goals

1. Собрать и зафиксировать источники: книги, модели, формулы, бенчмарки.
2. Адаптировать проверенные формулы под текущий tennis-only стек без новых тяжёлых зависимостей.
3. Заменить примитивный blend `0.7*model + 0.3*market` на калибруемую комбинацию модели и de-vigged рынка.
4. Добавить WElo (margin-weighted Elo) и Bradley–Terry-совместимый логистический слой поверх существующих surface-Elo/rank/serve-return фич.
5. Считать Brier/logloss и калибровку на out-of-fold прогнозах walk-forward, а не in-sample.
6. Сделать `market_depth()` агрегированным: один матч/рынок/линия → лучшие кэфы и букмекеры.

## Non-goals

- Не обещать прибыль или попадание каждого матча.
- Не добавлять Kafka/TimescaleDB/Transformer/live-in-play/платные API.
- Не менять Sackmann-инжест и tennis-only очистку.
- Не делать ставки автоматически; Kelly — только информационная метрика размера.

## Anti-goals

- In-sample метрики, выдаваемые за качество модели.
- Cross-book сравнение кэфов без канонической ориентации участников.
- Дубли строк по каждому букмекеру в основном фиде.

## Constraints

- Работа в worktree `.worktrees/impl`, ветка `impl`.
- TDD: RED → GREEN → полный `pytest`.
- Только tennis; `MVP_SPORTS={"tennis"}` не пересматривается.
- Без новых runtime-зависимостей: `math`, `sqlite3`, существующий Streamlit/Plotly.
- Сохранить обратную совместимость `FEATURES_VERSION` через миграцию/переобучение.

## Research base

### Books

- **Sharp Sports Betting** — Stanford Wong, 2001. Базовые идеи линии, MVP/CLV,Dispersion; https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor
- **The Logic of Sports Betting** — Ed Miller & Matthew Davidow, 2017. Моделирование рынка, closing line value; тот же каталог Unabated.
- **Squares & Sharps** — Jack Buchdahl, 2016. Практика оценки линий и bankroll; тот же каталог.
- **Sharper** — True PokerJoe, 2016. Современный игровой process; тот же каталог.
- **Statistical Sports Models in Excel** — Andrew Mack, 2019/2020. Практическая математика рейтингов и вероятностей; тот же каталог.
- **Bayesian Sports Models in R** — Andrew Mack, 2024. Байесовские операции и shrinkage; тот же каталог.

### Models and evidence

- Kovalchik (2020), **Extension of Elo to margin of victory / WElo**: https://www.sciencedirect.com/science/article/pii/S0169207020300157 ; пакет `welo`: https://cran.hafro.is/web/packages/welo/welo.pdf
- Сравнение Elo и ML в теннисе: https://journals.sagepub.com/doi/10.1177/17543371231212235
- Bradley–Terry: https://en.wikipedia.org/wiki/Bradley%E2%80%93Terry_model ; Stanford Lecture 24 (логистическая форма и MLE).
- Бенчмарк: MDPI https://www.mdpi.com/2813-2203/5/3/22 — Elo 65.87%, classical ML 66.30%, Elo+ML 67.52%, bookmaker odds 70–72%; Elo-фичи дают +1.57–1.65 п.п.; calibration ECE 0.0077 у deep nets против 0.0142. Вывод: ценность богатых фич и калибровки, а не размера модели.
- tennisalpha.in/resources — каталог теннисных моделей/источников.

### Formulas to adapt

1. Elo: `E_A = 1 / (1 + 10^((R_B - R_A)/400))`, `R'_A = R_A + K(S_A - E_A)`.
2. WElo (Kovalchik): `K_i = c (M_i + o)^s`, в статье `c=250, s=0.4, o=5`. Локально используем **нормализованный** вес относительно `o`: `w = clamp(((M+o)/o)^s, 0.75, 2.0)`, чтобы сохранить наш `K=20` и не дестабилизировать рейтинг.
3. Bradley–Terry: `P(i>j) = 1/(1+e^(β_j-β_i))`; logit = `β_i-β_j`; эквивалент Elo через `10^(R/400)`. Используем как логистическую форму для комбинирования rating/surface/market сигналов.
4. Beta-Binomial shrinkage: posterior `(α+Σx, β+n-Σx)` — уже частично применён к serve/return;.extend to form/surface win rates.
5. De-vig: `p_i = (1/o_i)/Σ_j(1/o_j)`; при полной паре нормализовать p1+p2=1. Power/Shin как расширения, если есть данные.
6. CLV: `decision_odds` против best closing odds в окне до старта, тот же bookmaker; уже реализовано в `closing.py`.
7. Brier: `BS = (1/N)Σ(f_i-o_i)^2`; logloss: `-Σ[y log p + (1-y)log(1-p)]`.
8. Kelly: `f=(bp-q)/b`; использовать half-Kelly и кап, только как рекомендацию.

## Approaches

### A — адаптировать текущую модель + дашборд (выбрано)

Пользователь выбрал вариант A. WElo иsurface/BT-логит добавляются в текущие rating features; market blending калибруется на OOF; дашборд агрегирует строки. Плюс: малый объём, полная совместимость с tennis-only БД. Минус: не.full graph/deep model.

### B — только дашборд

Быстро убирает дубли, но не отвечает на просьбу про «адекватные прогнозы». Отклонено.

### C — только исследовательский отчёт

Даёт список книг/формул, но не меняет продукт. Отклонено.

## Decisions

1. **WElo вместо «сырого» Kovalchik K.** `c=250` из статьи assume другой масштаб K и счёта; локально применяем нормализованный множитель к нашему `K=20`, с clamped range, чтобы сохранить стабильность. Cost: не bus exact published K, но сопоставимая идея.
2. **BT как форма, а не отдельный MLE-репозиторий.** Обучаемый вес market prior калибруется на OOF, без отдельного optimiser. Cost: меньше теоретической чистоты, проще и безопаснее.
3. **Market prior — de-vigged и coverage-weighted.** Constant `0.3` заменяется на `alpha` из OOF-калибровки; при coverage<2 alpha=0. Cost: требуется OOF-история, иначе fallback на текущий blend.
4. **Калибровка на OOF, не in-sample.** Использовать `analytics/calibration.py`,расширить OOF-пары из `_walk_forward()`. Cost: переобучение/новый model run.
5. **Kelly — informational only.** Half-Kelly, min edge 1.5%, cap 8% bankroll; не добавлять автоматические ставки. Cost: пользователь видит рекомендацию, но торговля остаётся ручной.
6. **Дашборд: один матч — одна строка по каждому рынку/линии.** `market_depth()` группирует снапшоты и показывает best odds + best bookmaker; `opportunity_feed()` уже делает это для pick,но нужно расширить `market_depth()`. Cost: теряется детальный список всех книг; он заменяется coverage_books и best_odds_by_outcome.

## How it will be built

### Files

- Modify `src/betdash/models/baseline.py`: `EloRating.update(..., weight=1.0)`; `probability()` unchanged.
- Modify `src/betdash/models/features.py`: margin helper, WElo/Sackmann features, diff features, version bump.
- Modify `src/betdash/models/trainer.py`: OOF probabilities in walk-forward; BT/logit blend; calibration wiring; Kelly/edge output.
- Modify `src/betdash/analytics/calibration.py`: expose fit/apply helpers if needed.
- Modify `src/betdash/markets/devig.py`: ensure power/Shin helper or at least normalized de-vig used by trainer.
- Modify `src/betdash/app/dashboard.py`: aggregate market depth and deduplicate feed; show `best_bookmaker`.
- Add tests under `tests/models/`, `tests/analytics/`, `tests/app/`.

### Verification

- Targeted TDD for each behavior.
- Full `PYTHONPATH=src .venv/bin/pytest -q`.
- Real DB smoke: `opportunity_feed()` and `market_depth()` — one row per event/market/line; no duplicate bookmaker rows.
- Honest report: OOF Brier/logloss/accuracy vs market/de-vigged market, not in-sample.

## What is left to the builder

Convert this design to an implementation plan with exact signatures, test files, and commit boundaries; execute with TDD.
