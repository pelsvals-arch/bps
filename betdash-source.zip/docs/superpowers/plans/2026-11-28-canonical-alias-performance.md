# Canonical Market and Performance Implementation Plan

> **For agentic workers:** use executing-plans or subagent-driven-development task-by-task.

**Goal:** Close verified canonicalization, alias, performance and accuracy-screen gaps.

**Architecture:** Registry/Trainer/Adapter make `game_handicap` first-class; alias generation becomes repeatable; repository readiness is cached per path; prediction generation reuses results; accuracy screen uses quality helpers.

**Tech Stack:** Python 3.12, pytest, SQLite, Streamlit.

**Spec:** `docs/superpowers/specs/2026-11-28-canonical-alias-performance-design.md`

## Global Constraints
- Worktree `.worktrees/impl`, branch `impl`.
- TDD: production changes require failing tests first.
- Full `pytest` suite stays green; unrelated dirty files untouched.

## Review Focus
- `game_handicap` survives adapter→DB→trainer — Task 1.
- Alias file generated and caches invalidated — Task 2.
- Connection readiness cached — Task 3.
- Prediction path reuses results — Task 4.
- Accuracy screen honestly reports zero settled data — Task 5.

---

### Task 1: Canonicalize game handicap
**Files:** `normalize/registry.py`, `models/trainer.py`, `tennis/markets.py`, `adapters/marathon.py`, tests.
- RED: `game_handicap` canonical, `spread` alias, trainer accepts it, Marathon `MTCH_HB` emits it.
- GREEN: add labels/market set/alias mapping.
- Full suite; commit `feat: canonicalize tennis game handicap`.

### Task 2: Regenerate aliases
**Files:** `alias_generator.py`, `sackmann_aliases.json`, tests.
- RED: generator CLI writes aliases from tmp DB; caches invalidate.
- GREEN: add `main()`/`__main__`, regenerate real alias file.
- Full suite; commit `feat: regenerate Sackmann aliases`.

### Task 3: Cache repository readiness
**Files:** `db/repository.py`, tests.
- RED: two connections run `_ensure_*` only once per path.
- GREEN: cache ready absolute paths; keep explicit migrations responsible for schema changes.
- Full suite; commit `perf: cache repository readiness`.

### Task 4: Reuse results in prediction path
**Files:** `models/trainer.py`, tests.
- RED: `_generate_predictions` passes `cached_results`.
- GREEN: load results once and pass to `build_features`.
- Full suite; commit `perf: reuse results in prediction path`.

### Task 5: Accuracy screen wiring
**Files:** `app/dashboard.py`, tests.
- RED: accuracy screen calls link/settle/quality helpers and warns on no settled data.
- GREEN: wire helpers and honest caption.
- Full suite; commit `feat: wire forecast quality into accuracy screen`.

### Task 6: Verification
- Full suite green; Streamlit `/healthz` 200; final review.
