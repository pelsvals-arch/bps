# Tennis Score Distribution (P0-P1) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the P0/P1 foundation for a tennis score-distribution engine: reliable score parsing, market resolution from a joint score distribution, an empirical distribution baseline, and separate accuracy/value evaluation.

**Architecture:** Add a new `betdash.tennis` package. `score.py` parses raw scores; `markets.py` projects a score distribution into market probabilities; `distribution.py` builds a smoothed empirical distribution from comparable historical matches; `evaluation.py` reports result accuracy and market value separately. P2 point-level Markov simulation is a later plan.

**Tech Stack:** Python 3 stdlib, pytest, existing SQLite repository data; no new runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-11-28-tennis-score-distribution-design.md`

## Global Constraints

- Work in worktree `.worktrees/impl`, branch `impl`.
- TDD: every production change has a test observed failing first.
- Tennis-only: do not reintroduce basketball/dota/cs2 runtime branches.
- No new runtime dependencies and no paid services.
- Data sources: existing `results`, `sackmann_matches`, `odds_snapshots`, `canonical_events`.
- Documentation and user-facing answers are in Russian.
- P2 point-level Markov simulator is a later plan, not this one.

## Review Focus

- Tiebreak, retirement, walkover, match tiebreak and malformed scores must parse predictably — pinned by Task 1 parser tests.
- Market resolution must handle push/void and preserve joint probabilities for `winner + total` — pinned by Task 2 combined-market test.
- Distribution probabilities must sum to 1 and degrade to a smoothed prior when no close matches exist — pinned by Task 3 distribution tests.
- Value claims must not be made without a real market probability — pinned by Task 4 no-market test.
- OOF evaluation must not reuse future rows — pinned by Task 4 chronological test.

---

### Task 1: Tennis score parser

**Files:**
- Create: `src/betdash/tennis/__init__.py`
- Create: `src/betdash/tennis/score.py`
- Test: `tests/tennis/test_score.py`

**Interfaces:**
- Consumes: raw `results.score` / `sackmann_matches.score` strings.
- Produces: `TennisScore` dataclass and `parse_tennis_score(score: str, comment: str = "") -> TennisScore | None`.

- [ ] **Step 1: Write the failing test**

```python
def test_parse_tennis_score_handles_tiebreak_and_set_counts():
    s = parse_tennis_score("7-6(4) 6-4")
    assert s is not None
    assert s.sets == ((7, 6), (6, 4))
    assert (s.sets_left, s.sets_right) == (2, 0)
    assert (s.games_left, s.games_right) == (13, 10)
    assert s.completed and s.totals_reliable


def test_parse_tennis_score_marks_retirement_and_void_totals():
    s = parse_tennis_score("6-4 3-2 RET", "retired")
    assert s is not None
    assert s.winner_side == "left"
    assert s.retirement and not s.totals_reliable


def test_parse_tennis_score_marks_walkover_and_match_tiebreak():
    assert parse_tennis_score("w/o", "walkover").walkover
    s = parse_tennis_score("6-7(5) 7-6(3) 10-8")
    assert s is not None and s.match_tiebreak and not s.totals_reliable
```

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_score.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'betdash.tennis'`.

- [ ] **Step 3: Implement parser**

Implement `TennisScore` with fields `sets`, `sets_left`, `sets_right`, `games_left`, `games_right`, `completed`, `walkover`, `retirement`, `match_tiebreak`, `winner_side`, `totals_reliable`. Strip tiebreak points before extracting `a-b` set pairs. Detect retirement from score/comment containing `RET`/`retired`; walkover from `w/o`/`walkover`; match tiebreak from a final set with winner at least 10 and loser at least 8. Malformed input returns `None`.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_score.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/tennis/__init__.py src/betdash/tennis/score.py tests/tennis/test_score.py docs/superpowers/specs/2026-11-28-tennis-score-distribution-design.md docs/superpowers/plans/2026-11-28-tennis-score-distribution.md
git commit -m "feat: add tennis score parser"
```

### Task 2: Market resolution from score distribution

**Files:**
- Create: `src/betdash/tennis/markets.py`
- Test: `tests/tennis/test_markets.py`

**Interfaces:**
- Consumes: `TennisScore` from Task 1 and `ScoreAtom = tuple[tuple[int, int], ...]`.
- Produces: `resolve_tennis_market(market: str, line: float | None, outcome: str, score: TennisScore, participant_side: str) -> float` and `market_probabilities(distribution: Mapping[ScoreAtom, float], market: str, line: float | None = None, set_index: int | None = None) -> dict[str, float]`.

- [ ] **Step 1: Write the failing test**

```python
def test_market_probabilities_match_winner_and_game_handicap():
    dist = {((6, 4), (6, 3)): 0.4, ((4, 6), (5, 7)): 0.6}
    wp = market_probabilities(dist, "match_winner")
    assert wp["p1"] == 0.4 and wp["p2"] == 0.6
    gc = market_probabilities(dist, "game_handicap", line=2.0)
    assert gc["push"] == 0.0  # margins -3 and +3, no exact push here
    assert gc["p1"] == 0.4 and gc["p2"] == 0.6


def test_combined_market_uses_joint_probability():
    dist = {((6, 4), (6, 3)): 0.4, ((7, 6), (6, 4)): 0.3, ((4, 6), (3, 6)): 0.3}
    comb = market_probabilities(dist, "winner_plus_total", line=22.5)
    assert comb["p1_over"] == 0.3  # only 7+6+6+4 = 23
    assert comb["p1_under"] == 0.4
    assert comb["p2_over"] + comb["p2_under"] == 0.3


def test_resolve_market_returns_push_for_void_totals():
    score = parse_tennis_score("6-4 3-2 RET", "retired")
    assert resolve_tennis_market("total_games", 10.5, "over", score, "p1") == 0.5
```

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_markets.py -v`
Expected: FAIL with `ImportError: cannot import name 'market_probabilities'`.

- [ ] **Step 3: Implement resolver**

Implement supported markets: `match_winner`, `total_games`, `total_sets`, `game_handicap`, `set_handicap`, `set_total`, `set_game_handicap`, `winner_plus_total`. Use score predicates; aggregate distribution mass per outcome. For `winner_plus_total`, count only atoms satisfying both conditions. For `totals_reliable == False` return `0.5` push/void. For exact integer handicap line where margin equals line, return `0.5`.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_markets.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/tennis/markets.py tests/tennis/test_markets.py
git commit -m "feat: derive tennis market probabilities from score distribution"
```

### Task 3: Empirical score distribution

**Files:**
- Create: `src/betdash/tennis/distribution.py`
- Test: `tests/tennis/test_distribution.py`

**Interfaces:**
- Consumes: `ScoreAtom` from Task 2 and history rows with keys `score_p1_first`, `surface`, `best_of`, `elo_gap`, `tourney_level`, `round`.
- Produces: `empirical_score_distribution(history: Sequence[Mapping[str, Any]], target: Mapping[str, Any], prior_strength: float = 5.0) -> dict[ScoreAtom, float]` and `condition_distribution_on_win_prob(distribution: Mapping[ScoreAtom, float], p1_win_prob: float) -> dict[ScoreAtom, float]`.

- [ ] **Step 1: Write the failing test**

```python
def test_empirical_distribution_uses_similar_matches_and_sums_to_one():
    history = [
        {"score_p1_first": "6-4 6-3", "surface": "clay", "best_of": 3, "elo_gap": 80, "tourney_level": "A", "round": "R32"},
        {"score_p1_first": "3-6 6-7", "surface": "clay", "best_of": 3, "elo_gap": -70, "tourney_level": "A", "round": "R32"},
        {"score_p1_first": "6-2 6-2", "surface": "grass", "best_of": 3, "elo_gap": 90, "tourney_level": "A", "round": "R32"},
    ]
    target = {"surface": "clay", "best_of": 3, "elo_gap": 75, "tourney_level": "A", "round": "R32"}
    dist = empirical_score_distribution(history, target, prior_strength=0.0)
    assert sum(dist.values()) == pytest.approx(1.0)
    assert dist[((6, 4), (6, 3))] == pytest.approx(0.5)
```

```python
def test_condition_distribution_shifts_match_winner_without_losing_mass():
    dist = {((6, 4), (6, 3)): 0.5, ((3, 6), (6, 7)): 0.5}
    shifted = condition_distribution_on_win_prob(dist, 0.8)
    assert sum(shifted.values()) == pytest.approx(1.0)
    assert market_probabilities(shifted, "match_winner")["p1"] == pytest.approx(0.8)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_distribution.py -v`
Expected: FAIL with `ImportError: cannot import name 'empirical_score_distribution'`.

- [ ] **Step 3: Implement distribution**

Filter history rows by exact `surface`, `best_of`, `tourney_level`, `round` and `abs(elo_gap - target_elo_gap) <= 100`. Parse each `score_p1_first` with `parse_tennis_score`; use its `sets` as `ScoreAtom`. Add `prior_strength` mass uniformly over observed atoms before normalizing. `condition_distribution_on_win_prob` scales p1-winning atoms and p2-winning atoms to the requested p1 probability, preserving relative weights and total mass 1.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_distribution.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/tennis/distribution.py tests/tennis/test_distribution.py
git commit -m "feat: add empirical tennis score distribution"
```

### Task 4: Separate accuracy and value evaluation

**Files:**
- Create: `src/betdash/tennis/evaluation.py`
- Test: `tests/tennis/test_evaluation.py`
- Modify: `src/betdash/tennis/__init__.py`

**Interfaces:**
- Consumes: score distributions from Task 3, market probabilities from Task 2.
- Produces: `evaluation_report(pairs: Sequence[EvaluationPair]) -> dict[str, float | int]`, where each pair holds `distribution`, `actual_score`, `market_probability`, `market_odds`, `observed_at`, `actual`.

- [ ] **Step 1: Write the failing test**

```python
def test_evaluation_report_separates_accuracy_and_value():
    pair = {
        "distribution": {((6, 4), (6, 3)): 0.7, ((4, 6), (3, 6)): 0.3},
        "actual_score": "6-4 6-3",
        "market_probability": 0.6,
        "market_odds": 2.0,
        "observed_at": "2026-01-01T12:00:00+00:00",
        "actual": 1,
    }
    report = evaluation_report([pair])
    assert report["oof_samples"] == 1
    assert 0.0 <= report["result_brier"] <= 1.0
    assert report["value_ev"] > 0.0


def test_evaluation_report_does_not_claim_value_without_market_probability():
    pair = {"distribution": {((6, 4), (6, 3)): 1.0}, "actual_score": "6-4 6-3", "actual": 1}
    report = evaluation_report([pair])
    assert report["value_samples"] == 0
    assert report["value_ev"] is None
```

```python
def test_evaluation_report_uses_chronological_pairs_only():
    rows = [
        {"distribution": {((6, 4), (6, 3)): 0.6, ((4, 6), (3, 6)): 0.4}, "actual_score": "6-4 6-3", "actual": 1, "observed_at": "2026-01-02T12:00:00+00:00"},
        {"distribution": {((6, 4), (6, 3)): 0.4, ((4, 6), (3, 6)): 0.6}, "actual_score": "4-6 3-6", "actual": 0, "observed_at": "2026-01-01T12:00:00+00:00"},
    ]
    report = evaluation_report(rows)
    assert report["oof_samples"] == 2
    assert report["first_observed_at"] == "2026-01-01T12:00:00+00:00"
    assert report["last_observed_at"] == "2026-01-02T12:00:00+00:00"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_evaluation.py -v`
Expected: FAIL with `ImportError: cannot import name 'evaluation_report'`.

- [ ] **Step 3: Implement evaluation**

Sort pairs by `observed_at` when present. Compute result Brier/log loss from `market_probabilities(distribution, "match_winner")["p1"]` against `actual`. Compute `value_ev = p*decimal_odds - 1` only where `market_probability` and `market_odds` are finite and `0 < p < 1`; otherwise leave `value_samples` unchanged and `value_ev` `None`. Export parser, resolver, distribution and evaluation functions from `betdash.tennis`.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_evaluation.py -v`
Expected: PASS.

- [ ] **Step 5: Full suite and commit**

Run: `PYTHONPATH=src .venv/bin/pytest -q`
Expected: all tests pass.

```bash
git add src/betdash/tennis/evaluation.py src/betdash/tennis/__init__.py tests/tennis/test_evaluation.py
git commit -m "feat: add tennis score evaluation split"
```

## Self-review

Spec coverage: parser, market resolution, empirical distribution, accuracy/value split and Russian constraints are covered. P2 Markov is explicitly deferred. Step scan: each task has one failing test, one implementation and one green run. Types are consistent across tasks. Review Focus lines are pinned by tests in Tasks 1–4. The plan is shorter than a transcript and leaves implementation bodies to the executor.






