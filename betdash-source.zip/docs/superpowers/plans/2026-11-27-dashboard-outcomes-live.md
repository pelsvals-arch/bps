# Dashboard outcomes, live scoreboard and time Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add scored prediction outcomes, a live scoreboard, readable Moscow time, and cleaner market depth to the tennis dashboard.

**Architecture:** Pure evaluator writes per-prediction accuracy rows; a small public-API live client feeds a dashboard screen; a shared time formatter normalizes displayed timestamps; market depth stays one row per market with an explicit best bookmaker.

**Tech Stack:** Python 3, SQLite, Streamlit, stdlib `urllib`/`zoneinfo`, pytest.

**Spec:** `docs/superpowers/specs/2026-11-27-dashboard-outcomes-live-design.md`

## Global Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD RED→GREEN; full suite after every task.
- No new runtime dependencies and no paid API keys.
- Display timezone is always `Europe/Moscow`, format `dd.mm HH:MM MSK`.
- Tennis-only restriction for predictions is unchanged.

## Review Focus

- Canonical outcome orientation — `tests/analytics/test_prediction_outcomes.py::test_prediction_outcome_uses_canonical_order`.
- Missing result must not create an outcome — `tests/analytics/test_prediction_outcomes.py::test_prediction_outcome_ignores_missing_results`.
- Live client degrades on HTTP error — `tests/live/test_sofascore.py::test_live_events_returns_empty_on_http_error`.
- All displayed times are Moscow — `tests/app/test_dashboard_time_format.py::test_format_msk`.
- Market depth keeps one row per match/market — `tests/app/test_dashboard_aggregation.py::test_market_depth_aggregates_by_event_market_line`.

---

### Task 1: Prediction outcome evaluator

**Files:**
- Create: `src/betdash/analytics/prediction_outcomes.py`
- Modify: `src/betdash/analytics/__init__.py`
- Modify: `src/betdash/db/schema.sql`
- Modify: `src/betdash/db/repository.py`
- Test: `tests/analytics/test_prediction_outcomes.py`

**Interfaces:**
- Produces: `backfill_prediction_outcomes(repo) -> dict[str,int]`, `prediction_outcomes(repo) -> list[dict]`.

- [ ] **Step 1: Write failing tests**

```python
def test_prediction_outcome_uses_canonical_order(db):
    assert row["brier"] == pytest.approx(0.25)
def test_prediction_outcome_ignores_missing_results(db):
    assert backfill_prediction_outcomes(repo)["skipped"] == 1
```

- [ ] **Step 2: Run tests**

Run: `PYTHONPATH=src .venv/bin/pytest tests/analytics/test_prediction_outcomes.py -q`
Expected: FAIL with missing module/table.

- [ ] **Step 3: Implement evaluator**

Use `canonical_outcome()` and `outcome="match_winner"`; write Brier/log_loss/hit/CLV into `prediction_outcomes` with UNIQUE(`prediction_id`).

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: score prediction outcomes against results"`

### Task 2: Live scoreboard client

**Files:**
- Create: `src/betdash/live/__init__.py`
- Create: `src/betdash/live/sofascore.py`
- Test: `tests/live/test_sofascore.py`

**Interfaces:**
- Produces: `fetch_live_events(sport: str, opener=urlopen) -> list[dict]`, fields `event_id,start_at,home,away,home_score,away_score,status,tournament,url`.

- [ ] **Step 1: Write failing tests**

Assert parsing of fixture JSON for tennis/basketball/esports and empty list on HTTP error.

- [ ] **Step 2: Run tests**

Expected: FAIL with missing module.

- [ ] **Step 3: Implement client**

Use `urllib.request.urlopen`, 5s timeout, no dependencies; Russian name translation when present; unknown fields do not raise.

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: add SofaScore live scoreboard client"`

### Task 3: Dashboard time formatting and live screen

**Files:**
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/app/test_dashboard_time_format.py`

**Interfaces:**
- Produces: `format_msk(value) -> str`, `render_live_scoreboard()`.

- [ ] **Step 1: Write failing tests**

Assert `format_msk("2026-11-27T12:34:00Z") == "27.11 15:34 MSK"` and source contains Moscow timezone and live screen.

- [ ] **Step 2: Run tests**

Expected: FAIL with missing formatter.

- [ ] **Step 3: Implement formatter and screen**

Use `ZoneInfo("Europe/Moscow")`; apply to all visible time columns; add `Live scoreboard` screen using `fetch_live_events("tennis")`.

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: show Moscow time and live scoreboard"`

### Task 4: Accuracy screen and market depth cleanup

**Files:**
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/app/test_dashboard_aggregation.py`

**Interfaces:**
- Consumes: `prediction_outcomes(repo)`.

- [ ] **Step 1: Write failing tests**

Assert one row per `(event_uid,market,line)`, non-empty `best_bookmaker`, no 20-row truncation, and source includes accuracy screen.

- [ ] **Step 2: Run tests**

Expected: FAIL.

- [ ] **Step 3: Implement**

Add `prediction_accuracy()` screen; remove `.head(20)` from market depth; keep aggregation and label best bookmaker explicitly.

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: add accuracy screen and clean market depth"`

### Task 5: Final verification

- [ ] **Step 1:** Run `PYTHONPATH=src .venv/bin/pytest -q`.
- [ ] **Step 2:** Check Streamlit health on `:8501`.
- [ ] **Step 3:** Record results in ledger and present finishing menu.
