# Tennis Betting Model & Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Adapt sourced tennis-betting math into BetDash predictions and show one aggregated row per match in the dashboard.

**Architecture:** Add margin-weighted Elo and a calibrated Bradley–Terry-style logit blend over model and de-vigged market probabilities; expose OOF probabilities for honest Brier/logloss/calibration; aggregate `market_depth()` by event/market/line instead of by bookmaker.

**Tech Stack:** Python 3 stdlib (`math`, `json`), existing SQLite repository, Streamlit/Plotly dashboard, pytest.

**Spec:** `docs/superpowers/specs/2026-11-27-tennis-betting-model-dashboard-design.md`

## Global Constraints

- Work in worktree `.worktrees/impl`, branch `impl`.
- TDD: RED → observe failure → GREEN → full suite.
- Tennis only; do not change `MVP_SPORTS={"tennis"}` or Sackmann ingest.
- No new runtime dependencies.
- Kovalchik WElo is normalized locally: `w = clamp(((margin+5)/5)**0.4, 0.75, 2.0)`.
- Market prior must be de-vigged; Kelly is informational only: half-Kelly, cap `0.08`.
- Every model metric shown as quality must come from OOF, not in-sample rows.

## Review Focus

- A missing or tied score must not crash rating updates or produce an extreme WElo weight — pinned by `test_welo_missing_score_uses_neutral_weight` in Task 1.
- A stale/low-coverage market must not dominate the model — pinned by `test_blend_ignores_market_when_coverage_is_below_two` in Task 2.
- OOF probabilities must be truly out-of-fold — pinned by `test_walk_forward_oof_returns_only_test_fold_rows` in Task 2.
- Dashboard must not repeat a match for every bookmaker — pinned by `test_market_depth_aggregates_snapshots_by_event_market_line` in Task 3.
- Kelly output must never exceed the cap or go negative — pinned by `test_kelly_half_cap_and_floor` in Task 2.

---

### Task 1: Margin-weighted Elo

**Files:**
- Modify: `src/betdash/models/baseline.py`
- Test: `tests/models/test_baseline_welo.py`

**Interfaces:**
- Consumes: existing `EloRating(a,b,score_a)`.
- Produces: `EloRating.update(a: str, b: str, score_a: float, weight: float = 1.0) -> None`; `score_margin(score: str | None) -> float`; `_welo_weight(margin: float) -> float`.

- [ ] **Step 1: Write failing tests**

```python
def test_welo_updates_more_for_decisive_score():
    close = EloRating(k=20.0)
    decisive = EloRating(k=20.0)
    close.update("A", "B", 1.0, weight=_welo_weight(score_margin("6-4 7-6")))
    decisive.update("A", "B", 1.0, weight=_welo_weight(score_margin("6-0 6-0")))
    assert decisive.get("A") > close.get("A")

def test_welo_missing_score_uses_neutral_weight():
    assert _welo_weight(score_margin(None)) == 1.0
```

- [ ] **Step 2: Run tests and verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/models/test_baseline_welo.py -q`  
Expected: FAIL because `score_margin` and `weight` do not exist.

- [ ] **Step 3: Implement minimal code**

Add `score_margin()` parsing the two score numbers via regex and returning `abs(a-b)`; return `0.0` when fewer than two numbers. Add `_welo_weight(margin)` as `max(0.75, min(2.0, ((margin+5.0)/5.0)**0.4))`. Extend `update()` to multiply both rating changes by `weight`.

- [ ] **Step 4: Run tests and verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/models/test_baseline_welo.py -q`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/models/baseline.py tests/models/test_baseline_welo.py
git commit -m "feat: add margin-weighted Elo updates"
```

### Task 2: OOF calibration, BT blend and Kelly

**Files:**
- Modify: `src/betdash/analytics/calibration.py`
- Modify: `src/betdash/models/trainer.py`
- Test: `tests/analytics/test_calibration.py`
- Test: `tests/models/test_trainer.py`

**Interfaces:**
- Consumes: existing `fit_isotonic`, `calibration_report`, `Trainer._market_probs`, `Trainer._walk_forward`, `Trainer._fit_model`, `Trainer._predict_with_model`.
- Produces: `Trainer._walk_forward_oof(rows: list[dict], window: int | None = None) -> list[tuple[float,int]]`; `fit_blend_alpha(pairs: list[tuple[float,float,int]]) -> float`; `apply_blend(p_model: float, p_market: float, alpha: float) -> float`; `kelly_fraction(p: float, decimal_odds: float, fraction: float = 0.5, cap: float = 0.08) -> float`.

- [ ] **Step 1: Write failing tests**

```python
def test_walk_forward_oof_returns_only_test_fold_rows():
    rows = [{"event_uid": str(i), "actual": i % 2, "features": {}} for i in range(10)]
    oof = trainer._walk_forward_oof(rows, window=2)
    assert len(oof) == 9  # folds after the first training row
    assert all(0.0 <= p <= 1.0 for p, _ in oof)

def test_blend_ignores_market_when_coverage_is_below_two():
    assert apply_blend(0.60, 0.90, 0.0) == 0.60

def test_kelly_half_cap_and_floor():
    assert kelly_fraction(0.60, 2.0) == 0.10  # f=0.2, half=0.1
    assert kelly_fraction(0.95, 1.05) == 0.08
    assert kelly_fraction(0.40, 2.0) == 0.0
```

- [ ] **Step 2: Run tests and verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/analytics/test_calibration.py tests/models/test_trainer.py -q`  
Expected: FAIL because the new helpers do not exist.

- [ ] **Step 3: Implement minimal code**

In `calibration.py`, add `fit_blend_alpha()` minimizing Brier over candidate alphas `0.0,0.1,...,1.0`, `apply_blend()` and `kelly_fraction()`. In `trainer.py`, add `_walk_forward_oof()` using `self._fit_model()`/`self._predict_with_model()` over the same folds as `_walk_forward()`, replace fixed `0.7/0.3` with `apply_blend(...)` using calibrated alpha when OOF supports it, and include OOF Brier/logloss and Kelly in model-run metrics.

- [ ] **Step 4: Run tests and verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/analytics/test_calibration.py tests/models/test_trainer.py -q`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/analytics/calibration.py src/betdash/models/trainer.py tests/analytics/test_calibration.py tests/models/test_trainer.py
git commit -m "feat: add OOF calibration and BT-style market blend"
```

### Task 3: Dashboard aggregation

**Files:**
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/app/test_dashboard_aggregation.py`

**Interfaces:**
- Consumes: `Repository.last_snapshots()`, `tennis_only()`, existing `opportunity_feed()`.
- Produces: `market_depth(event_uid: str | None = None) -> list[dict]` with one row per `(event_uid, market, line)`, fields `best_odds_by_outcome`, `best_bookmaker`, `coverage_books`, `odds_summary`.

- [ ] **Step 1: Write failing test**

```python
def test_market_depth_aggregates_snapshots_by_event_market_line(tmp_path):
    # two bookmakers, same event/market/line, different odds
    rows = rt.market_depth()
    assert len(rows) == 1
    assert rows[0]["best_bookmaker"] == "fonbet"
    assert "p1: 2.10" in rows[0]["best_odds_by_outcome"]
```

- [ ] **Step 2: Run tests and verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/app/test_dashboard_aggregation.py -q`  
Expected: FAIL because `market_depth()` still returns per-bookmaker rows.

- [ ] **Step 3: Implement minimal code**

Group `repo.last_snapshots()` by `(event_uid, market, line)`, compute best odds and bookmaker per outcome, keep `coverage_books`, and format `best_odds_by_outcome`; update the render columns to show aggregated fields.

- [ ] **Step 4: Run tests and verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/app/test_dashboard_aggregation.py -q`  
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/app/dashboard.py tests/app/test_dashboard_aggregation.py
git commit -m "feat: aggregate dashboard market depth by match"
```

### Task 4: Research report and final verification

**Files:**
- Create: `docs/research/2026-11-27-tennis-betting-models.md`
- Modify: `docs/superpowers/specs/2026-11-27-tennis-betting-model-dashboard-design.md` (typo cleanup only)

**Interfaces:**
- Consumes: Firecrawl research results and the implemented code.
- Produces: a cited research report with books, models, formulas, benchmark table and adaptation decisions.

- [ ] **Step 1: Write the report**

Include the book list, WElo/Kovalchik, Bradley–Terry, de-vig/Kelly, calibration formulas, MDPI benchmark and the explicit limitation that bookmaker closing odds remain a stronger baseline.

- [ ] **Step 2: Run the full suite**

Run: `PYTHONPATH=src .venv/bin/pytest -q`  
Expected: PASS.

- [ ] **Step 3: Commit**

```bash
git add docs/research/2026-11-27-tennis-betting-models.md docs/superpowers/specs/2026-11-27-tennis-betting-model-dashboard-design.md
git commit -m "docs: add tennis betting research report"
```
