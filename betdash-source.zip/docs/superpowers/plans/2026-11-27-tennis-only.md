# Tennis-only Focus Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Сделать весь проект и рабочую БД tennis-only: архивировать не-теннисные данные, удалить их из рабочей БД, убрать не-теннисные ветки из кода, тестов и доков, затем удалить архив.

**Architecture:** Сначала добавляется и тестируется миграция БД и чекапоинта. Затем нормализация и адаптеры сужаются до tennis, после чего тренер/бэктест/CLV/дашборд теряют sport-измерение. Финальным шагом выполняется миграция на живой БД с остановкой Streamlit и WAL-checkpoint, аудит и удаление архива.

**Tech Stack:** Python 3.11+, SQLite WAL, pytest, Streamlit, pydantic-settings.

**Spec:** `docs/superpowers/specs/2026-11-27-tennis-only-design.md`

## Global Constraints

- Working tree: `.worktrees/impl`, branch `impl`.
- `MVP_SPORTS = {"tennis"}` — единственный разрешённый вид спорта.
- Колонка `sport` в схеме остаётся и всегда содержит `tennis`.
- `sackmann_matches` и `tournaments` не удаляются и не изменяются.
- Архив создаётся до удаления; удаляется только после зелёного suite и DB-аудита.
- Перед миграцией живой БД остановить Streamlit и выполнить `PRAGMA wal_checkpoint(TRUNCATE)`.
- TDD: каждый production change сначала подтверждён упавшим тестом.
- Полный suite `PYTHONPATH=src .venv/bin/pytest -q` должен быть зелёным.
- Посторонние untracked-файлы (`bets/`, `cli.py`, code dumps, `egg-info`, `analytics/market_metrics.py`) не трогать.

## Review Focus

- **Снапшот без `canonical_events` (65 236 строк).** Ожидается: архивируется и удаляется, сирот в рабочей БД ноль. Тест: `tests/db/test_tennis_migration.py::test_archive_and_purge_removes_orphan_snapshots`.
- **Живой Streamlit и WAL во время миграции.** Ожидается: писатели остановлены, WAL checkpoint'нут, после миграции дашборд поднят заново. Тест/проверка: Task 7 steps 2–6.
- **Не-теннисный `RawOdd` от любого адаптера.** Ожидается: тихо игнорируется, без событий и снапшотов. Тесты: `tests/adapters/test_betboom.py`, `test_marathon.py`, `test_winline.py`, `test_json_family.py` — по одному assertion на отфильтрованный не-теннисный sport.
- **Теннисная линия, пришедшая как `total_points`/`spread`.** Ожидается: probabilities продолжают считаться. Тест: `tests/models/test_trainer.py::test_tennis_total_and_spread_markets_keep_working`.
- **Чекапоинт с ключами `basketball`.** Ожидается: после миграции только `tennis`. Тест: `tests/db/test_tennis_migration.py::test_migrate_checkpoint_keeps_only_tennis`.

---

### Task 1: Migration helpers

**Files:**
- Create: `src/betdash/db/tennis_migration.py`
- Create: `tests/db/test_tennis_migration.py`
- Modify: `src/betdash/db/__init__.py`

**Interfaces:**
- Consumes: `Repository.path` (`str`), `sqlite3` file DB.
- Produces:
  - `archive_and_purge_non_tennis(repo: Repository, archive_path: Path) -> dict[str, dict[str, int]]`
  - `migrate_checkpoint(path: Path) -> dict[str, int]`
  - `main(argv: list[str] | None = None) -> int`

- [ ] **Step 1: Write the failing DB migration test**

```python
def test_archive_and_purge_removes_orphan_snapshots(tmp_path):
    # minimal schema: canonical_events, odds_snapshots, predictions,
    # closing_lines, closing_lines_book
    # rows: one tennis event, one basketball event, one orphan snapshot
    report = archive_and_purge_non_tennis(repo, archive_path)
    assert report["canonical_events"]["basketball"] == 1
    assert orphan_count(archive_path) == 1
    assert orphan_count(db_path) == 0
    assert sports(db_path) == {"tennis"}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/db/test_tennis_migration.py::test_archive_and_purge_removes_orphan_snapshots -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'betdash.db.tennis_migration'`.

- [ ] **Step 3: Implement `archive_and_purge_non_tennis`**

Use `sqlite3` with `ATTACH` to copy table schema and rows into the archive. Filter `canonical_events` by `sport != 'tennis'`. Copy dependent rows by `event_uid` from `odds_snapshots`, `predictions`, `results`, `closing_lines`, `closing_lines_book`, `event_aliases`, `feature_values`, `bets`, `events`; also copy snapshots whose `event_uid` is absent from `canonical_events`. Delete the same rows from the working DB and run `VACUUM`. Do not touch `sackmann_matches`, `tournaments`, `adapter_health`, `bankroll`, `model_runs`.

- [ ] **Step 4: Run the test**

Run: `PYTHONPATH=src .venv/bin/pytest tests/db/test_tennis_migration.py::test_archive_and_purge_removes_orphan_snapshots -v`
Expected: PASS.

- [ ] **Step 5: Write the failing checkpoint test**

```python
def test_migrate_checkpoint_keeps_only_tennis(tmp_path):
    payload = {"elo": {"tennis": {}, "basketball": {}},
               "glicko": {"tennis": {}, "basketball": {}},
               "runs": 4}
    path.write_text(json.dumps(payload), encoding="utf-8")
    report = migrate_checkpoint(path)
    assert report == {"elo": 1, "glicko": 1}
    saved = json.loads(path.read_text(encoding="utf-8"))
    assert set(saved["elo"]) == {"tennis"}
    assert set(saved["glicko"]) == {"tennis"}
    assert saved["runs"] == 4
```

- [ ] **Step 6: Run it to verify it fails**

Run: `PYTHONPATH=src .venv/bin/pytest tests/db/test_tennis_migration.py::test_migrate_checkpoint_keeps_only_tennis -v`
Expected: FAIL with missing function.

- [ ] **Step 7: Implement `migrate_checkpoint(path: Path) -> dict[str, int]`**

Load JSON, keep only the `"tennis"` key in `elo`/`glicko`, preserve every other field, write atomically via a temporary file and `replace`, return removed-key counts.

- [ ] **Step 8: Run both tests and commit**

Run: `PYTHONPATH=src .venv/bin/pytest tests/db/test_tennis_migration.py -v`
Expected: 2 passed.

```bash
git add src/betdash/db/tennis_migration.py src/betdash/db/__init__.py tests/db/test_tennis_migration.py
git commit -m "feat: add tennis-only data migration helpers"
```

---

### Task 2: Normalization tennis-only

**Files:**
- Modify: `src/betdash/normalize/registry.py`
- Modify: `tests/normalize/test_registry.py`

**Interfaces:**
- Consumes: nothing new.
- Produces: `MVP_SPORTS == {"tennis"}`; `canon_sport("basketball") == ""`; `canon_market` no longer emits `map_winner`, `total_maps`, `map_handicap`.

- [ ] **Step 1: Write failing tests**

```python
@pytest.mark.parametrize("raw", ["basketball", "dota2", "cs2", "football", "NBA"])
def test_non_tennis_sport_is_unknown(raw):
    assert canon_sport(raw) == ""

def test_map_markets_are_not_canonical():
    assert canon_market("map_winner", "marathon") == "unknown_map_winner"
    assert canon_market("total maps", "marathon") == "unknown_total_maps"
    assert canon_market("map handicap", "marathon") == "unknown_map_handicap"
```

- [ ] **Step 2: Run to verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/normalize/test_registry.py -k "non_tennis_sport or map_markets" -v`
Expected: FAIL because non-tennis sports still canonicalize and map markets still map.

- [ ] **Step 3: Implement**

Set `MVP_SPORTS = {"tennis"}`. Reduce `_SPORT_ALIASES` and `canon_sport()` heuristics to tennis only. Delete `map_winner`, `total_maps`, `map_handicap` labels from both market tables. Keep `total_points`, `total_games`, `spread`, `set_handicap`.

- [ ] **Step 4: Run to verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/normalize/test_registry.py -v`
Expected: all passed.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/normalize/registry.py tests/normalize/test_registry.py
git commit -m "feat: restrict normalization to tennis"
```

---

### Task 3: Adapters tennis-only

**Files:**
- Modify: `src/betdash/adapters/betboom.py`
- Modify: `src/betdash/adapters/marathon.py`
- Modify: `src/betdash/adapters/winline.py`
- Modify: `src/betdash/adapters/json_family.py`
- Modify: `tests/adapters/test_betboom.py`, `test_marathon.py`, `test_winline.py`, `test_json_family.py`
- Modify: `tests/adapters/fixtures/*.json`

**Interfaces:**
- Consumes: `canonical_outcome`, `canon_sport`, `MVP_SPORTS` from Task 2.
- Produces: every adapter emits `RawOdd.sport == "tennis"` only.

- [ ] **Step 1: Write failing adapter tests**

For each of the four adapters, keep one tennis assertion and change the previous basketball/dota/cs2 assertions to:

```python
assert all(r.sport == "tennis" for r in rows)
assert not any(r.sport in {"basketball", "dota2", "cs2"} for r in rows)
```

- [ ] **Step 2: Run to verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/adapters -q`
Expected: FAIL for the changed sport assertions.

- [ ] **Step 3: Implement**

Replace `_SUPPORTED_SPORTS`/sport-id maps in all four adapters with tennis-only sets. Remove alias entries and branches for basketball/dota/cs2. Keep bookmaker-specific tennis leagues and market mappings intact.

- [ ] **Step 4: Run to verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/adapters -q`
Expected: all passed.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/adapters tests/adapters
git commit -m "feat: make bookmaker adapters tennis-only"
```

---

### Task 4: Trainer, backtest and CLV tennis-only

**Files:**
- Modify: `src/betdash/models/trainer.py`
- Modify: `src/betdash/backtest/engine.py`
- Modify: `src/betdash/backtest/clv.py`
- Modify: `tests/models/test_trainer.py`
- Modify: `tests/backtest/test_engine.py`
- Modify: `tests/test_clv.py`

**Interfaces:**
- Consumes: Task 2 market labels and Task 3 tennis-only raw odds.
- Produces:
  - `BacktestEngine.run(start: datetime, end: datetime) -> BacktestReport`
  - `clv_report(repo) -> dict` without `by_sport`
  - Trainer rating state contains only key `"tennis"`.

- [ ] **Step 1: Write failing tests**

```python
def test_tennis_total_and_spread_markets_keep_working():
    probs = trainer._market_probs("total_points", 2.5, {"over": ..., "under": ...}, 0.55, None)
    assert set(probs) == {"over", "under"}
    probs = trainer._market_probs("spread", 1.5, {"p1": ..., "p2": ...}, 0.6, None)
    assert set(probs) == {"p1", "p2"}

def test_map_markets_are_ignored():
    assert trainer._market_probs("map_winner", None, {}, 0.5, None) == {}

def test_backtest_run_has_no_sport_argument():
    report = BacktestEngine(repo, model).run(start, end)
```

Also assert `"by_sport" not in clv_report(repo)`.

- [ ] **Step 2: Run to verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/models/test_trainer.py tests/backtest/test_engine.py tests/test_clv.py -q`
Expected: FAIL on new signatures/assertions.

- [ ] **Step 3: Implement**

In `trainer._market_probs()`, remove `total_maps`, `map_handicap`, `map_winner` branches; keep `total_points`, `total_games`, `spread`, `set_handicap`. Restrict `_elo`/`_glicko` to `"tennis"` on load and save. Change `BacktestEngine.run()` to `(start, end)` with fixed tennis filtering; update `run_with_duplicates` similarly. Remove `by_sport` from `clv_report()`. Update all internal callers.

- [ ] **Step 4: Run to verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/models/test_trainer.py tests/backtest/test_engine.py tests/test_clv.py -q`
Expected: all passed.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/models/trainer.py src/betdash/backtest/engine.py src/betdash/backtest/clv.py tests/models/test_trainer.py tests/backtest/test_engine.py tests/test_clv.py
git commit -m "feat: make trainer, backtest and CLV tennis-only"
```

---

### Task 5: Dashboard tennis-only

**Files:**
- Modify: `src/betdash/app/dashboard.py`
- Create: `tests/app/test_dashboard_tennis_only.py`

**Interfaces:**
- Consumes: `BacktestEngine.run(start, end)` from Task 4; `opportunity_feed()` and `last_snapshots()` from `Repository`.
- Produces: dashboard has no sport selector and filters every displayed row to tennis.

- [ ] **Step 1: Write failing test**

```python
def test_tennis_filter_drops_other_sports():
    rows = [{"sport": "tennis", "event": "e1"},
            {"sport": "basketball", "event": "e2"}]
    assert tennis_only(rows) == [{"sport": "tennis", "event": "e1"}]
```

Also add a source-level assertion that `selectbox("Спорт")` is absent from `dashboard.py`.

- [ ] **Step 2: Run to verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/app/test_dashboard_tennis_only.py -v`
Expected: FAIL because `tennis_only` is missing.

- [ ] **Step 3: Implement**

Add `TENNIS_ONLY_SPORT = "tennis"` and `tennis_only(rows)` in `dashboard.py`. Apply it to opportunity feed, market depth, model diagnostics and backtest outputs. Remove the sport `selectbox` and every `sport=` argument to `engine.run()`. Change headings/sort priority copy to tennis.

- [ ] **Step 4: Run to verify GREEN**

Run: `PYTHONPATH=src .venv/bin/pytest tests/app/test_dashboard_tennis_only.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/betdash/app/dashboard.py tests/app/test_dashboard_tennis_only.py
git commit -m "feat: make dashboard tennis-only"
```

---

### Task 6: Tests, fixtures and docs sweep

**Files:**
- Modify: `tests/adapters/fixtures/*.json`
- Modify: `tests/models/test_trainer.py`, `tests/normalize/test_registry.py`, `tests/backtest/test_engine.py`
- Modify: `docs/superpowers/specs/2026-11-26-betting-dashboard-design.md`
- Modify: `docs/superpowers/plans/2026-11-26-betting-dashboard.md`
- Modify: `README.md`
- Create: `tests/test_tennis_only_audit.py`

**Interfaces:**
- Consumes: all prior tasks.
- Produces: repository-wide audit test; old docs marked superseded.

- [ ] **Step 1: Write failing audit test**

```python
BANNED = ("basketball", "dota2", "cs2", "NBA", "football", "hockey", "map_winner", "total_maps", "map_handicap")
ALLOW = {"tests/db/test_tennis_migration.py"}

def test_src_has_no_non_tennis_tokens():
    for path in Path("src/betdash").rglob("*.py"):
        assert not [t for t in BANNED if t in path.read_text()]
```

- [ ] **Step 2: Run to verify RED**

Run: `PYTHONPATH=src .venv/bin/pytest tests/test_tennis_only_audit.py -v`
Expected: FAIL while old tokens remain.

- [ ] **Step 3: Clean fixtures/tests/docs**

Remove basketball/dota/cs2/NBA cases from test bodies and fixture JSON. Keep migration tests that intentionally construct non-tennis rows. Add to old spec and plan: `Scope superseded by docs/superpowers/specs/2026-11-27-tennis-only-design.md`. Update README to say tennis-only.

- [ ] **Step 4: Run full suite**

Run: `PYTHONPATH=src .venv/bin/pytest -q`
Expected: all passed, `259+` tests.

- [ ] **Step 5: Commit**

```bash
git add tests docs README.md
git commit -m "chore: finish tennis-only test and docs sweep"
```

---

### Task 7: Live migration, verification and archive removal

**Files:**
- Execute: `src/betdash/db/tennis_migration.py::main`
- Execute: `src/betdash/db/tennis_migration.py::migrate_checkpoint`
- No source files changed.

**Interfaces:**
- Consumes: Task 1 helpers, Task 6 green suite.
- Produces: working DB tennis-only; archive removed.

- [ ] **Step 1: Pre-flight audit**

Run and save output:

```bash
python3 - <<'PY'
import sqlite3
c=sqlite3.connect('data/betdash.sqlite')
for q in [
 "SELECT sport, COUNT(*) FROM canonical_events GROUP BY sport",
 "SELECT COUNT(*) FROM odds_snapshots s LEFT JOIN canonical_events e ON e.event_uid=s.event_uid WHERE e.event_uid IS NULL",
 "SELECT COUNT(*) FROM odds_snapshots",
 "SELECT COUNT(*) FROM predictions",
]:
    print(q, c.execute(q).fetchall())
PY
```

Expected: basketball rows and 65 236 orphans present before migration.

- [ ] **Step 2: Stop writers and checkpoint WAL**

```bash
pkill -f "streamlit run src/betdash/app/dashboard_page.py" || true
python3 - <<'PY'
import sqlite3
c=sqlite3.connect('data/betdash.sqlite')
print(c.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone())
PY
```

Expected: no Streamlit process; checkpoint returns `(0, 0, 0)`.

- [ ] **Step 3: Run archive-and-purge**

```bash
PYTHONPATH=src .venv/bin/python -c "from pathlib import Path; from betdash.db.repository import Repository; from betdash.db.tennis_migration import archive_and_purge_non_tennis, migrate_checkpoint; repo=Repository('data/betdash.sqlite'); print(archive_and_purge_non_tennis(repo, Path('data/archive/non-tennis-2026-11-27.sqlite'))); print(migrate_checkpoint(Path('data/checkpoints/trainer_checkpoint.json')))"
```

Expected: counts include 769 canonical events, 1 996 356 snapshots, 6 406 predictions, 2 968 closing lines, 7 864 per-book lines, 65 236 orphans.

- [ ] **Step 4: Post-migration audit**

Run the same queries as Step 1.

Expected: only `tennis` in `canonical_events`; orphan count `0`; snapshot count reduced by ~2 061 592; checkpoint `elo`/`glicko` only have `"tennis"`.

- [ ] **Step 5: Full suite and smoke restart**

```bash
PYTHONPATH=src .venv/bin/pytest -q
nohup env PYTHONPATH=src .venv/bin/python -m streamlit run src/betdash/app/dashboard_page.py --server.headless true --server.port 8501 > /tmp/betdash-streamlit.log 2>&1 &
```

Expected: suite green; dashboard starts; no sport selector visible.

- [ ] **Step 6: Remove the archive**

```bash
rm -f data/archive/non-tennis-2026-11-27.sqlite
```

Expected: archive gone; working DB remains tennis-only. This is the planned A → B transition.

- [ ] **Step 7: Final commit**

No tracked source changed in this task. Confirm with:

```bash
git status --short
git log -1 --oneline
```

Expected: only pre-existing unrelated untracked files remain; HEAD points to Task 6 commit.
