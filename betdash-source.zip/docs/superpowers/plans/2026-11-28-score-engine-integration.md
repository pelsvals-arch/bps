# Score Engine Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Wire empirical and Markov score distributions into storage, trainer and dashboard, then blend them using OOF evaluation.

**Architecture:** Add score-distribution storage and provider modules around the existing `betdash.tennis` contract. Empirical and Markov providers produce `dict[ScoreAtom, float]`; a blend provider combines them; trainer saves all three per event; dashboard derives market probabilities from the selected provider.

**Tech Stack:** Python 3 stdlib, pytest, existing SQLite schema and Streamlit dashboard.

**Spec:** `docs/superpowers/specs/2026-11-28-score-engine-integration-design.md`

## Global Constraints

- Work in worktree `.worktrees/impl`, branch `impl`.
- TDD: every production change follows a red test observed first.
- Tennis-only runtime; no new runtime dependencies; no paid APIs.
- Existing predictions, CLV and OOF metrics remain unchanged.
- Documentation and answers in Russian.

## Review Focus

- Sackmann history must be oriented to canonical `p1` and strictly pre-event — pinned by Task 2 temporal/orientation test.
- Markov simulation must produce a valid distribution for BO3/BO5 and strong-player dominance — pinned by Task 3 tests.
- Blend must preserve total mass and be selected by OOF loss, not by hand — pinned by Task 4 tests.
- Trainer must add distributions without changing existing prediction rows — pinned by Task 5 compatibility test.
- Dashboard must show one row per match/market with best bookmaker and must not claim value without market probability — pinned by Task 6 tests.

---

### Task 1: Score distribution storage

**Files:**
- Modify: `src/betdash/db/schema.sql`
- Modify: `src/betdash/db/repository.py`
- Test: `tests/db/test_score_distribution_storage.py`

**Interfaces:**
- Consumes: `Repository` and schema conventions.
- Produces: `save_score_distribution(row: Mapping[str, Any]) -> None`, `score_distributions(event_uid: str | None = None, model_run_id: str | None = None) -> list[dict[str, Any]]`; table `score_distributions` with `provider in {empirical, markov, blend}`.

- [ ] **Step 1: Write failing tests for save/load and schema**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/db/test_score_distribution_storage.py -v`; expect ImportError/AttributeError**
- [ ] **Step 3: Add table and repository methods with JSON serialization**
- [ ] **Step 4: Run targeted tests; expect PASS**
- [ ] **Step 5: Commit `feat: store tennis score distributions`**

---

### Task 2: Empirical provider from Sackmann history

**Files:**
- Create: `src/betdash/tennis/empirical_provider.py`
- Test: `tests/tennis/test_empirical_provider.py`

**Interfaces:**
- Consumes: `Repository`, `ScoreAtom`, `empirical_score_distribution`, Sackmann schema.
- Produces: `sackmann_history_rows(repo, p1, p2, target, limit=2000) -> list[dict[str, Any]]` and `empirical_provider_distribution(repo, p1, p2, target) -> dict[ScoreAtom, float]`.

- [ ] **Step 1: Write failing tests for orientation and strict pre-event filtering**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_empirical_provider.py -v`; expect ModuleNotFoundError**
- [ ] **Step 3: Implement SQL fetch, name canonicalization, p1 orientation and provider call**
- [ ] **Step 4: Run targeted tests; expect PASS**
- [ ] **Step 5: Commit `feat: add empirical score distribution provider`**

---

### Task 3: Markov score distribution provider

**Files:**
- Create: `src/betdash/tennis/markov.py`
- Test: `tests/tennis/test_markov.py`

**Interfaces:**
- Consumes: `ScoreAtom`, serve statistics mapping with `svc_pts`, `svc_won`, `ret_pts`, `ret_won`.
- Produces: `point_probability_from_serve(stats: Mapping[str, float]) -> float`, `markov_score_distribution(p1_point_prob: float, p2_point_prob: float, best_of: int = 3, simulations: int = 2000, seed: int = 7) -> dict[ScoreAtom, float]`.

- [ ] **Step 1: Write failing tests for valid BO3/BO5 distribution and strong-player dominance**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_markov.py -v`; expect ModuleNotFoundError**
- [ ] **Step 3: Implement point-to-game recursion and deterministic set/match simulation**
- [ ] **Step 4: Run targeted tests; expect PASS**
- [ ] **Step 5: Commit `feat: add Markov tennis score distribution provider`**

---

### Task 4: Blend and OOF provider comparison

**Files:**
- Create: `src/betdash/tennis/blend.py`
- Test: `tests/tennis/test_blend.py`

**Interfaces:**
- Consumes: provider distributions and OOF pairs with `empirical`, `markov`, `actual`.
- Produces: `blend_score_distributions(empirical: Mapping[ScoreAtom, float], markov: Mapping[ScoreAtom, float], weight: float) -> dict[ScoreAtom, float]`; `fit_blend_weight(pairs: Sequence[Mapping[str, Any]]) -> tuple[float, dict[str, float]]` returning weight and per-provider log loss.

- [ ] **Step 1: Write failing tests for mass preservation and OOF-selected weight**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/tennis/test_blend.py -v`; expect ModuleNotFoundError**
- [ ] **Step 3: Implement normalized mixture and grid search by match-winner log loss**
- [ ] **Step 4: Run targeted tests; expect PASS**
- [ ] **Step 5: Commit `feat: blend empirical and Markov score distributions`**

---

### Task 5: Trainer integration

**Files:**
- Modify: `src/betdash/models/trainer.py`
- Test: `tests/models/test_trainer_score_distributions.py`

**Interfaces:**
- Consumes: `Repository`, provider functions from Tasks 2–4, `p1_prob` from existing model.
- Produces: `build_score_distribution_rows(event, repo, p1_prob, model_run_id, observed_at) -> list[dict[str, Any]]` with three rows (`empirical`, `markov`, `blend`) and `blend_weight` stored in run state.

- [ ] **Step 1: Write failing test that existing predictions stay unchanged and three distribution rows are produced**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/models/test_trainer_score_distributions.py -v`; expect ImportError**
- [ ] **Step 3: Add helper and call it from `_generate_predictions` without changing existing prediction rows**
- [ ] **Step 4: Run targeted tests and full suite; expect PASS**
- [ ] **Step 5: Commit `feat: generate score distributions during training`**

---

### Task 6: Dashboard score markets screen

**Files:**
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/app/test_dashboard_score_markets.py`

**Interfaces:**
- Consumes: `Repository.score_distributions`, `market_probabilities`, fresh non-live `last_snapshots`.
- Produces: `score_market_rows(distributions, snapshots, provider) -> list[dict[str, Any]]`; page `"Score markets"` showing one row per `(event_uid, market, line)` with best odds/bookmaker and no value column unless market probability is valid.

- [ ] **Step 1: Write failing tests for one-row-per-market aggregation and no-value-without-market**
- [ ] **Step 2: Run `PYTHONPATH=src .venv/bin/pytest tests/app/test_dashboard_score_markets.py -v`; expect ImportError**
- [ ] **Step 3: Implement helper, provider selector and Streamlit page**
- [ ] **Step 4: Run targeted tests and full suite; expect PASS**
- [ ] **Step 5: Commit `feat: show score-derived markets in dashboard`**

---

### Task 7: Verification

- [ ] **Step 1: Run full suite** `PYTHONPATH=src .venv/bin/pytest -q`; expect all green.
- [ ] **Step 2: Check Streamlit health** `curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8501/healthz`; expect `200`.
- [ ] **Step 3: Record completion in ledger; no production changes.**
