# Review-driven hardening implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair the measurement loop and wire review-driven fixes into the tennis score pipeline.

**Architecture:** Generate Sackmann aliases, link predictions to results, replace legacy score handling with the tennis parser, pass surface/best_of context, then improve Markov and OOF performance.

**Tech Stack:** Python 3.12, pytest, SQLite, Streamlit (unchanged).

**Spec:** `docs/superpowers/specs/2026-11-28-review-driven-hardening-design.md`

## Global Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD: production change only after an observed failing test.
- Tennis-only runtime; no new runtime dependencies; no paid APIs.
- Do not alter CLV or close-line semantics.
- Full suite must remain green after every task.

## Review Focus

- Prediction-result linking must require both participant pair and UTC date — pinned by Task 2.
- Legacy winner-side helpers must no longer score tennis predictions — pinned by Task 3.
- Surface and best_of must be real values, not placeholders — pinned by Task 4.
- Markov probabilities must distinguish p1/p2 hold and tiebreak — pinned by Task 5.
- OOF work must be reused and blend lookup must be indexed — pinned by Task 6.

---

### Task 1: Generate Sackmann player aliases

**Files:**
- Create: `src/betdash/normalize/alias_generator.py`
- Modify: `src/betdash/normalize/sackmann_aliases.json`
- Test: `tests/normalize/test_alias_generator.py`

**Interfaces:**
- Consumes: `Repository`, `sackmann_matches`.
- Produces: `sackmann_alias_variants(name: str) -> set[str]`, `generate_sackmann_aliases(repo) -> dict[str, list[str]]`, `write_sackmann_aliases(repo, path: str | Path | None = None) -> Path`.

- [ ] Step 1: failing test for `F Last`, `F. Last`, `Last F`, `Last F.` variants and preserved manual overrides.
- [ ] Step 2: run targeted pytest; expect ModuleNotFoundError.
- [ ] Step 3: implement reader/writer with deterministic sorted aliases.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `feat: generate Sackmann player aliases`.

---

### Task 2: Link predictions to results

**Files:**
- Modify: `src/betdash/db/schema.sql`, `src/betdash/db/repository.py`
- Create: `src/betdash/analytics/prediction_links.py`
- Modify: `src/betdash/analytics/prediction_outcomes.py`
- Test: `tests/analytics/test_prediction_result_links.py`

**Interfaces:**
- Consumes: `predictions`, `canonical_events`, `results`, alias map.
- Produces: `link_prediction_results(repo) -> dict[str, int]`; table `prediction_result_links(prediction_event_uid, result_event_uid, confidence, PRIMARY KEY(...))`; `backfill_prediction_outcomes()` uses links when direct join has no result.

- [ ] Step 1: failing test with prediction event and result event differing by uid but matching participant pair/date.
- [ ] Step 2: run targeted pytest; expect missing module/method.
- [ ] Step 3: implement normalized-pair/date matching and repository storage; wire backfill fallback.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `feat: link predictions to results by participants and date`.

---

### Task 3: Use tennis score parser everywhere

**Files:**
- Modify: `src/betdash/backtest/engine.py`
- Modify: `src/betdash/analytics/prediction_outcomes.py`
- Modify: `src/betdash/models/trainer.py`
- Modify: `src/betdash/models/features.py`
- Test: `tests/tennis/test_score_parser_wiring.py`

**Interfaces:**
- Consumes: `parse_tennis_score`, `resolve_tennis_market`.
- Produces: tennis score settlement uses parser; `winner_side_from_score` remains only as fallback.

- [ ] Step 1: failing source + behavior tests for each of four call sites and a retirement scoreline.
- [ ] Step 2: run targeted pytest; expect assertion failures.
- [ ] Step 3: replace legacy calls with parser-based settlement.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `feat: use tennis score parser across scoring paths`.

---

### Task 4: Pass surface and best_of context

**Files:**
- Modify: `src/betdash/models/features.py`
- Modify: `src/betdash/tennis/empirical_provider.py`
- Modify: `src/betdash/tennis/markov.py`
- Test: `tests/tennis/test_match_context.py`

**Interfaces:**
- Consumes: Sackmann `surface`, `best_of`, `build_features`.
- Produces: `features['surface']` as string (`Hard`/`Clay`/`Grass`) and `features['best_of']` as int 3/5, used by providers.

- [ ] Step 1: failing test that placeholder surface=0.0 and missing best_of produce real context.
- [ ] Step 2: run targeted pytest; expect assertion failure.
- [ ] Step 3: populate context from Sackmann rows and use it in providers.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `feat: pass real surface and best_of to score models`.

---

### Task 5: Serve-aware Markov model

**Files:**
- Modify: `src/betdash/tennis/markov.py`
- Test: `tests/tennis/test_markov_serve_aware.py`

**Interfaces:**
- Consumes: `p1_point_prob`, `p2_point_prob`, serve/hold stats.
- Produces: separate p1/p2 game-hold probabilities and tiebreak rotation; `markov_score_distribution` signature extended with optional `tiebreak=True`.

- [ ] Step 1: failing test that asymmetric hold rates change winner probability and tiebreak rotation is used.
- [ ] Step 2: run targeted pytest; expect assertion failure.
- [ ] Step 3: implement analytic hold/set probabilities and deterministic simulation.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `feat: make Markov model serve-aware`.

---

### Task 6: Reuse OOF work and index blend pairs

**Files:**
- Modify: `src/betdash/models/trainer.py`
- Modify: `src/betdash/tennis/blend.py`
- Test: `tests/tennis/test_oof_performance.py`

**Interfaces:**
- Consumes: `_walk_forward_oof_rows`, `fit_blend_weight_from_repository`.
- Produces: one OOF pass per trainer step; blend pairs indexed by `event_uid`.

- [ ] Step 1: failing test/count assertion for `_walk_forward_oof_rows` call count and indexed lookup.
- [ ] Step 2: run targeted pytest; expect assertion failure.
- [ ] Step 3: thread precomputed rows through metrics and blend fitting; replace nested scans with dict index.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `perf: reuse OOF rows and index blend pairs`.

---

### Task 7: Python version pin

**Files:**
- Modify: `pyproject.toml`
- Test: `tests/test_project_metadata.py`

**Interfaces:**
- Consumes: project metadata.
- Produces: `requires-python = ">=3.12,<3.13"`.

- [ ] Step 1: failing test reading `pyproject.toml`.
- [ ] Step 2: run targeted pytest; expect assertion failure.
- [ ] Step 3: change version constraint.
- [ ] Step 4: targeted PASS and full suite PASS.
- [ ] Step 5: commit `chore: pin supported Python version`.

---

### Task 8: Verification

- [ ] Full suite: `PYTHONPATH=src .venv/bin/pytest -q`.
- [ ] Streamlit health: `curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8501/healthz`.
- [ ] Run live link report and record counts in ledger.
