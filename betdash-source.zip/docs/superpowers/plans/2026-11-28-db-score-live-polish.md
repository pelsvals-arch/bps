# DB boundary, score-market and live-cache polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Harden the repository boundary, make score-market aliases visible, and make the SofaScore live screen resilient.

**Architecture:** Replace private connection calls with one public context manager, remove duplicated DDL, enrich score-market rows with canonical market names, and add a short TTL cache around the existing live client.

**Tech Stack:** Python 3.12, SQLite, pytest, Streamlit.

**Spec:** `docs/superpowers/specs/2026-11-28-db-score-live-polish-design.md`

## Global Constraints

- Work only in `.worktrees/impl`, branch `impl`.
- Use TDD RED→GREEN for every behavior change.
- Run the full `pytest` suite before each commit.
- Do not modify unrelated dirty/untracked files.
- Preserve tennis-only behavior and Moscow-time dashboard formatting.

## Review Focus

- A caller using a connection outside a context manager must still work.
- Legacy databases must gain `prediction_result_links` from `schema.sql`.
- Score-market aliases must not change settlement semantics.
- A transient SofaScore error must not clear the last good scoreboard.
- TTL cache must not hide new live events beyond the chosen window.

---

### Task 1: Public repository connection API

**Files:**
- Modify: `src/betdash/db/repository.py`
- Modify all `src/betdash/**/*.py` callers of `._connect()`
- Test: `tests/db/test_repository_connection_api.py`

**Interfaces:**
- Produces: `Repository.connection() -> ContextManager[sqlite3.Connection]`.

- [ ] **Step 1: Write failing audit/behavior test**
  Assert `connection` is decorated with `contextmanager` and no `._connect()` occurs in production files outside `repository.py`.

- [ ] **Step 2: Run it**
  Expected: FAIL on decorator/source assertions.

- [ ] **Step 3: Implement**
  Move `@contextmanager` to `connection()`; keep `_connect` as compatibility alias; migrate external callers.

- [ ] **Step 4: Run targeted and full suite**
  Expected: PASS.

- [ ] **Step 5: Commit**
  `refactor: use public repository connection API`

### Task 2: Deduplicate prediction-result-links schema

**Files:**
- Modify: `src/betdash/analytics/prediction_links.py`
- Test: `tests/analytics/test_prediction_result_links.py`

**Interfaces:**
- Consumes: `Repository.connection()` from Task 1.

- [ ] **Step 1: Write failing test**
  Assert DDL for `prediction_result_links` exists only in `schema.sql`.

- [ ] **Step 2: Run it**
  Expected: FAIL.

- [ ] **Step 3: Implement**
  Remove the runtime `CREATE TABLE` block; rely on `init_db()`.

- [ ] **Step 4: Run targeted and full suite**
  Expected: PASS.

- [ ] **Step 5: Commit**
  `refactor: deduplicate prediction link schema`

### Task 3: Score-market canonical names

**Files:**
- Modify: `src/betdash/tennis/markets.py`
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/app/test_dashboard_score_markets.py`

**Interfaces:**
- Produces: public `canonical_tennis_market(market: str) -> str`; score rows with `market_canonical`.

- [ ] **Step 1: Write failing test**
  Snapshot markets `total_points` and `spread` produce rows with `market_canonical` equal to `total_games` and `game_handicap`.

- [ ] **Step 2: Run it**
  Expected: FAIL on missing key.

- [ ] **Step 3: Implement**
  Add `market_canonical` to `score_market_rows()`; show it in the Score markets table.

- [ ] **Step 4: Run targeted and full suite**
  Expected: PASS.

- [ ] **Step 5: Commit**
  `feat: expose canonical score market names`

### Task 4: Live scoreboard cache

**Files:**
- Modify: `src/betdash/live/sofascore.py`
- Modify: `src/betdash/live/__init__.py`
- Modify: `src/betdash/app/dashboard.py`
- Test: `tests/live/test_sofascore.py`

**Interfaces:**
- Produces: `fetch_live_events_cached(sport, opener=urlopen, ttl_seconds=30, now=None)`.

- [ ] **Step 1: Write failing tests**
  Cover cache hit within TTL, refetch after TTL, and last-good fallback on error.

- [ ] **Step 2: Run them**
  Expected: FAIL on missing function.

- [ ] **Step 3: Implement**
  Add a small module-level cache keyed by sport; return last successful rows on fetch error; use it in the live screen.

- [ ] **Step 4: Run targeted and full suite**
  Expected: PASS.

- [ ] **Step 5: Commit**
  `feat: cache live scoreboard responses`

### Task 5: Final verification

- [ ] Run full suite.
- [ ] Check dashboard `/healthz` returns 200.
- [ ] Run a final fresh reviewer over the plan range if available.
- [ ] Apply RED→GREEN fixes for Critical/Important findings.
- [ ] Delete plan workspace after clean verification.
