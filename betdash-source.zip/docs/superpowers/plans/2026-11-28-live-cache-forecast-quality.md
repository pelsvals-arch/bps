# Live Cache and Forecast Quality Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use executing-plans or subagent-driven-development task-by-task.

**Goal:** Harden live caching and produce an honest forecast-quality report.

**Architecture:** Cache changes stay in `betdash.live.sofascore`; dashboard only renders a stale flag. Forecast quality is a new analytics helper built on existing link/outcome/calibration helpers.

**Tech Stack:** Python 3.12, pytest, SQLite, Streamlit.

**Spec:** `docs/superpowers/specs/2026-11-28-live-cache-forecast-quality-design.md`

## Global Constraints
- Worktree `.worktrees/impl`, branch `impl`.
- TDD: production changes require a failing test first.
- Full `pytest` suite stays green.
- `fetch_live_events()` stays backward compatible.
- Do not touch unrelated dirty tracked files.

## Review Focus
- Monotonic default clock — Task 1 source test.
- Bounded stale fallback — Task 1 behavior test.
- Cache rows copied — Task 1 mutation test.
- Legacy DB link table from `init_db()` — Task 2 functional test.
- No false OOF claim — Task 3 report fields.

---

### Task 1: Harden live cache
**Files:** `src/betdash/live/sofascore.py`, `tests/live/test_sofascore.py`
**Produces:** `fetch_live_events_cached(sport, opener=urlopen, ttl_seconds=30, max_fallback_age_seconds=300, now=None) -> list[dict]`.

- [ ] RED tests: monotonic default source assertion, `_stale` flag on fallback, fallback stops after max age, returned rows are copies.
- [ ] GREEN: use `time.monotonic()`, store timestamp with rows, mark/copy returned rows, bound fallback to `ttl + max_fallback_age_seconds`.
- [ ] Run targeted tests, full suite, commit `feat: harden live scoreboard cache`.

### Task 2: Dashboard stale badge and legacy DDL
**Files:** `src/betdash/app/dashboard.py`, `tests/app/test_dashboard_live_stale.py`, `tests/analytics/test_prediction_result_links.py`
- [ ] RED: dashboard source contains stale warning; legacy DB without `prediction_result_links` gets table via `init_db()` and then links one prediction.
- [ ] GREEN: render warning when any live row has `_stale`; keep DDL in schema only.
- [ ] Run targeted tests, full suite, commit `feat: surface stale live data`.

### Task 3: Forecast quality report
**Files:** create `src/betdash/analytics/forecast_quality.py`, `tests/analytics/test_forecast_quality.py`, modify `src/betdash/analytics/__init__.py`
**Produces:** `forecast_quality_report(repo) -> dict`.
- [ ] RED: report links/settles rows, computes model Brier/log-loss, derives market probabilities from paired odds, excludes incomplete pairs, and labels sample as historical not OOF.
- [ ] GREEN: implement helper using `link_prediction_results`, `backfill_prediction_outcomes`, `calibration_report`, and `market_comparison`.
- [ ] Run targeted tests, full suite, commit `feat: add honest forecast quality report`.

### Task 4: Verification
- [ ] Full suite green; Streamlit `/healthz` 200.
- [ ] `task-done`, final review, cleanup.
