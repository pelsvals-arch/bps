# Collector Throughput Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Poll bookmaker adapters concurrently and persist normalized snapshots in one deterministic batch, then document a bounded read-only endpoint spike.

**Architecture:** `Collector.poll_once()` keeps its public signature and global polling lock. Adapter fetches run in a bounded `ThreadPoolExecutor`; results are merged in adapter order. Normalization produces snapshots and canonical events in memory, deduplicates them, then writes one canonical-event batch and one snapshot batch.

**Tech Stack:** Python 3 stdlib `concurrent.futures`, existing SQLite repository, pytest.

**Spec:** `docs/superpowers/specs/2026-11-27-collector-throughput-design.md`

## Global Constraints

- Worktree `.worktrees/impl`, branch `impl`.
- TDD RED→GREEN; full suite after every task.
- `max_workers = min(4, len(adapters))`.
- Preserve adapter order when merging fetched results.
- No mobile app runtime, emulator, certificate bypass, credentials, paid API or live-odds ingestion.

## Review Focus

- Adapter fetch failure must not block other adapters — `tests/ingest/test_collector.py::test_parallel_fetch_isolates_adapter_exception`.
- Deterministic merge order must not depend on completion order — `tests/ingest/test_collector.py::test_parallel_fetch_preserves_adapter_order`.
- Duplicate snapshots must be removed with a stable key — `tests/ingest/test_collector.py::test_poll_once_deduplicates_snapshots`.
- Canonical events must be upserted once per unique event and snapshots once per poll — `tests/ingest/test_collector.py::test_poll_once_batches_writes`.
- Endpoint spike must remain read-only R&D, not runtime source — `tests/research/test_collector_endpoint_spike.py::test_endpoint_spike_is_read_only`.

---

### Task 1: Parallel adapter fetches

**Files:**
- Modify: `src/betdash/ingest/collector.py`
- Test: `tests/ingest/test_collector.py`

**Interfaces:**
- Produces: `Collector._fetch_all_adapters() -> list[tuple[Any, str, list[RawOdd] | None, str | None]]`; adapter order preserved, error text in the fourth field.

- [ ] **Step 1: Write failing tests**

Add `test_parallel_fetch_preserves_adapter_order` and `test_parallel_fetch_isolates_adapter_exception` using fake adapters with an event barrier and different sleeps so the slowest adapter is first.

- [ ] **Step 2: Run tests**

Run: `PYTHONPATH=src .venv/bin/pytest tests/ingest/test_collector.py -q`
Expected: FAIL with missing `_fetch_all_adapters`.

- [ ] **Step 3: Implement bounded parallel fetch**

Use `ThreadPoolExecutor(max_workers=min(4, len(self.adapters)))`, submit each adapter in list order, then consume futures in submission order. Catch exceptions per adapter and return `raw_odds=None` with `"Type: message"`.

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: fetch bookmaker adapters in parallel"`

### Task 2: Batched deterministic writes

**Files:**
- Modify: `src/betdash/ingest/collector.py`
- Test: `tests/ingest/test_collector.py`

**Interfaces:**
- Consumes: `Collector._fetch_all_adapters()` from Task 1.
- Produces: `Collector._dedupe_snapshots(snapshots: list[Snapshot]) -> list[Snapshot]`; `poll_once()` calls `save_snapshots()` at most once.

- [ ] **Step 1: Write failing tests**

Add `test_poll_once_batches_writes` using a recording repository: two adapters, overlapping events, expect one `save_snapshots` call and one upsert per unique `event_uid`. Add `test_poll_once_deduplicates_snapshots` with the same raw quote repeated twice.

- [ ] **Step 2: Run tests**

Expected: FAIL because writes are still per adapter and duplicates remain.

- [ ] **Step 3: Implement batching**

Collect normalized events in a dict keyed by `event_uid`, collect snapshots across adapters, dedupe by `(event_uid, bookmaker, market, outcome, line, observed_at, source_event_id, adapter_version)` after sorting by the same key, upsert events once each, then call `save_snapshots()` once. Keep live-rows skip and health marking semantics.

- [ ] **Step 4: Run tests**

Expected: targeted PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "feat: batch collector snapshot writes"`

### Task 3: Read-only endpoint spike report

**Files:**
- Create: `docs/research/2026-11-27-collector-endpoint-spike.md`
- Test: `tests/research/test_collector_endpoint_spike.py`

**Interfaces:**
- Produces: research report with Winline `/api/xds/v2/...` and `/api/cls/...`, Fonbet `/events/listBase` and `/events/event`, and explicit conclusion that mobile apps are not a runtime source.

- [ ] **Step 1: Write failing test**

Assert the report exists and contains both Winline and Fonbet endpoint strings plus `not a runtime source`.

- [ ] **Step 2: Run test**

Expected: FAIL with missing report.

- [ ] **Step 3: Write report**

Summarize Firecrawl findings, current adapter overlap, ToS/pinning risk, why paid APIs are out of scope, and a bounded next experiment: compare one public endpoint response with current adapter output for one match.

- [ ] **Step 4: Run test**

Expected: PASS; full suite PASS.

- [ ] **Step 5: Commit**

`git commit -m "docs: record collector endpoint spike findings"`

### Task 4: Final verification

- [ ] **Step 1:** Run `PYTHONPATH=src .venv/bin/pytest -q`.
- [ ] **Step 2:** Check Streamlit health on `:8501`.
- [ ] **Step 3:** Record results in ledger, final review, present finishing menu.
