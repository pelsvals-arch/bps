# Исследование: книги, ML/AI-модели и формулы для ставок на теннис

Дата: 2026-11-27. Источники собраны через Firecrawl (conversation `b7f2b105-6f84-43e3-a34c-42f5b34ed28e`) и несколько уточняющих поисков (`1ab98473-64b6-4897-a798-9a0ff9aa51d7`). Отчёт описывает применимое к локальному BetDash, а не обещание прибыли.

## Executive summary

Надёжная теннисная модель должна быть не столько «сложным AI», сколько аккуратной вероятностной системой: чистые входные данные до начала матча, прозрачные рейтинговые/паред-сравнительные базовые модели, хронологический walk-forward, калибровка на out-of-fold прогнозах и сравнение с de-vigged линией букмекера. Литература и бенчмарки сходятся: самые сильные одиночные признаки часто уже заложены в рынок, а closing odds остаются более сильным бейзлайном, чем большинство моделей ([Pinnacle ATP closing market](https://www.pinnacle.com/betting-resources/en/tennis/how-efficient-is-the-atp-tennis-betting-market/uru25k89x26gmh62), [Wilkens](https://journals.sagepub.com/doi/pdf/10.3233/JSA-200463)). Внутренняя цель BetDash — честно измерить Brier/log loss и calibrated edge, а не «попасть каждый матч».

## Книги

| Книга | Автор/год | Почему полезно | Источник |
|---|---|---|---|
| Sharp Sports Betting | Stanford Wong, 2001/2021 ed. | Математика линий, spreads, moneylines и discipline; базовая книга по поиску edge | [Huntington Press](http://huntingtonpress.com/sharp-sports-betting/), [Unabated list](https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor) |
| The Logic of Sports Betting | Ed Miller & Matthew Davidow, 2017/2019 ed. | Как букмекер строит линию; почему сравнение с рынком важнее «accuracy» | [Barnes & Noble](https://www.barnesandnoble.com/w/the-logic-of-sports-betting-matthew-davidow/1131634561) |
| Squares & Sharps | Jack Buchdahl, 2016 | Практика оценки линий и bankroll process | [Unabated list](https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor) |
| Sharper | True PokerJoe, 2016 | Процесс, дисциплина и поиск-edge | [Unabated list](https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor) |
| Statistical Sports Models in Excel | Andrew Mack, 2019/2020 | Практическая математика рейтингов и вероятностей без тяжёлого стека | [Unabated list](https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor) |
| Bayesian Sports Models in R | Andrew Mack, 2024 | Байесовские модели и shrinkage | [Unabated list](https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor) |
| The Mathematics of Gambling | Edward O. Thorp, 1984 | EV, uncertainty, bankroll-risk | [MIT Libraries](https://libraries.mit.edu/150books/2011/05/10/1984/) |
| The Oxford Handbook of the Economics of Gambling | Vaughan-Williams & Siegel, 2013 | Рыночная структура, поведение, регулирование | [Oxford](https://academic.oup.com/edited-volume/36333) |
| Statistical Thinking in Sports | Albert & Koning, 2007 | Статистические основы прогнозирования в спорте | [Routledge](https://www.routledge.com/Statistical-Thinking-in-Sports/Albert-Koning/p/book/9780367388850) |
| Forecasting the winner of a tennis match | Klaassen & Magnus, 2003 | Каноническая модель serve-point → game → set → match, in-play вероятности | [Tilburg](https://research.tilburguniversity.edu/en/publications/forecasting-the-winner-of-a-tennis-match/) |
| A Bradley–Terry type model for forecasting tennis match results | McHale & Morton, 2011 | Surface-aware paired comparison и оценка betting returns | [Elsevier](https://www.sciencedirect.com/science/article/abs/pii/S0169207010001019) |
| High dimensional dynamic model for tennis | Gorgi, Koopman & Lit, 2019 | Динамические surface-specific способности игроков | [JSTOR](https://www.jstor.org/stable/48547273) |

## Модели

| Модель | Идея | Формула/ядро | Источник |
|---|---|---|---|
| Elo | Латентная сила, вероятность из разности рейтингов | `P_i=1/(1+10^((R_j-R_i)/400))`, `R_i'=R_i+K(S_i-P_i)` | [Kovalchik comparison paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC8900648/) |
| WElo / margin-weighted Elo | Обновление сильнее при разгромном счёте | `R_i'=R_i+K·w(margin,context)·(S_i-P_i)`; локально `w=clip(((margin+5)/5)^0.4,0.75,2.0)` | [ScienceDirect](https://www.sciencedirect.com/science/article/pii/S0169207020300157), [welo R package](https://cran.hafro.is/web/packages/welo/welo.pdf) |
| Surface Elo | Отдельные hard/clay/grass рейтинги +shrinkage к общему | `logit(P)=a+b_overall(R_i-R_j)+b_surface(R_{i,s}-R_{j,s})` | [Wimbledon Elo study](https://ideas.repec.org/p/nbs/wpaper/2019-03.html) |
| Bradley–Terry | Паровое сравнение игроков через разность способностей | `P(i>j)=exp(λ_i)/(exp(λ_i)+exp(λ_j))=logit^{-1}(λ_i-λ_j)`; MLE | [McHale & Morton](https://www.sciencedirect.com/science/article/abs/pii/S0169207010001019) |
| Glicko-2 | Рейтинг + RD + volatility; неактивность увеличивает неопределённость | `g(φ)=1/sqrt(1+3φ²/π²)`; official update steps | [Glicko-2](https://glicko.net/glicko/glicko2.pdf) |
| Logistic regression | Калибруемая бинарная вероятность из разностных фич | `p=1/(1+exp(-θᵀx))`, penalized log-likelihood | [Stanford CS229 tennis report](https://cs229.stanford.edu/proj2017/final-reports/5242116.pdf) |
| Random forest / GBDT | Нелинейные взаимодействия фич; нужна калибровка | `p̂(x)=T^{-1}Σ p̂_t(x)`; `F_m=F_{m-1}+ηh_m` | [CS229](https://cs229.stanford.edu/proj2017/final-reports/5242116.pdf), [sklearn scoring](https://scikit-learn.org/stable/modules/model_evaluation.html) |
| Neural net / MLP | AI-классификатор, но легко переобучается на tennis-данных | `p=σ(W_L h_{L-1}+b_L)`, log loss + regularization | [CS229](https://cs229.stanford.edu/proj2017/final-reports/5242116.pdf) |
| Markov point→game→set→match | Точная динамика счёта при известных serve-point probabilities | `V(s)=p_sV(s_win)+(1-p_s)V(s_loss)` | [TENNISPROB](https://www.janmagnus.nl/papers/JRM065.pdf), [Imperial thesis](https://www.doc.ic.ac.uk/teaching/distinguished-projects/2012/a.madurska%20.pdf) |
| Graph / Bonacich centrality | Сила игрока по сети побед; logit поверх разности centrality | `b∝Ab`; `p=logit^{-1}(α+β(b_i-b_j))` | [PMC8900648](https://pmc.ncbi.nlm.nih.gov/articles/PMC8900648/) |

## Математические формулы, которые можно адаптировать

- **De-vig, multiplicative:** `q_i=1/O_i`, `S=Σq_i`, `p_i=q_i/S`, `overround=S−1`. [CRAN implied](https://cran.r-project.org/web/packages/implied/refman/implied.html)
- **Power de-vig:** `p_i=q_i^k/Σ_j q_j^k`, `k` оценивается исторически. [Clarke/Kovalchik/Ingram](https://figshare.swinburne.edu.au/articles/journal_contribution/Adjusting_bookmaker_s_odds_to_allow_for_overround/26295688)
- **Shin de-vig:** решить `Σ_i [sqrt(z²+4(1−z)q_i²/Q)−z]/[2(1−z)]=1`, `Q=Σq_i`; [CRAN implied](https://cran.r-project.org/web/packages/implied/refman/implied.html), [ImpliedScore](https://impliedscore.com/bookmaker-margin-removal-methods/).
- **Brier:** `BS=(1/N)Σ(p_t−y_t)²`; **Log loss:** `LL=−(1/N)Σ[y_t log p_t+(1−y_t)log(1−p_t)]`. [sklearn](https://scikit-learn.org/stable/modules/model_evaluation.html)
- **Isotonic:** монотонная непараметрическая регрессия; **Platt:** `p_cal(f)=1/(1+exp(Af+B))`. [sklearn calibration](https://scikit-learn.org/stable/modules/calibration.html)
- **OOF/walk-forward:**.fit на датах `<t_k`, предсказание на следующем блоке, калибровка только на OOF, финальный нетронутый блок. [TimeSeriesSplit](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html)
- **Kelly:** `f_K=max(0,(pO−1)/(O−1))=max(0,(bp−q)/b)`; дробный `f_bet=min(cap,c·f_K)`, локально `c=0.5`, `cap=0.08`. [Swartz Kelly paper](https://www.sfu.ca/~tswartz/papers/kelly.pdf)
- **CLV:** `O_entry/O_close−1` при том же selections/рынке/закрытии. [Sportmonks](https://www.sportmonks.com/glossary/closing-line-value-clv/)
- **EV/ROI:** `EV=p(O−1)−(1−p)`; `ROI=Σreturns/Σstake`. [Pinnacle](https://www.pinnacle.com/betting-resources/en/tennis/how-efficient-is-the-atp-tennis-betting-market/uru25k89x26gmh62), [MDPI](https://www.mdpi.com/2227-9091/8/3/68)

## Бенчмарк (MDPI 2025, 5/3/22)

| Модель | Accuracy |
|---|---|
| Elo | 65.87% |
| Лучшая classical ML | 66.30% |
| Deep nets | 66.15–66.22% |
| Elo + ML | 67.52% |
| Bookmaker odds | 70–72% |

Elo-фичи дают +1.57–1.65 п.п.; deep nets лучше калиброваны (ECE 0.0077 против 0.0142). Вывод: важнее richness признаков и calibration, чем размер модели. [MDPI](https://www.mdpi.com/2813-2203/5/3/22)

## Adaptation decisions in BetDash

1. **WElo подключён к обновлению рейтинга:** `score_margin()` суммирует разницу по сетам (без тай-брейков), `_welo_weight` ограничен `[0.75, 2.0]`, и tainer передаёт вес в `EloRating.update(..., weight=...)` для каждого результата. Пропущенный/ничейный счёт даёт нейтральный вес 1.0.
2. **Bradley–Terry-совместимый слой:** уже существующие surface-Elo/rank/serve-return фичи подаются в логистическую модель; BT-логит используется как форма вероятности, а не как отдельный MLE-сервис.
3. **Blend честно оценён и применён:** market prior строится только из свежих (≤6 ч), не-live снимков, de-vig делается внутри каждого букмекера через `consensus_prob`, и используется только при coverage ≥ 2. `alpha` оценивается на OOF-парах `(p_model, p_market, actual)` минимизацией Brier и передаётся в генерацию прогнозов; жёсткого `0.3` и синтетических кросс-букмерных пар больше нет.
4. **Метрики и калибровка OOF:** `_walk_forward_oof()` возвращает только test-fold пары в хронологическом порядке; `brier`, `log_loss`, `hit_rate`, `calibration_bins` в model_runs и дашборде — out-of-fold. Изотonic-калибровка обучается на OOF и применяется к новым прогнозам; `market_comparison` показывает разницу OOF log-loss модели и рынка. Поля `in_sample_*` оставлены только как диагностика в JSON.
5. **Дашборд:** `market_depth()` группирует снимки по `(event_uid, market, line)`; на экран выводятся best odds, best bookmaker, coverage и сводка по исходам — без дублей по букмекерам.
6. **Staking:** Kelly информационный, считается на OOF-вероятности против реального offering odds с порогом edge 1.5% и coverage ≥ 2; автоматических ставок нет.

## Contrarian views and risks

- Closing market остаётся сильнее модели и часто калиброван; положительный edge на отобранных матчах может быть selection/multiple-testing artefact. [Pinnacle](https://www.pinnacle.com/betting-resources/en/tennis/how-efficient-is-the-atp-tennis-betting-market/uru25k89x26gmh62), [Wilkens](https://journals.sagepub.com/doi/pdf/10.3233/JSA-200463)
- Best-price hindsight: лучший кэф не всегда исполним; хранить observed_at и исключать будущую информацию.
- De-vig method меняет apparent EV; сравнить multiplicative/power/Shin до выводов об edge.
- Kelly assuming known p hazardous; использовать half-Kelly/cap и неопределённость.
- Retirements, walkovers, переназначение surface/tournament, name collisions и пост-матчевые ранги искажают labels/features.
- Live-модель point-game-set требует отдельной валидации; в текущем плане её нет.

## Sources

1. http://huntingtonpress.com/sharp-sports-betting/ — Wong, Sharp Sports Betting.
2. https://unabated.com/post/build-your-library-sports-betting-books-for-every-bettor — каталог книг.
3. https://www.barnesandnoble.com/w/the-logic-of-sports-betting-matthew-davidow/1131634561 — Miller/Davidow.
4. https://libraries.mit.edu/150books/2011/05/10/1984/ — Thorp.
5. https://academic.oup.com/edited-volume/36333 — Oxford gambling handbook.
6. https://www.routledge.com/Statistical-Thinking-in-Sports/Albert-Koning/p/book/9780367388850 — Albert/Koning.
7. https://research.tilburguniversity.edu/en/publications/forecasting-the-winner-of-a-tennis-match/ — Klaassen/Magnus 2003.
8. https://www.sciencedirect.com/science/article/abs/pii/S0169207010001019 — McHale/Morton Bradley–Terry tennis.
9. https://www.jstor.org/stable/48547273 — Gorgi/Koopman/Lit.
10. https://www.janmagnus.nl/papers/JRM065.pdf — TENNISPROB.
11. https://ideas.repec.org/p/nbs/wpaper/2019-03.html — surface Elo comparison.
12. https://pmc.ncbi.nlm.nih.gov/articles/PMC8900648/ — Elo/BT/graph tennis study.
13. https://glicko.net/glicko/glicko2.pdf — Glicko-2 spec.
14. https://cs229.stanford.edu/proj2017/final-reports/5242116.pdf — tennis ML report.
15. https://scikit-learn.org/stable/modules/calibration.html — calibration docs.
16. https://scikit-learn.org/stable/modules/model_evaluation.html — Brier/log loss docs.
17. https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html — time splits.
18. https://cran.r-project.org/web/packages/implied/refman/implied.html — de-vig methods.
19. https://figshare.swinburne.edu.au/articles/journal_contribution/Adjusting_bookmaker_s_odds_to_allow_for_overround/26295688 — overround comparison.
20. https://impliedscore.com/bookmaker-margin-removal-methods/ — Shin formula.
21. https://www.sfu.ca/~tswartz/papers/kelly.pdf — Kelly paper.
22. https://www.sportmonks.com/glossary/closing-line-value-clv/ — CLV formula.
23. https://www.pinnacle.com/betting-resources/en/tennis/how-efficient-is-the-atp-tennis-betting-market/uru25k89x26gmh62 — ATP closing market.
24. https://www.pinnacle.com/betting-resources/en/tennis/how-efficient-is-the-tennis-betting-market/u522zlsepqja8q2n — market tiers.
25. https://journals.sagepub.com/doi/pdf/10.3233/JSA-200463 — Wilkens review.
26. https://www.mdpi.com/2227-9091/8/3/68 — ANN tennis betting study.
27. https://www.mdpi.com/2813-2203/5/3/22 — Elo/ML/deep/bookmaker benchmark.
28. https://www.doc.ic.ac.uk/teaching/distinguished-projects/2012/a.madurska%20.pdf — dynamic Markov tennis thesis.

## Rerun inputs

```text
workflow: firecrawl-deep-research
topic: tennis betting books, ML/AI models, formulas and local adaptation
depth: exhaustive
output: markdown
conversationId: b7f2b105-6f84-43e3-a34c-42f5b34ed28e
```
