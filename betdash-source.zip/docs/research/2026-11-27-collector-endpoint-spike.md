# Collector endpoint spike: Winline and Fonbet

Date: 2026-11-27. Scope: read-only R&D for collector throughput. No runtime code depends on this report.

## Executive summary

Running bookmaker mobile apps as a runtime data source is not justified. Mobile apps usually call the same backend APIs as the current HTTP adapters, while adding certificate pinning, emulator/Frida fragility, account/session risk and Terms-of-Service exposure. The useful part of the mobile-app angle is a one-time traffic inspection to discover hidden delta/WebSocket endpoints. The current safe win is the collector optimization already implemented: bounded parallel fetches and batched writes.

## Findings

### Winline

A public reverse-engineering script documents HTTP endpoints used by the mobile/web client, including `/api/xds/v2/...` and `/api/cls/...`. These are candidates for a read-only one-match comparison against the current Winline adapter. They are not a stable public contract and may change without notice.

Source: `https://github.com/rpuats/fork_hunter_pro/blob/main/winline_api_reverse_engineering.py` (as surfaced by Firecrawl search).

### Fonbet

A community MCP implementation uses `GET /events/listBase` and `GET /events/event`, with odds in `customFactors[].facts/factors[]`. It explicitly notes the absence of a stable public API. These endpoints are useful to compare payload shape and update cadence with the current Fonbet adapter, but should not be treated as a supported integration.

Source: `https://github.com/FermerX/fonbet-odds-mcp` (as surfaced by Firecrawl search).

### Other bookmakers

Marathon, BetBoom and Pari have REST/aggregator clients in public repositories, and third-party providers such as odds-api.io expose Marathon data, but most are paid or unofficial. Paid APIs are out of scope because the original project constraint is no paid API. They can be revisited as a separate product decision, not as part of this spike.

Sources: `https://github.com/BettingApi/js-rest-client`, `https://odds-api.io/sportsbooks/marathonbet`.

## Risks

- Certificate pinning and anti-instrumentation can break emulator/proxy capture.
- Reverse-engineered endpoints can change or be rate-limited without notice.
- Using a logged-in app session risks account data and may breach bookmaker ToS.
- Live odds are still skipped in the collector (`if raw.is_live: continue`); hidden live endpoints would require a separate live-snapshot and live-model design, not merely faster parsing.

## Decision

Mobile apps are **not a runtime source**. They are useful only as a one-time discovery aid. The runtime path remains the current HTTP adapters with parallel fetch and batched persistence.

## Bounded next experiment

1. Pick one upcoming tennis event present in both Winline and Fonbet adapters.
2. Record one public endpoint response from each candidate API and one current-adapter snapshot for the same event.
3. Compare participant mapping, market codes, odds values and timestamps.
4. If mapping is stable and the endpoint exposes genuine deltas, write a follow-up design. If blocked or unstable, record the finding and stop.

## Verification status

No endpoint was live-called in this report task. The report is based on Firecrawl research already reviewed with the user; the next experiment remains a separate, explicitly authorized step.

## Rerun inputs

workflow: firecrawl-search
queries: Winline reverse engineering API, Fonbet MCP endpoints, bookmaker mobile app traffic reverse engineering, Marathon BetBoom Pari REST API
depth: quick
output: markdown
