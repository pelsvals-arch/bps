from pathlib import Path

import betdash.app.tray as tray


SRC = Path(__file__).resolve().parents[1] / "src" / "betdash"


def test_build_icon_image_does_not_load_pystray(monkeypatch):
    def fail():
        raise AssertionError("pystray must not be loaded to draw the icon")

    monkeypatch.setattr(tray, "_load_pystray", fail)

    image = tray.TrayController()._build_icon_image(running=False)

    assert image.size == (64, 64)


def test_trainer_declares_canonical_event_for_type_checkers():
    text = (SRC / "models" / "trainer.py").read_text(encoding="utf-8")
    assert "if TYPE_CHECKING:" in text
    assert "from betdash.normalize.models import CanonicalEvent" in text


def test_dashboard_has_no_dead_total_cov():
    text = (SRC / "app" / "dashboard.py").read_text(encoding="utf-8")
    assert "total_cov = " not in text


def test_known_unused_source_imports_are_removed():
    checks = {
        "backtest/clv.py": "from typing import Any",
        "normalize/alias_generator.py": "from typing import Iterable",
        "tennis/markets.py": "from typing import Any",
    }
    for relative, import_line in checks.items():
        assert import_line not in (SRC / relative).read_text(encoding="utf-8")


def test_known_unused_test_imports_are_removed():
    import ast

    root = Path(__file__).resolve().parents[1]
    checks = {
        "tests/adapters/test_json_family.py": {"SCOPE_MARKETS"},
        "tests/adapters/test_winline.py": {"pytest"},
        "tests/results/test_resolve.py": {"timezone"},
        "tests/backtest/test_engine.py": {"timedelta"},
        "tests/models/test_baseline.py": {"Settings"},
        "tests/models/test_model_review_fixes.py": {"fit_isotonic"},
        "tests/risk/test_engine.py": {"PredictionRecord"},
        "tests/analytics/test_movement.py": {"datetime", "timezone", "timedelta"},
    }
    for relative, names in checks.items():
        tree = ast.parse((root / relative).read_text(encoding="utf-8"))
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(a.asname or a.name.split(".")[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom):
                imported.update(a.asname or a.name for a in node.names)
        assert not (imported & names), f"{relative}: {sorted(imported & names)}"
