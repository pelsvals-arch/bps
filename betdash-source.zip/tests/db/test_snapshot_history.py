from datetime import datetime, timezone, timedelta
from betdash.db.repository import Repository, Snapshot

def test_snapshot_history_returns_chronological(tmp_path):
    repo = Repository(str(tmp_path / "db.sqlite"))
    t0 = datetime(2026,1,1,tzinfo=timezone.utc)
    for i, odds in enumerate([2.0, 2.1, 1.9]):
        repo.save_snapshots([Snapshot(
            event_uid="e1", bookmaker="bk1", market="match_winner", outcome="p1",
            line=None, odds_decimal=odds, observed_at=t0 + timedelta(minutes=i),
            source_event_id="s1", adapter_version="v1", is_live=False
        )])
    rows = repo.snapshot_history("e1", market="match_winner", outcome="p1", line=None, limit=10)
    assert [r.odds_decimal for r in rows] == [2.0, 2.1, 1.9]
