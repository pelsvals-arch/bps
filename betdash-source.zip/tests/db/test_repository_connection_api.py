import inspect
from pathlib import Path

import betdash.db.repository as repository_module
from betdash.db.repository import Repository


def test_repository_exposes_public_connection_context_manager(tmp_path):
    repo = Repository(str(tmp_path / "repo.sqlite"))

    with repo.connection() as conn:
        value = conn.execute("SELECT 1").fetchone()[0]

    assert value == 1


def test_legacy_connect_still_works_as_context_manager(tmp_path):
    repo = Repository(str(tmp_path / "legacy.sqlite"))

    with repo._connect() as conn:
        value = conn.execute("SELECT 1").fetchone()[0]

    assert value == 1


def test_connection_is_decorated_and_private_calls_are_migrated():
    source = inspect.getsource(Repository.connection)
    assert "@contextmanager" in source

    repository_path = Path(repository_module.__file__).resolve()
    root = repository_path.parent.parent
    offenders = [
        str(path.relative_to(root))
        for path in root.rglob("*.py")
        if path.resolve() != repository_path and "._connect()" in path.read_text(encoding="utf-8")
    ]
    assert offenders == []
