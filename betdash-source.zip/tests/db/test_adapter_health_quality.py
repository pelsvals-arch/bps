from datetime import datetime, timezone
from betdash.db.repository import AdapterHealth, Repository

def test_adapter_health_quality_fields(tmp_path):
    repo = Repository(str(tmp_path / "t.sqlite"))
    h = AdapterHealth(
        bookmaker="fonbet",
        status="ok",
        last_success=datetime.now(timezone.utc),
        error_count=0,
        adapter_version="v1",
        last_error=None,
        rows_last_poll=123,
        payload_hash="abc",
        freshness_sec=1.5,
    )
    repo.upsert_adapter_health(h)
    got = repo.list_adapter_health()[0]
    assert got.rows_last_poll == 123
    assert got.payload_hash == "abc"
    assert got.last_error is None
    assert got.freshness_sec == 1.5
