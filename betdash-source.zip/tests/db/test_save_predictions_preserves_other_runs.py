from datetime import datetime, timezone

from betdash.db.repository import Repository


def _row(run_id: str, event_uid: str, prob: float) -> dict:
    now = datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    return {
        "model_run_id": run_id,
        "event_uid": event_uid,
        "market": "match_winner",
        "outcome": "p1",
        "model_prob": prob,
        "odds_decimal": 2.0,
        "observed_at": now,
        "event_start_at": now,
    }


def test_save_predictions_keeps_rows_from_other_runs(tmp_path):
    repo = Repository(str(tmp_path / "predictions.sqlite"))
    repo.save_predictions([_row("run-old", "e-old", 0.55)])
    repo.save_predictions([_row("run-new", "e-new", 0.65)])

    with repo._connect() as conn:
        runs = [r[0] for r in conn.execute("SELECT DISTINCT model_run_id FROM predictions")]

    assert set(runs) == {"run-old", "run-new"}
