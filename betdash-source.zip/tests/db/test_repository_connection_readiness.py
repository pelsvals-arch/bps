from betdash.db.repository import Repository


def test_connection_runs_schema_checks_once_per_database(tmp_path, monkeypatch):
    repo = Repository(str(tmp_path / "ready.db"))
    calls = {"odds": 0}

    original = Repository._ensure_odds_snapshot_columns

    def counted(self, connection):
        calls["odds"] += 1
        original(connection)

    monkeypatch.setattr(Repository, "_ensure_odds_snapshot_columns", counted)

    with repo.connection():
        pass
    with repo.connection():
        pass

    assert calls["odds"] == 1


def test_connection_marks_ready_even_when_first_use_writes(tmp_path, monkeypatch):
    repo = Repository(str(tmp_path / "writing.db"))
    calls = {"odds": 0}
    original = Repository._ensure_odds_snapshot_columns

    def counted(self, connection):
        calls["odds"] += 1
        original(connection)

    monkeypatch.setattr(Repository, "_ensure_odds_snapshot_columns", counted)

    with repo.connection() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO bankroll(id,amount,updated_at) VALUES (1,100,'x')"
        )
    with repo.connection():
        pass

    assert calls["odds"] == 1
