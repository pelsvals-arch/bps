from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from betdash.db.repository import Repository, init_db
from betdash.db.tennis_migration import archive_and_purge_non_tennis


def _db(path):
    init_db(str(path))
    conn = sqlite3.connect(str(path))
    conn.executescript(
        """
        CREATE TABLE sackmann_matches (
            tour TEXT,
            tourney_id TEXT,
            match_num INTEGER,
            winner_id INTEGER,
            loser_id INTEGER,
            PRIMARY KEY (tour, tourney_id, match_num, winner_id, loser_id)
        );
        """
    )
    conn.executemany(
        """INSERT INTO canonical_events
           (event_uid, sport, league, participant_ids, start_at, mapping_confidence)
           VALUES (?, ?, 'Test', '[]', '2026-01-01T00:00:00Z', 1.0)""",
        [("tennis-1", "tennis"), ("basket-1", "basketball")],
    )
    conn.executemany(
        """INSERT INTO odds_snapshots
           (event_uid, bookmaker, market, outcome, odds_decimal, observed_at, adapter_version)
           VALUES (?, ?, 'match_winner', 'p1', ?, '2026-01-01T00:00:00Z', 'test')""",
        [
            ("tennis-1", "pari", 2.0),
            ("basket-1", "pari", 2.1),
            ("orphan-1", "fonbet", 3.0),
        ],
    )
    conn.executemany(
        """INSERT INTO predictions
           (prediction_id, event_uid, market, outcome, model_prob, odds_decimal, observed_at)
           VALUES (?, ?, 'match_winner', 'p1', 0.5, ?, '2026-01-01T00:00:00Z')""",
        [("p-tennis", "tennis-1", 2.0), ("p-basket", "basket-1", 2.1)],
    )
    conn.executemany(
        """INSERT INTO closing_lines
           (event_uid, market, outcome, odds_closing, captured_at)
           VALUES (?, 'match_winner', 'p1', ?, '2026-01-01T00:00:00Z')""",
        [("tennis-1", 1.9), ("basket-1", 2.0)],
    )
    conn.executemany(
        """INSERT INTO closing_lines_book
           (event_uid, market, outcome, bookmaker, odds_closing, captured_at)
           VALUES (?, 'match_winner', 'p1', 'pari', ?, '2026-01-01T00:00:00Z')""",
        [("tennis-1", 1.9), ("basket-1", 2.0)],
    )
    conn.execute(
        "INSERT INTO sackmann_matches(tour, tourney_id, match_num, winner_id, loser_id) VALUES ('atp', 'x', 1, 1, 2)"
    )
    conn.commit()
    return conn


def _sports(path):
    conn = sqlite3.connect(path)
    try:
        return {row[0] for row in conn.execute("SELECT DISTINCT sport FROM canonical_events")}
    finally:
        conn.close()


def _orphans(path):
    conn = sqlite3.connect(path)
    try:
        return conn.execute(
            "SELECT COUNT(*) FROM odds_snapshots s LEFT JOIN canonical_events e ON e.event_uid = s.event_uid WHERE e.event_uid IS NULL"
        ).fetchone()[0]
    finally:
        conn.close()


def test_archive_and_purge_removes_orphan_snapshots(tmp_path):
    db = tmp_path / "work.sqlite"
    archive = tmp_path / "archive.sqlite"
    conn = _db(db)
    conn.close()

    report = archive_and_purge_non_tennis(Repository(str(db)), archive)

    assert report["canonical_events"]["basketball"] == 1
    assert _sports(db) == {"tennis"}
    assert _orphans(db) == 0
    assert _orphans(archive) == 1
    ac = sqlite3.connect(archive)
    try:
        assert ac.execute("SELECT sport FROM canonical_events").fetchall() == [("basketball",)]
        assert ac.execute("SELECT COUNT(*) FROM odds_snapshots").fetchone()[0] == 2
        assert ac.execute("SELECT COUNT(*) FROM predictions").fetchone()[0] == 1
        assert ac.execute("SELECT COUNT(*) FROM sackmann_matches").fetchone()[0] == 0
    finally:
        ac.close()
    wc = sqlite3.connect(db)
    try:
        assert wc.execute("SELECT COUNT(*) FROM odds_snapshots").fetchone()[0] == 1
        assert wc.execute("SELECT COUNT(*) FROM sackmann_matches").fetchone()[0] == 1
    finally:
        wc.close()


def test_archive_and_purge_handles_null_event_uid(tmp_path):
    db = tmp_path / "work.sqlite"
    archive = tmp_path / "archive.sqlite"
    conn = _db(db)
    conn.execute(
        """INSERT INTO canonical_events
           (event_uid, sport, league, participant_ids, start_at, mapping_confidence)
           VALUES (NULL, 'basketball', 'Test', '[]', '2026-01-01T00:00:00Z', 1.0)"""
    )
    conn.execute(
        """INSERT INTO events
           (event_uid, sport, league, participant_ids, start_at, mapping_confidence)
           VALUES (NULL, 'basketball', 'Test', '[]', '2026-01-01T00:00:00Z', 1.0)"""
    )
    conn.commit()
    conn.close()

    archive_and_purge_non_tennis(Repository(str(db)), archive)

    assert _sports(db) == {"tennis"}
    assert _orphans(db) == 0
    ac = sqlite3.connect(archive)
    try:
        assert ac.execute("SELECT COUNT(*) FROM canonical_events WHERE sport = 'basketball'").fetchone()[0] == 2
        assert ac.execute(
            "SELECT COUNT(*) FROM events WHERE event_uid IS NULL"
        ).fetchone()[0] == 1
    finally:
        ac.close()


def test_main_prepares_wal_and_has_module_entrypoint():
    source = Path(__file__).resolve().parents[2] / "src" / "betdash" / "db" / "tennis_migration.py"
    text = source.read_text(encoding="utf-8")
    assert 'if __name__ == "__main__":' in text
    assert "PRAGMA wal_checkpoint(TRUNCATE)" in text
    assert "PRAGMA busy_timeout" in text


def test_main_validates_checkpoint_before_purge(tmp_path):
    from betdash.db.tennis_migration import main

    db = tmp_path / "db.sqlite"
    conn = _db(db)
    conn.close()
    checkpoint = tmp_path / "trainer_checkpoint.json"
    checkpoint.write_text("not json", encoding="utf-8")

    with pytest.raises(json.JSONDecodeError):
        main([
            "--db", str(db),
            "--archive", str(tmp_path / "archive.sqlite"),
            "--checkpoint", str(checkpoint),
        ])

    assert _sports(db) == {"tennis", "basketball"}


def test_migrate_checkpoint_keeps_only_tennis(tmp_path):
    from betdash.db.tennis_migration import migrate_checkpoint

    payload = {
        "elo": {"tennis": {}, "basketball": {}},
        "glicko": {"tennis": {}, "basketball": {}},
        "runs": 4,
    }
    path = tmp_path / "trainer_checkpoint.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    report = migrate_checkpoint(path)

    assert report == {"elo": 1, "glicko": 1}
    saved = json.loads(path.read_text(encoding="utf-8"))
    assert set(saved["elo"]) == {"tennis"}
    assert set(saved["glicko"]) == {"tennis"}
    assert saved["runs"] == 4


def test_main_runs_with_explicit_paths(tmp_path, capsys):
    from betdash.db.tennis_migration import main

    db = tmp_path / "db.sqlite"
    _db(db)
    checkpoint = tmp_path / "trainer_checkpoint.json"
    checkpoint.write_text(
        json.dumps({"elo": {"tennis": {}, "basketball": {}}, "glicko": {"tennis": {}}}),
        encoding="utf-8",
    )
    archive = tmp_path / "archive.sqlite"

    rc = main([
        "--db", str(db),
        "--archive", str(archive),
        "--checkpoint", str(checkpoint),
    ])
    report = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert report["canonical_events"]["basketball"] == 1
    assert set(json.loads(checkpoint.read_text(encoding="utf-8"))["elo"]) == {"tennis"}
