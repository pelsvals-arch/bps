from datetime import datetime, timezone

from betdash.backtest.clv import backfill_clv
from betdash.db.repository import Repository


LEGACY_PREDICTIONS = """
CREATE TABLE predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    model_run_id TEXT,
    event_uid TEXT NOT NULL,
    market TEXT NOT NULL,
    outcome TEXT NOT NULL,
    line REAL,
    model_prob REAL NOT NULL,
    odds_decimal REAL,
    bookmaker TEXT,
    observed_at TEXT NOT NULL,
    decision_observed_at TEXT,
    event_start_at TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    closing_odds REAL,
    clv REAL,
    actual_outcome INTEGER,
    settled_at TEXT
)
"""


def test_legacy_predictions_get_ids_and_can_receive_clv(tmp_path):
    repo = Repository(str(tmp_path / "legacy.sqlite"))
    with repo._connect() as conn:
        conn.execute("DROP TABLE predictions")
        conn.execute(LEGACY_PREDICTIONS)
        conn.execute(
            """
            INSERT INTO predictions(
                model_run_id, event_uid, market, outcome, model_prob,
                odds_decimal, observed_at, event_start_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "run-1",
                "event-1",
                "match_winner",
                "p1",
                0.55,
                2.10,
                datetime(2026, 1, 1, 9, tzinfo=timezone.utc).isoformat(),
                datetime(2026, 1, 1, 10, tzinfo=timezone.utc).isoformat(),
            ),
        )
        conn.commit()

    # Repository._connect() runs schema migrations and must backfill the id.
    with repo._connect() as conn:
        row = conn.execute("SELECT prediction_id FROM predictions").fetchone()
        conn.execute(
            """
            INSERT INTO closing_lines(event_uid, market, line, outcome, odds_closing, bookmaker, captured_at)
            VALUES ('event-1', 'match_winner', NULL, 'p1', 2.00, 'b1', '2026-01-01T09:55:00+00:00')
            """
        )
        conn.commit()

    assert row["prediction_id"]
    assert backfill_clv(repo) == 1
    with repo._connect() as conn:
        filled = conn.execute("SELECT closing_odds, clv FROM predictions").fetchone()
    assert float(filled["closing_odds"]) == 2.0
    assert float(filled["clv"]) > 0
