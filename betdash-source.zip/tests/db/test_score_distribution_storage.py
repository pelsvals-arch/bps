import sqlite3

from betdash.db.repository import Repository


def test_score_distribution_storage_round_trip(tmp_path):
    repo = Repository(str(tmp_path / "test.db"))
    row = {
        "event_uid": "e1",
        "model_run_id": "run-1",
        "provider": "empirical",
        "observed_at": "2026-11-28T10:00:00Z",
        "distribution": {"6-4 6-4": 0.7, "6-4 5-7 6-4": 0.3},
        "p1_prob": 0.62,
    }

    repo.save_score_distribution(row)

    rows = repo.score_distributions(event_uid="e1", model_run_id="run-1")
    assert len(rows) == 1
    assert rows[0]["provider"] == "empirical"
    assert rows[0]["distribution"] == row["distribution"]
    assert rows[0]["p1_prob"] == 0.62


def test_score_distribution_round_trip_preserves_score_atom_keys(tmp_path):
    repo = Repository(str(tmp_path / "atoms.db"))
    row = {
        "event_uid": "e2",
        "model_run_id": "run-2",
        "provider": "markov",
        "observed_at": "2026-11-28T10:00:00Z",
        "distribution": {((6, 4), (6, 3)): 0.6, ((4, 6), (3, 6)): 0.4},
        "p1_prob": 0.6,
    }

    repo.save_score_distribution(row)
    loaded = repo.score_distributions(event_uid="e2")

    assert loaded[0]["distribution"] == row["distribution"]


def test_score_distributions_table_is_part_of_schema(tmp_path):
    db = tmp_path / "schema.db"
    Repository(str(db))

    with sqlite3.connect(db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(score_distributions)")}

    assert {
        "event_uid",
        "model_run_id",
        "provider",
        "observed_at",
        "distribution_json",
        "p1_prob",
    } <= columns
