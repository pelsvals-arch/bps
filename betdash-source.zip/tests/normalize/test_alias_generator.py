import json

from betdash.data.sackmann import ensure_sackmann_tables
from betdash.db.repository import Repository
from betdash.normalize.alias_generator import (
    generate_sackmann_aliases,
    main,
    sackmann_alias_variants,
    write_sackmann_aliases,
)


def test_sackmann_alias_variants_cover_bookmaker_orders():
    assert sackmann_alias_variants("Taylor Fritz") == {
        "Taylor Fritz",
        "T Fritz",
        "T. Fritz",
        "Fritz Taylor",
        "Fritz T",
        "Fritz T.",
        "Fritz",
        "FritzT",
        "FritzT.",
    }


def test_generate_and_write_aliases_preserve_manual_overrides(tmp_path):
    db = tmp_path / "aliases.db"
    repo = Repository(str(db))
    with repo._connect() as conn:
        ensure_sackmann_tables(conn)
        conn.execute(
            "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
            "VALUES ('atp','t','20260101','Taylor Fritz','Andrey Rublev')"
        )
    path = tmp_path / "aliases.json"
    path.write_text(json.dumps({"Taylor Fritz": ["Тэйлор Фриц"]}), encoding="utf-8")

    generated = generate_sackmann_aliases(repo)
    assert "Fritz T." in generated["Taylor Fritz"]
    assert "Rublev A." in generated["Andrey Rublev"]

    written = write_sackmann_aliases(repo, path)
    stored = json.loads(written.read_text(encoding="utf-8"))
    assert "Тэйлор Фриц" in stored["Taylor Fritz"]
    assert stored["Andrey Rublev"] == sorted(stored["Andrey Rublev"])


def test_write_sackmann_aliases_invalidates_runtime_caches(tmp_path, monkeypatch):
    from betdash.analytics import prediction_links
    from betdash.models import features

    repo = Repository(str(tmp_path / "cache.db"))
    with repo._connect() as conn:
        ensure_sackmann_tables(conn)
        conn.execute(
            "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
            "VALUES ('atp','t','20260101','Taylor Fritz','Andrey Rublev')"
        )
    monkeypatch.setattr(features, "_SACKMANN_PLAYER_ALIAS_MAP", {"stale": "x"})
    monkeypatch.setattr(prediction_links, "_ALIAS_REVERSE", {"stale": "x"})

    write_sackmann_aliases(repo, tmp_path / "aliases.json")

    assert features._SACKMANN_PLAYER_ALIAS_MAP is None
    assert prediction_links._ALIAS_REVERSE is None


def test_generate_sackmann_aliases_can_limit_to_frequent_players(tmp_path):
    db = tmp_path / "limit.db"
    repo = Repository(str(db))
    with repo.connection() as conn:
        ensure_sackmann_tables(conn)
        for i in range(3):
            conn.execute(
                "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
                "VALUES ('atp',?,?,?,?)",
                (f"t{i}", "20260101", "Frequent Player", "Rare Player"),
            )
        conn.execute(
            "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
            "VALUES ('atp','other','20260101','Second Player','Rare Player')"
        )

    generated = generate_sackmann_aliases(repo, limit=2)

    assert set(generated) == {"Frequent Player", "Rare Player"}


def test_write_sackmann_aliases_drops_stale_canonicals(tmp_path):
    db = tmp_path / "stale.db"
    repo = Repository(str(db))
    with repo.connection() as conn:
        ensure_sackmann_tables(conn)
        conn.execute(
            "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
            "VALUES ('atp','t','20260101','Taylor Fritz','Andrey Rublev')"
        )
    target = tmp_path / "aliases.json"
    target.write_text(
        json.dumps({"Taylor Fritz": ["Тэйлор Фриц"], "Old Player": ["Старый Игрок"]}),
        encoding="utf-8",
    )

    write_sackmann_aliases(repo, target, limit=2)
    stored = json.loads(target.read_text(encoding="utf-8"))

    assert "Old Player" not in stored
    assert "Taylor Fritz" in stored
    assert "Тэйлор Фриц" in stored["Taylor Fritz"]


def test_alias_generator_cli_writes_requested_path(tmp_path):
    db = tmp_path / "cli.db"
    repo = Repository(str(db))
    with repo.connection() as conn:
        ensure_sackmann_tables(conn)
        conn.execute(
            "INSERT INTO sackmann_matches (tour, tourney_id, tourney_date, winner_name, loser_name) "
            "VALUES ('atp','t','20260101','Taylor Fritz','Andrey Rublev')"
        )
    target = tmp_path / "generated.json"

    assert main(["--db", str(db), "--output", str(target)]) == 0
    stored = json.loads(target.read_text(encoding="utf-8"))
    assert "Fritz T." in stored["Taylor Fritz"]
