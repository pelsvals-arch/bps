from betdash.adapters.marathon import _JSON_MARKET_MODELS
from betdash.models.trainer import TENNIS_MARKETS
from betdash.normalize.registry import canon_market
from betdash.tennis.markets import canonical_tennis_market


def test_game_handicap_is_canonical_tennis_market():
    assert canon_market("game_handicap", "test") == "game_handicap"
    assert canon_market("spread", "test") == "game_handicap"
    assert canonical_tennis_market("game_handicap") == "game_handicap"
    assert "game_handicap" in TENNIS_MARKETS


def test_marathon_handicap_codes_emit_canonical_market():
    assert _JSON_MARKET_MODELS["MTCH_HB"] == "game_handicap"
    assert _JSON_MARKET_MODELS["MTCH_HBP"] == "game_handicap"
