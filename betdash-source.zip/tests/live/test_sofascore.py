from __future__ import annotations

import io
import json

import pytest

from betdash.live.sofascore import _clear_live_cache, fetch_live_events, fetch_live_events_cached


@pytest.fixture(autouse=True)
def clear_live_cache():
    _clear_live_cache()
    yield
    _clear_live_cache()


class _Response(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def _opener(payload):
    def open_url(url, timeout=None):
        assert "api.sofascore.com" in url
        assert timeout == 5
        return _Response(json.dumps(payload).encode())
    return open_url


def _event(event_id, home, away, home_translation=None):
    team = {"name": home}
    if home_translation:
        team["fieldTranslations"] = {"nameTranslation": {"ru": home_translation}}
    return {
        "id": event_id,
        "startTimestamp": 1764253200,
        "homeTeam": team,
        "awayTeam": {"name": away},
        "homeScore": {"current": 1},
        "awayScore": {"current": 2},
        "status": {"description": "1st set"},
        "tournament": {"name": "ATP Cup"},
        "category": {"slug": "tennis"},
    }


def test_fetch_live_events_parses_all_supported_sports():
    payload = {"events": [_event(1, "Djokovic", "Alcaraz", "Джокович"), _event(2, "Team A", "Team B")]}

    assert fetch_live_events("tennis", opener=_opener(payload)) == [
        {
            "event_id": 1,
            "start_at": "2025-11-27T14:20:00+00:00",
            "home": "Джокович",
            "away": "Alcaraz",
            "home_score": 1,
            "away_score": 2,
            "status": "1st set",
            "tournament": "ATP Cup",
            "url": "https://www.sofascore.com/event/1",
        },
        {
            "event_id": 2,
            "start_at": "2025-11-27T14:20:00+00:00",
            "home": "Team A",
            "away": "Team B",
            "home_score": 1,
            "away_score": 2,
            "status": "1st set",
            "tournament": "ATP Cup",
            "url": "https://www.sofascore.com/event/2",
        },
    ]


def test_live_events_returns_empty_on_http_error():
    def broken(url, timeout=None):
        raise OSError("offline")

    assert fetch_live_events("tennis", opener=broken) == []


def test_live_events_tolerates_malformed_payload():
    def bad_json(url, timeout=None):
        return _Response(b"{not json")

    assert fetch_live_events("tennis", opener=bad_json) == []


def test_fetch_live_events_rejects_unknown_sport():
    assert fetch_live_events("hockey", opener=_opener({"events": []})) == []


def test_cached_live_events_reuses_fresh_response():
    calls = []

    def opener(url, timeout=None):
        calls.append(url)
        return _opener({"events": [_event(1, "Djokovic", "Alcaraz")]})(url, timeout)

    first = fetch_live_events_cached("tennis", opener=opener, now=lambda: 100)
    second = fetch_live_events_cached("tennis", opener=opener, now=lambda: 110)

    assert first == second
    assert len(calls) == 1


def test_cached_live_events_refetches_after_ttl():
    calls = []

    def opener(url, timeout=None):
        calls.append(url)
        return _opener({"events": [_event(1, "Djokovic", "Alcaraz")]})(url, timeout)

    fetch_live_events_cached("tennis", opener=opener, ttl_seconds=30, now=lambda: 100)
    fetch_live_events_cached("tennis", opener=opener, ttl_seconds=30, now=lambda: 200)

    assert len(calls) == 2


def test_cached_live_events_returns_last_good_rows_on_error():
    def broken(url, timeout=None):
        raise OSError("offline")

    good = fetch_live_events_cached("tennis", opener=_opener({"events": [_event(7, "Rublev", "Zverev")]}), now=lambda: 100)
    fallback = fetch_live_events_cached("tennis", opener=broken, now=lambda: 200)

    assert [row["event_id"] for row in fallback] == [row["event_id"] for row in good]
    assert all(row["_stale"] for row in fallback)


def test_cached_live_events_marks_fresh_rows_not_stale():
    rows = fetch_live_events_cached(
        "tennis", opener=_opener({"events": [_event(8, "Sinner", "Fritz")]}), now=lambda: 100
    )
    assert all(row["_stale"] is False for row in rows)


def test_cached_live_events_stops_stale_fallback_after_max_age():
    def broken(url, timeout=None):
        raise OSError("offline")

    fetch_live_events_cached(
        "tennis", opener=_opener({"events": [_event(9, "Rublev", "Zverev")]}), now=lambda: 100
    )
    fallback = fetch_live_events_cached(
        "tennis",
        opener=broken,
        ttl_seconds=30,
        max_fallback_age_seconds=60,
        now=lambda: 500,
    )
    assert fallback == []


def test_cached_live_events_returns_copies():
    from betdash.live import sofascore

    fetch_live_events_cached(
        "tennis", opener=_opener({"events": [_event(10, "Sinner", "Fritz")]}), now=lambda: 100
    )
    first = fetch_live_events_cached("tennis", opener=broken_opener, now=lambda: 105)
    first[0]["home"] = "mutated"
    second = fetch_live_events_cached("tennis", opener=broken_opener, now=lambda: 106)
    assert second[0]["home"] == "Sinner"
    assert sofascore._LIVE_CACHE["tennis"][1][0]["home"] == "Sinner"


def broken_opener(url, timeout=None):
    raise OSError("offline")


def test_cached_live_events_uses_monotonic_clock_by_default():
    from pathlib import Path

    import betdash.live.sofascore as sofascore

    source = Path(sofascore.__file__).read_text(encoding="utf-8")
    assert "time.monotonic()" in source
