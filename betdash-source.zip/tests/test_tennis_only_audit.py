from pathlib import Path


BANNED = (
    "basketball", "dota2", "cs2", "NBA", "football", "hockey",
    "map_winner", "total_maps", "map_handicap",
)
ALLOW = {"tests/db/test_tennis_migration.py"}


def test_src_has_no_non_tennis_tokens():
    offenders: list[str] = []
    for path in Path("src/betdash").rglob("*.py"):
        text = path.read_text(encoding="utf-8").lower()
        for token in BANNED:
            if token.lower() in text:
                offenders.append(f"{path}:{token}")
    assert not offenders, "non-tennis tokens in src: " + ", ".join(offenders)
