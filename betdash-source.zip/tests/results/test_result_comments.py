from betdash.db.repository import Repository
from betdash.results.ingest import parse_tennis_results


CSV = """Date,Winner,Loser,Score,Tournament,Comment
01/05/2026,Player One,Player Two,6-4 3-2 RET,ATP,Retired
"""


def test_result_comment_is_preserved(tmp_path):
    path = tmp_path / "results.csv"
    path.write_text(CSV, encoding="utf-8")

    rows = parse_tennis_results(path)

    assert rows[0].comment == "Retired"

    repo = Repository(str(tmp_path / "db.sqlite"))
    assert repo.save_result("event-1", rows[0])
    stored = repo.results("event-1")[0]

    assert stored["comment"] == "Retired"
