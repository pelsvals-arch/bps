from pathlib import Path

from betdash.config import Settings
from betdash.db.repository import Repository
from betdash.models.trainer import Trainer


def _oof_row(event_uid, day, actual, strength):
    return {
        "event_uid": event_uid,
        "event_start_at": f"2026-01-{day:02d}T00:00:00Z",
        "actual": actual,
        "features": {"elo_p1": strength},
        "market_p1": strength,
    }


def test_oof_rows_are_time_sorted_and_actual_filtered(tmp_path):
    trainer = Trainer(Repository(str(tmp_path / "oof.db")), Settings())
    late = [
        _oof_row("late0", 4, 1, 0.8),
        _oof_row("late1", 5, 0, 0.3),
    ]
    early = [
        _oof_row("early0", 1, 1, 0.7),
        _oof_row("early1", 2, 0, 0.4),
    ]
    shuffled = late + early + [_oof_row("bad", 3, None, 0.5)]

    got = trainer._walk_forward_oof_rows(shuffled, window=1)
    expected = trainer._walk_forward_oof_rows(early + late, window=1)

    assert [(p, a, r["event_uid"]) for p, a, r in got] == [
        (p, a, r["event_uid"]) for p, a, r in expected
    ]


def test_step_computes_oof_rows_once_and_passes_to_metrics(tmp_path):
    source = (Path(Trainer.__module__.replace(".", "/"))).with_suffix(".py")
    text = source.read_text() if source.exists() else ""
    if not text:
        text = Path("src/betdash/models/trainer.py").read_text()

    assert "oof_rows = self._walk_forward_oof_rows(processed_rows)" in text
    assert "oof_rows=oof_rows" in text
    assert text.count("self._walk_forward_oof_rows(rows)") == 1


def test_walk_forward_summary_comes_from_oof_rows(tmp_path):
    trainer = Trainer(Repository(str(tmp_path / "summary.db")), Settings())
    oof_rows = [(0.8, 1, {"event_uid": "e1"}), (0.3, 0, {"event_uid": "e2"})]

    summary = trainer._walk_forward_summary_from_oof_rows(oof_rows, window=1)

    assert summary["predictions"] == 2
    assert summary["correct"] == 2
    assert summary["accuracy"] == 1.0
    assert [fold["fold"] for fold in summary["folds"]] == [1, 2]


def test_step_does_not_run_a_second_walk_forward():
    text = Path("src/betdash/models/trainer.py").read_text()

    assert "wf = self._walk_forward_summary_from_oof_rows(oof_rows)" in text
    assert "wf = self._walk_forward(processed_rows)" not in text


def test_blend_repository_lookup_is_indexed_by_event_uid():
    text = Path("src/betdash/tennis/blend.py").read_text()

    assert "by_event.setdefault(uid, [])" in text
    assert "for run_id, distributions in by_event.get(uid, ())" in text
    assert "for (event_uid, run_id), distributions in grouped.items()" not in text
