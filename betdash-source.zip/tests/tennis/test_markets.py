from betdash.tennis.markets import market_probabilities, resolve_tennis_market
from betdash.tennis.score import parse_tennis_score


def test_market_probabilities_match_winner_and_game_handicap():
    dist = {((6, 4), (6, 3)): 0.4, ((4, 6), (5, 7)): 0.6}

    wp = market_probabilities(dist, "match_winner")
    assert wp["p1"] == 0.4
    assert wp["p2"] == 0.6

    gc = market_probabilities(dist, "game_handicap", line=2.0)
    assert gc["push"] == 0.0
    assert gc["p1"] == 0.4
    assert gc["p2"] == 0.6


def test_set_markets_use_requested_set():
    dist = {((6, 4), (6, 3)): 0.4, ((4, 6), (5, 7)): 0.6}

    total = market_probabilities(dist, "set_total", line=10.5, set_index=2)
    assert total["over"] == 0.6
    assert total["under"] == 0.4

    handicap = market_probabilities(dist, "set_game_handicap", line=1.5, set_index=2)
    assert handicap["p1"] == 0.4
    assert handicap["p2"] == 0.6


def test_combined_market_uses_joint_probability():
    dist = {((6, 4), (6, 3)): 0.4, ((7, 6), (6, 4)): 0.3, ((4, 6), (3, 6)): 0.3}

    comb = market_probabilities(dist, "winner_plus_total", line=22.5)
    assert comb["p1_over"] == 0.3
    assert comb["p1_under"] == 0.4
    assert comb["p2_over"] + comb["p2_under"] == 0.3


def test_bookmaker_market_aliases_resolve_to_tennis_markets():
    dist = {((6, 4), (6, 3)): 0.4, ((4, 6), (5, 7)): 0.6}

    total = market_probabilities(dist, "total_points", line=19.5)
    assert total == market_probabilities(dist, "total_games", line=19.5)

    spread = market_probabilities(dist, "spread", line=1.5)
    assert spread == market_probabilities(dist, "game_handicap", line=1.5)


def test_exact_integer_totals_create_push():
    dist = {((6, 4), (6, 3)): 0.4, ((4, 6), (5, 7)): 0.6}

    totals = market_probabilities(dist, "total_games", line=19.0)
    assert totals["push"] == 0.4
    assert totals["over"] == 0.6


def test_resolve_market_returns_push_for_void_totals():
    score = parse_tennis_score("6-4 3-2 RET", "retired")

    assert resolve_tennis_market("total_games", 10.5, "over", score, "p1") == 0.5
