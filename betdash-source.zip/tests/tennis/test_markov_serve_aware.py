from betdash.tennis.markov import markov_score_distribution


def _p1_winner_prob(distribution):
    return sum(
        probability
        for atom, probability in distribution.items()
        if sum(left > right for left, right in atom) > sum(left < right for left, right in atom)
    )


def test_asymmetric_hold_rates_change_winner_probability():
    strong = markov_score_distribution(0.78, 0.52, simulations=3000, seed=11)
    weak = markov_score_distribution(0.52, 0.78, simulations=3000, seed=11)

    assert _p1_winner_prob(strong) > 0.85
    assert _p1_winner_prob(weak) < 0.15


def test_tiebreak_flag_changes_score_distribution():
    with_tiebreak = markov_score_distribution(0.56, 0.54, simulations=3000, seed=5, tiebreak=True)
    without_tiebreak = markov_score_distribution(0.56, 0.54, simulations=3000, seed=5, tiebreak=False)

    assert with_tiebreak != without_tiebreak
