import pytest

from betdash.tennis.distribution import empirical_score_distribution
from betdash.tennis.markets import market_probabilities, resolve_tennis_market
from betdash.tennis.score import parse_tennis_score
from betdash.tennis.evaluation import evaluation_report


def test_p2_settlement_preserves_void_totals():
    score = parse_tennis_score("6-4 6-3 RET", "retired")

    assert resolve_tennis_market("total_games", 18.5, "over", score, "p1") == 0.5
    assert resolve_tennis_market("total_games", 18.5, "over", score, "p2") == 0.5


def test_match_winner_tied_score_is_push():
    outcomes = market_probabilities({((1, 1),): 1.0}, "match_winner")

    assert outcomes["push"] == 1.0


def test_tied_seven_seven_is_not_a_finished_set():
    score = parse_tennis_score("7-7")

    assert score is not None
    assert not score.completed
    assert score.winner_side is None


def test_two_number_tiebreak_is_stripped():
    score = parse_tennis_score("7-6(4-2) 6-4")

    assert score is not None
    assert score.sets == ((7, 6), (6, 4))
    assert score.totals_reliable


def test_match_tiebreak_detects_ten_seven():
    score = parse_tennis_score("6-7(5) 7-6(3) 10-7")

    assert score is not None
    assert score.match_tiebreak
    assert not score.totals_reliable


def test_distribution_falls_back_to_smoothed_prior():
    dist = empirical_score_distribution([], {"best_of": 3}, prior_strength=5.0)

    assert dist
    assert sum(dist.values()) == pytest.approx(1.0)


def test_distribution_skips_unreliable_history():
    context = {"surface": "clay", "best_of": 3, "elo_gap": 80, "tourney_level": "A", "round": "R32"}
    history = [
        {**context, "score_p1_first": "6-4 3-2 RET", "comment": "retired"},
        {**context, "score_p1_first": "6-4 6-3"},
    ]

    dist = empirical_score_distribution(history, context, prior_strength=0.0)

    assert ((6, 4), (3, 2)) not in dist
    assert dist[((6, 4), (6, 3))] == pytest.approx(1.0)


def test_distribution_excludes_future_rows():
    context = {"surface": "clay", "best_of": 3, "elo_gap": 80, "tourney_level": "A", "round": "R32"}
    history = [
        {**context, "score_p1_first": "6-4 6-3", "observed_at": "2026-01-01T12:00:00+00:00"},
        {**context, "score_p1_first": "3-6 6-3 6-2", "observed_at": "2026-01-03T12:00:00+00:00"},
    ]
    target = {**context, "observed_at": "2026-01-02T12:00:00+00:00"}

    dist = empirical_score_distribution(history, target, prior_strength=0.0)

    assert dist[((6, 4), (6, 3))] == pytest.approx(1.0)


def test_comment_substrings_do_not_force_void_flags():
    clean = parse_tennis_score("6-4 6-3", "two clean sets")
    returned = parse_tennis_score("6-4 6-3", "return of player")

    assert clean is not None and not clean.walkover and clean.totals_reliable
    assert returned is not None and not returned.retirement and returned.totals_reliable


def test_set_totals_survive_match_tiebreak():
    dist = {((6, 4), (6, 3), (10, 7)): 1.0}

    sets = market_probabilities(dist, "total_sets", line=2.5)
    first_set = market_probabilities(dist, "set_total", line=9.5, set_index=1)

    assert sets["over"] == 1.0
    assert first_set["over"] == 1.0


def test_value_ev_requires_real_odds_and_model_probability():
    base = {
        "distribution": {((6, 4), (6, 3)): 0.7, ((4, 6), (3, 6)): 0.3},
        "actual_score": "6-4 6-3",
        "actual": 1,
        "market_probability": 0.6,
        "market_odds": 2.0,
    }

    assert evaluation_report([base])["value_ev"] > 0
    assert evaluation_report([{**base, "market_odds": 1.0}])["value_samples"] == 0
    assert evaluation_report([{**base, "distribution": {((6, 4), (6, 3)): 1.0}}])["value_ev"] is None
