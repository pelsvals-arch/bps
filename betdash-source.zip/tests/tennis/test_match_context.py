from datetime import datetime, timezone

from betdash.data.sackmann import ingest_sackmann_matches
from betdash.db.repository import Repository
from betdash.models.features import build_features
from betdash.normalize.models import CanonicalEvent

HEADER = (
    "tourney_id,tourney_name,surface,draw_size,tourney_level,tourney_date,match_num,"
    "winner_id,winner_name,loser_id,loser_name,score,best_of,round,minutes,"
    "w_ace,w_df,w_svpt,w_1stIn,w_1stWon,w_2ndWon,w_SvGms,w_bpSaved,w_bpFaced,"
    "l_ace,l_df,l_svpt,l_1stIn,l_1stWon,l_2ndWon,l_SvGms,l_bpSaved,l_bpFaced"
)
ROW = (
    "2023-001,Old Open,Clay,32,A,20230101,1,100,Novak Djokovic,200,Carlos Alcaraz,"
    "6-4 6-4,3,R32,90,10,2,60,40,30,10,10,2,3,2,3,55,35,20,8,9,1,4"
)


def test_build_features_exposes_real_surface_and_best_of(tmp_path):
    db = tmp_path / "context.db"
    repo = Repository(str(db))
    csv_path = tmp_path / "atp_matches_2023.csv"
    csv_path.write_text(f"{HEADER}\n{ROW}\n", encoding="utf-8")
    ingest_sackmann_matches(repo, [csv_path], tour="atp")
    event = CanonicalEvent(
        event_uid="e1",
        sport="tennis",
        league="Test",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2023, 12, 1, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )

    features = build_features(event, repo)

    assert features["surface_name"] == "clay"
    assert isinstance(features["surface"], float)
    assert features["best_of"] == 3
