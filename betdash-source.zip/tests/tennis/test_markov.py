from betdash.tennis.markov import (
    markov_score_distribution,
    point_probability_from_serve,
)


def test_point_probability_blends_serve_and_return():
    stats = {"svc_pts": 100, "svc_won": 80, "ret_pts": 100, "ret_won": 30}

    assert point_probability_from_serve(stats) == 0.55


def test_markov_bo3_distribution_is_valid_and_deterministic():
    first = markov_score_distribution(0.55, 0.45, best_of=3, simulations=500, seed=11)
    second = markov_score_distribution(0.55, 0.45, best_of=3, simulations=500, seed=11)

    assert first == second
    assert abs(sum(first.values()) - 1.0) < 1e-9
    assert all(len(atom) in (2, 3) for atom in first)
    assert all(0 <= a <= 7 and 0 <= b <= 7 for atom in first for a, b in atom)


def test_markov_bo5_distribution_can_have_three_to_five_sets():
    dist = markov_score_distribution(0.52, 0.48, best_of=5, simulations=500, seed=12)

    assert abs(sum(dist.values()) - 1.0) < 1e-9
    assert any(len(atom) >= 3 for atom in dist)


def test_strong_player_dominates_markov_distribution():
    dist = markov_score_distribution(0.85, 0.15, best_of=3, simulations=1000, seed=13)

    p1_mass = sum(
        probability
        for atom, probability in dist.items()
        if sum(1 for a, b in atom if a > b) > sum(1 for a, b in atom if b > a)
    )
    assert p1_mass > 0.95
