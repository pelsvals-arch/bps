from betdash.tennis.evaluation import evaluation_report


def test_evaluation_sorts_by_instant_not_string():
    rows = [
        {
            "distribution": {((6, 4), (6, 3)): 0.9},
            "actual_score": "6-4 6-3",
            "actual": 1,
            "observed_at": "2026-01-10T12:00:00+03:00",
        },
        {
            "distribution": {((6, 4), (6, 3)): 0.1},
            "actual_score": "6-4 6-3",
            "actual": 0,
            "observed_at": "2026-01-10T10:00:00+00:00",
        },
    ]

    report = evaluation_report(rows)

    assert report["first_observed_at"] == "2026-01-10T12:00:00+03:00"
    assert report["last_observed_at"] == "2026-01-10T10:00:00+00:00"
