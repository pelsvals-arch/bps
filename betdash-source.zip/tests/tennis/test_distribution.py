import pytest

from betdash.tennis.distribution import (
    condition_distribution_on_win_prob,
    empirical_score_distribution,
)
from betdash.tennis.markets import market_probabilities


def test_empirical_distribution_uses_similar_matches_and_sums_to_one():
    history = [
        {"score_p1_first": "6-4 6-3", "surface": "clay", "best_of": 3, "elo_gap": 80, "tourney_level": "A", "round": "R32"},
        {"score_p1_first": "3-6 6-7", "surface": "clay", "best_of": 3, "elo_gap": -70, "tourney_level": "A", "round": "R32"},
        {"score_p1_first": "6-2 6-2", "surface": "grass", "best_of": 3, "elo_gap": 90, "tourney_level": "A", "round": "R32"},
    ]
    target = {"surface": "clay", "best_of": 3, "elo_gap": 75, "tourney_level": "A", "round": "R32"}

    dist = empirical_score_distribution(history, target, prior_strength=0.0)

    assert sum(dist.values()) == pytest.approx(1.0)
    assert dist[((6, 4), (6, 3))] == pytest.approx(0.5)


def test_condition_distribution_shifts_match_winner_without_losing_mass():
    dist = {((6, 4), (6, 3)): 0.5, ((3, 6), (6, 7)): 0.5}

    shifted = condition_distribution_on_win_prob(dist, 0.8)

    assert sum(shifted.values()) == pytest.approx(1.0)
    assert market_probabilities(shifted, "match_winner")["p1"] == pytest.approx(0.8)
