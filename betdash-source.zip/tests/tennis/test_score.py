from betdash.tennis.score import parse_tennis_score


def test_parse_tennis_score_handles_tiebreak_and_set_counts():
    s = parse_tennis_score("7-6(4) 6-4")
    assert s is not None
    assert s.sets == ((7, 6), (6, 4))
    assert (s.sets_left, s.sets_right) == (2, 0)
    assert (s.games_left, s.games_right) == (13, 10)
    assert s.completed and s.totals_reliable


def test_parse_tennis_score_marks_retirement_and_void_totals():
    s = parse_tennis_score("6-4 3-2 RET", "retired")
    assert s is not None
    assert s.winner_side == "left"
    assert s.retirement and not s.totals_reliable


def test_parse_tennis_score_marks_walkover_and_match_tiebreak():
    assert parse_tennis_score("w/o", "walkover").walkover
    s = parse_tennis_score("6-7(5) 7-6(3) 10-8")
    assert s is not None and s.match_tiebreak and not s.totals_reliable
