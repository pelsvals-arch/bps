import sqlite3

from betdash.data.sackmann import ensure_sackmann_tables
from betdash.db.repository import Repository
from betdash.tennis.empirical_provider import (
    empirical_provider_distribution,
    sackmann_history_rows,
)

P1 = "name:Novak Djokovic"
P2 = "name:Carlos Alcaraz"
TARGET = {
    "surface": "Hard",
    "best_of": 3,
    "tourney_level": "A",
    "round": "R32",
    "elo_gap": 50.0,
    "observed_at": "2023-12-01",
}


def _seed(db_path):
    with sqlite3.connect(db_path) as conn:
        ensure_sackmann_tables(conn)
        rows = [
            ("2023-001", "20230101", "Novak Djokovic", "Carlos Alcaraz", "6-4 6-3", 5, 20),
            ("2023-002", "20230201", "Carlos Alcaraz", "Novak Djokovic", "6-2 6-1", 5, 20),
            ("2024-001", "20240101", "Novak Djokovic", "Carlos Alcaraz", "6-0 6-0", 5, 20),
        ]
        for tid, date, winner, loser, score, wrank, lrank in rows:
            conn.execute(
                """
                INSERT INTO sackmann_matches (
                    tour, tourney_id, surface, tourney_level, round, tourney_date,
                    winner_name, loser_name, score, best_of, winner_rank, loser_rank
                ) VALUES ('atp', ?, 'Hard', 'A', 'R32', ?, ?, ?, ?, 3, ?, ?)
                """,
                (tid, date, winner, loser, score, wrank, lrank),
            )


def test_history_rows_are_oriented_to_p1_and_strictly_pre_event(tmp_path):
    db = tmp_path / "history.db"
    _seed(db)
    repo = Repository(str(db))

    rows = sackmann_history_rows(repo, P1, P2, TARGET)

    assert len(rows) == 2
    assert rows[0]["score_p1_first"] == "6-4 6-3"
    assert rows[1]["score_p1_first"] == "2-6 1-6"
    assert rows[0]["elo_gap"] > 0
    assert rows[1]["elo_gap"] < 0


def test_provider_builds_distribution_from_oriented_history(tmp_path):
    db = tmp_path / "provider.db"
    _seed(db)
    repo = Repository(str(db))

    dist = empirical_provider_distribution(repo, P1, P2, TARGET)

    assert ((6, 4), (6, 3)) in dist
    assert ((2, 6), (1, 6)) in dist
    assert abs(sum(dist.values()) - 1.0) < 1e-9
