from pathlib import Path

from betdash.tennis.score import tennis_winner_side

ROOT = Path(__file__).resolve().parents[2] / "src" / "betdash"
CALL_SITES = (
    "backtest/engine.py",
    "analytics/prediction_outcomes.py",
    "models/trainer.py",
    "models/features.py",
)


def test_tennis_paths_do_not_call_legacy_winner_side():
    for relative in CALL_SITES:
        source = (ROOT / relative).read_text(encoding="utf-8")
        assert "BacktestEngine.winner_side_from_score(" not in source
        assert "parse_tennis_score" in source or "tennis_winner_side" in source


def test_retirement_scoreline_keeps_parser_winner_side():
    assert tennis_winner_side("6-4 3-2 RET") == "left"
