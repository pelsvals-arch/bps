import betdash.tennis as tennis
from betdash.tennis.evaluation import evaluation_report


def test_evaluation_report_separates_accuracy_and_value():
    pair = {
        "distribution": {((6, 4), (6, 3)): 0.7, ((4, 6), (3, 6)): 0.3},
        "actual_score": "6-4 6-3",
        "market_probability": 0.6,
        "market_odds": 2.0,
        "observed_at": "2026-01-01T12:00:00+00:00",
        "actual": 1,
    }

    report = evaluation_report([pair])

    assert report["oof_samples"] == 1
    assert 0.0 <= report["result_brier"] <= 1.0
    assert 0.0 <= report["score_log_loss"] <= 1.0
    assert report["value_ev"] > 0.0


def test_evaluation_report_does_not_claim_value_without_market_probability():
    pair = {"distribution": {((6, 4), (6, 3)): 1.0}, "actual_score": "6-4 6-3", "actual": 1}

    report = evaluation_report([pair])

    assert report["value_samples"] == 0
    assert report["value_ev"] is None


def test_evaluation_report_uses_chronological_pairs_only():
    rows = [
        {"distribution": {((6, 4), (6, 3)): 0.6, ((4, 6), (3, 6)): 0.4}, "actual_score": "6-4 6-3", "actual": 1, "observed_at": "2026-01-02T12:00:00+00:00"},
        {"distribution": {((6, 4), (6, 3)): 0.4, ((4, 6), (3, 6)): 0.6}, "actual_score": "4-6 3-6", "actual": 0, "observed_at": "2026-01-01T12:00:00+00:00"},
    ]

    report = evaluation_report(rows)

    assert report["oof_samples"] == 2
    assert report["first_observed_at"] == "2026-01-01T12:00:00+00:00"
    assert report["last_observed_at"] == "2026-01-02T12:00:00+00:00"


def test_tennis_package_exports_score_pipeline():
    assert hasattr(tennis, "parse_tennis_score")
    assert hasattr(tennis, "market_probabilities")
    assert hasattr(tennis, "empirical_score_distribution")
    assert hasattr(tennis, "evaluation_report")
