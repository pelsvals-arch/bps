from betdash.tennis.blend import blend_score_distributions, fit_blend_weight


def test_blend_preserves_total_mass_and_union_of_atoms():
    empirical = {((6, 4), (6, 3)): 0.7, ((4, 6), (3, 6)): 0.3}
    markov = {((6, 4), (6, 3)): 0.4, ((7, 6), (6, 4)): 0.6}

    blended = blend_score_distributions(empirical, markov, 0.5)

    assert abs(sum(blended.values()) - 1.0) < 1e-9
    assert set(blended) == set(empirical) | set(markov)


def test_fit_blend_weight_prefers_accurate_provider_on_oof_pairs():
    correct = {((6, 4), (6, 3)): 0.9, ((4, 6), (3, 6)): 0.1}
    wrong = {((6, 4), (6, 3)): 0.1, ((4, 6), (3, 6)): 0.9}
    pairs = [
        {"empirical": correct, "markov": wrong, "actual": ((6, 4), (6, 3))},
        {"empirical": correct, "markov": wrong, "actual": ((6, 4), (6, 3))},
        {"empirical": correct, "markov": wrong, "actual": ((6, 4), (6, 3))},
    ]

    weight, losses = fit_blend_weight(pairs)

    assert weight > 0.5
    assert losses["empirical"] < losses["markov"]
    assert "blend" in losses
