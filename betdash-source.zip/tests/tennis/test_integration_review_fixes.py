from datetime import datetime, timezone
import os
import subprocess
import sys
from typing import Any

from betdash.app.dashboard import score_market_rows
from betdash.db.repository import Repository, Snapshot
from betdash.data.sackmann import ensure_sackmann_tables
from betdash.tennis.empirical_provider import (
    empirical_provider_distribution,
    sackmann_history_rows,
)


def _seed_sackmann(repo: Repository) -> None:
    with repo._connect() as conn:
        ensure_sackmann_tables(conn)
        conn.execute(
            """
            INSERT INTO sackmann_matches (
                tour, tourney_id, tourney_name, surface, draw_size, tourney_level,
                tourney_date, match_num, winner_id, winner_name, loser_id, loser_name,
                score, best_of, round, winner_rank, loser_rank
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "atp", "t1", "Open", "Hard", 32, "A", "20260101", 1,
                1, "Novak Djokovic", 2, "Carlos Alcaraz", "6-4 6-3", 3, "R32", 10, 20,
            ),
        )


def test_empirical_provider_uses_real_history_with_blank_context(tmp_path):
    repo = Repository(str(tmp_path / "ctx.db"))
    _seed_sackmann(repo)
    target = {
        "surface": "Hard",
        "best_of": 3,
        "tourney_level": "",
        "round": "",
        "elo_gap": 0.0,
        "observed_at": "2026-11-28",
    }

    dist = empirical_provider_distribution(repo, "name:Новак Джокович", "name:Карлос Алькарас", target)

    assert ((6, 4), (6, 3)) in dist
    assert dist[((6, 4), (6, 3))] > 0.5


def test_empirical_provider_handles_missing_sackmann_table(tmp_path):
    repo = Repository(str(tmp_path / "missing.db"))

    assert sackmann_history_rows(repo, "name:Novak Djokovic", "name:Carlos Alcaraz", {}) == []


def test_score_market_rows_uses_newest_distribution():
    now = datetime(2026, 11, 28, 12, tzinfo=timezone.utc)
    older = {
        "event_uid": "e1",
        "provider": "blend",
        "observed_at": datetime(2026, 11, 28, 9, tzinfo=timezone.utc),
        "distribution": {((6, 4), (6, 3)): 0.9, ((4, 6), (3, 6)): 0.1},
    }
    newer = {
        "event_uid": "e1",
        "provider": "blend",
        "observed_at": now,
        "distribution": {((6, 4), (6, 3)): 0.2, ((4, 6), (3, 6)): 0.8},
    }
    snapshots = [
        Snapshot(
            event_uid="e1",
            bookmaker=book,
            market="match_winner",
            outcome=outcome,
            odds_decimal=odds,
            observed_at=now,
            source_event_id="s1",
            adapter_version="test",
        )
        for book, outcome, odds in (
            ("a", "p1", 2.0), ("a", "p2", 2.0),
            ("b", "p1", 2.1), ("b", "p2", 2.3),
        )
    ]

    rows = score_market_rows([older, newer], snapshots, "blend")

    assert rows[0]["outcome"] == "p2"
    assert rows[0]["model_prob"] == 0.8


def test_trainer_honors_best_of_and_blend_weight(monkeypatch):
    import betdash.models.trainer as trainer_module
    from betdash.normalize.models import CanonicalEvent

    captured: dict[str, Any] = {}
    monkeypatch.setattr(
        trainer_module, "build_features", lambda *a, **k: {"best_of": 5}
    )
    monkeypatch.setattr(
        trainer_module,
        "empirical_provider_distribution",
        lambda *a, **k: {((6, 4), (6, 3), (6, 4)): 1.0},
    )
    def _markov(p1, p2, best_of, **kwargs):
        captured["best_of"] = best_of
        return {((6, 4), (4, 6), (7, 5)): 1.0}

    monkeypatch.setattr(trainer_module, "markov_score_distribution", _markov)
    event = CanonicalEvent(
        event_uid="e5",
        sport="tennis",
        league="Test",
        participant_ids=("name:P1", "name:P2"),
        start_at="2026-11-28T12:00:00Z",
        mapping_confidence=1.0,
    )

    rows = trainer_module.build_score_distribution_rows(
        event, object(), 0.6, "run-5", datetime(2026, 11, 28, tzinfo=timezone.utc), blend_weight=0.8
    )

    assert captured["best_of"] == 5
    assert rows[-1]["blend_weight"] == 0.8


def test_empirical_provider_imports_standalone():
    result = subprocess.run(
        [sys.executable, "-c", "from betdash.tennis.empirical_provider import empirical_provider_distribution"],
        env={**os.environ, "PYTHONPATH": "src"},
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0, result.stderr
