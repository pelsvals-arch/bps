from pathlib import Path
import sqlite3

from betdash.db.repository import Repository
from betdash.data.sackmann import ingest_sackmann_matches


def test_ingest_sackmann_matches_creates_table_and_rows(tmp_path: Path):
    db = tmp_path / "test.db"
    repo = Repository(str(db))

    csv_path = tmp_path / "atp_matches_2024.csv"
    csv_path.write_text(
        "tourney_id,tourney_name,surface,draw_size,tourney_level,tourney_date,match_num,winner_id,winner_name,loser_id,loser_name,score,best_of,round,minutes,w_ace,w_df,w_svpt,w_1stIn,w_1stWon,w_2ndWon,w_SvGms,w_bpSaved,w_bpFaced,l_ace,l_df,l_svpt,l_1stIn,l_1stWon,l_2ndWon,l_SvGms,l_bpSaved,l_bpFaced\n"
        "2024-001,Test Open,Hard,32,A,20240101,1,100,Player A,200,Player B,6-4 6-3,3,R32,90,5,2,60,40,30,10,10,2,3,3,4,55,35,20,8,9,1,4\n",
        encoding="utf-8",
    )

    n = ingest_sackmann_matches(repo, [csv_path], tour="atp")
    assert n == 1

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT * FROM sackmann_matches").fetchone()
    assert row["tour"] == "atp"
    assert row["winner_name"] == "Player A"
    assert row["loser_name"] == "Player B"
    assert row["surface"] == "Hard"
    assert row["w_ace"] == 5
    assert row["is_retirement"] == 0
    conn.close()


def test_reingest_backfills_missing_rank_columns(tmp_path: Path):
    header = (
        "tourney_id,tourney_name,surface,draw_size,tourney_level,tourney_date,match_num,"
        "winner_id,winner_name,loser_id,loser_name,score,best_of,round,minutes,"
        "w_ace,w_df,w_svpt,w_1stIn,w_1stWon,w_2ndWon,w_SvGms,w_bpSaved,w_bpFaced,"
        "l_ace,l_df,l_svpt,l_1stIn,l_1stWon,l_2ndWon,l_SvGms,l_bpSaved,l_bpFaced,"
        "is_retirement,winner_rank,winner_rank_points,loser_rank,loser_rank_points"
    )
    row = (
        "legacy,Open,Hard,32,A,20240101,1,1,Player A,2,Player B,6-4 6-4,3,R32,90,"
        "5,1,60,39,28,12,10,4,8,4,1,60,39,19,9,9,3,7,0,7,1000,33,800"
    )
    db = tmp_path / "legacy.db"
    repo = Repository(str(db))
    csv_path = tmp_path / "atp.csv"
    csv_path.write_text(header + "\n" + row + "\n", encoding="utf-8")

    assert ingest_sackmann_matches(repo, [csv_path], tour="atp") == 1

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT winner_rank, loser_rank FROM sackmann_matches").fetchone()
    assert row["winner_rank"] == 7
    assert row["loser_rank"] == 33
    conn.close()
