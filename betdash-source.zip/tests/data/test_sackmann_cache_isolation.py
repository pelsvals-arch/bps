from datetime import datetime, timezone
from pathlib import Path

from betdash.data.sackmann import ingest_sackmann_matches
from betdash.db.repository import Repository
from betdash.models.features import build_features
from betdash.normalize.models import CanonicalEvent

HEADER = (
    "tourney_id,tourney_name,surface,draw_size,tourney_level,tourney_date,match_num,"
    "winner_id,winner_name,loser_id,loser_name,score,best_of,round,minutes,"
    "w_ace,w_df,w_svpt,w_1stIn,w_1stWon,w_2ndWon,w_SvGms,w_bpSaved,w_bpFaced,"
    "l_ace,l_df,l_svpt,l_1stIn,l_1stWon,l_2ndWon,l_SvGms,l_bpSaved,l_bpFaced"
)


def _row(tourney_id: str, winner: str, loser: str) -> str:
    return (
        f"{tourney_id},Old Open,Hard,32,A,20230101,1,100,{winner},200,{loser},"
        "6-4 6-4,3,R32,90,10,2,60,40,30,10,10,2,3,2,3,55,35,20,8,9,1,4"
    )


def _event(uid: str, p1: str, p2: str) -> CanonicalEvent:
    return CanonicalEvent(
        event_uid=uid,
        sport="tennis",
        league="Test",
        participant_ids=(f"name:{p1}", f"name:{p2}"),
        start_at=datetime(2023, 12, 1, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )


def _ingest(repo: Repository, path: Path, rows: list[str]) -> None:
    csv_path = path / f"{repo.path.replace('/', '_')}.csv"
    csv_path.write_text(f"{HEADER}\n" + "\n".join(rows) + "\n", encoding="utf-8")
    ingest_sackmann_matches(repo, [csv_path], tour="atp")


def test_sackmann_history_cache_is_bounded_across_cutoffs():
    from betdash.models import features

    db = "/tmp/bounded.db"
    features._SACKMANN_ROWS_CACHE.clear()
    for i in range(features.SACKMANN_CACHE_MAX_ENTRIES + 4):
        features._SACKMANN_ROWS_CACHE[(db, f"202301{i:02d}", i)] = [("old",)]

    newest_key = (db, "20991231", 999)
    features._remember_sackmann_rows(newest_key, [("new",)])

    assert len(features._SACKMANN_ROWS_CACHE) <= features.SACKMANN_CACHE_MAX_ENTRIES
    assert features._SACKMANN_ROWS_CACHE[newest_key] == [("new",)]


def test_sackmann_history_cache_is_isolated_between_repositories(tmp_path: Path):
    repo_a = Repository(str(tmp_path / "a.db"))
    _ingest(repo_a, tmp_path, [_row("2023-001", "Alice Smith", "Bob Jones")])
    first = build_features(_event("e-a", "Alice Smith", "Bob Jones"), repo_a)

    repo_b = Repository(str(tmp_path / "b.db"))
    _ingest(repo_b, tmp_path, [_row("2023-002", "Carol White", "Dan Brown")])
    second = build_features(_event("e-b", "Carol White", "Dan Brown"), repo_b)

    assert first["p1_matches_365"] == 1.0
    assert second["p1_matches_365"] == 1.0


def test_sackmann_history_cache_sees_new_matches_in_same_repository(tmp_path: Path):
    repo = Repository(str(tmp_path / "c.db"))
    _ingest(repo, tmp_path, [_row("2023-003", "Alice Smith", "Bob Jones")])
    build_features(_event("e-c", "Alice Smith", "Bob Jones"), repo)

    _ingest(repo, tmp_path, [_row("2023-004", "Alice Smith", "Dan Brown")])
    features = build_features(_event("e-c", "Alice Smith", "Bob Jones"), repo)

    assert features["p1_matches_365"] == 2.0
