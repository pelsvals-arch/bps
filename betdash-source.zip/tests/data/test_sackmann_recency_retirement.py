from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from betdash.data.sackmann import ingest_sackmann_matches
from betdash.db.repository import Repository
from betdash.models.features import build_features
from betdash.normalize.models import CanonicalEvent

HEADER = (
    "tourney_id,tourney_name,surface,draw_size,tourney_level,tourney_date,match_num,"
    "winner_id,winner_name,loser_id,loser_name,score,best_of,round,minutes,"
    "w_ace,w_df,w_svpt,w_1stIn,w_1stWon,w_2ndWon,w_SvGms,w_bpSaved,w_bpFaced,"
    "l_ace,l_df,l_svpt,l_1stIn,l_1stWon,l_2ndWon,l_SvGms,l_bpSaved,l_bpFaced,"
    "is_retirement,winner_rank,winner_rank_points,loser_rank,loser_rank_points"
)


def _row(
    tourney_id: str,
    date: str,
    winner: str,
    loser: str,
    w_svpt: int,
    w_won: int,
    l_svpt: int,
    l_won: int,
    retirement: int = 0,
    w_rank: str = "",
    l_rank: str = "",
    surface: str = "Hard",
) -> str:
    w1, w2 = int(w_won * 0.7), w_won - int(w_won * 0.7)
    l1, l2 = int(l_won * 0.7), l_won - int(l_won * 0.7)
    return (
        f"{tourney_id},Open,{surface},32,A,{date},1,1,{winner},2,{loser},"
        f"{'6-4 3-2 RET' if retirement else '6-4 6-4'},3,R32,90,5,1,{w_svpt},{int(w_svpt * 0.65)},{w1},{w2},10,4,8,"
        f"4,1,{l_svpt},{int(l_svpt * 0.65)},{l1},{l2},9,3,7,{retirement},"
        f"{w_rank},{w_rank and '1000'},{l_rank},{l_rank and '1000'}"
    )


def _event(p1: str, p2: str) -> CanonicalEvent:
    return CanonicalEvent(
        event_uid="e1",
        sport="tennis",
        league="Test",
        participant_ids=(f"name:{p1}", f"name:{p2}"),
        start_at=datetime(2023, 12, 1, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )


def _ingest(tmp_path: Path, rows: list[str]) -> Repository:
    repo = Repository(str(tmp_path / "test.db"))
    csv_path = tmp_path / "atp.csv"
    csv_path.write_text(HEADER + "\n" + "\n".join(rows) + "\n", encoding="utf-8")
    assert ingest_sackmann_matches(repo, [csv_path], tour="atp") == len(rows)
    return repo


def test_recent_serve_results_are_weighted_more_than_old_ones(tmp_path: Path) -> None:
    repo = _ingest(
        tmp_path,
        [
            _row("old", "20200101", "Player A", "Player B", 60, 54, 60, 30),
            _row("recent", "20231101", "Player A", "Player B", 60, 18, 60, 30),
        ],
    )

    features = build_features(_event("Player A", "Player B"), repo)

    # Raw average would be 0.60; recency weighting plus shrinkage must pull it down.
    assert 0.5 < features["p1_srv_win"] < 0.58
    assert features["p1_matches_30"] == 1.0


def test_retirement_history_raises_player_retire_risk(tmp_path: Path) -> None:
    repo = _ingest(
        tmp_path,
        [
            _row("r1", "20230501", "Player A", "Player B", 60, 40, 60, 28),
            _row("r2", "20230601", "Player B", "Player A", 60, 38, 45, 20, retirement=1),
        ],
    )

    features = build_features(_event("Player A", "Player B"), repo)

    assert features["p1_retire_risk"] > 0.05
    assert features["p2_retire_risk"] <= 0.05


def test_rank_features_use_pre_event_ranks(tmp_path: Path) -> None:
    repo = _ingest(
        tmp_path,
        [
            _row("r1", "20230501", "Player A", "Player B", 60, 40, 60, 28, w_rank="5", l_rank="50"),
            _row("r2", "20230601", "Player A", "Player B", 60, 42, 60, 27, w_rank="4", l_rank="48"),
        ],
    )

    features = build_features(_event("Player A", "Player B"), repo)

    assert features["p1_rank"] == 4.0
    assert features["p2_rank"] == 48.0
    assert features["p1_rank_diff"] > 0.0
    assert features["p2_rank_diff"] < 0.0


def test_surface_elo_is_tracked_per_surface(tmp_path: Path) -> None:
    repo = _ingest(
        tmp_path,
        [
            _row("h1", "20230101", "Player A", "Player B", 60, 45, 60, 25, surface="Hard"),
            _row("h2", "20230201", "Player A", "Player B", 60, 44, 60, 26, surface="Hard"),
            _row("c1", "20230301", "Player B", "Player A", 60, 43, 60, 27, surface="Clay"),
            _row("h3", "20231101", "Player A", "Player B", 60, 46, 60, 24, surface="Hard"),
        ],
    )

    features = build_features(_event("Player A", "Player B"), repo)

    assert features["p1_elo_hard"] > features["p2_elo_hard"]
    assert features["p1_elo_clay"] < features["p2_elo_clay"]
    assert features["p1_surface_elo"] > features["p2_surface_elo"]
