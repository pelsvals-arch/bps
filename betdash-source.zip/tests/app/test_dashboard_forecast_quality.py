from betdash.app import dashboard


class _St:
    def __init__(self):
        self.warnings = []
        self.infos = []

    def header(self, *args, **kwargs):
        pass

    def caption(self, *args, **kwargs):
        pass

    def info(self, text, *args, **kwargs):
        self.infos.append(text)

    def warning(self, text, *args, **kwargs):
        self.warnings.append(text)


def test_accuracy_screen_uses_forecast_quality_report(monkeypatch):
    calls = []
    report = {
        "links": {"linked": 0, "skipped": 1},
        "settlement": {"settled": 0, "skipped": 1},
        "n_settled": 0,
        "sample_type": "historical_settled_predictions_not_oof",
        "warning": "not out-of-sample",
    }

    def fake_report(repo):
        calls.append(repo)
        return report

    monkeypatch.setattr(dashboard, "forecast_quality_report", fake_report)
    runtime = object.__new__(dashboard.StreamlitRuntime)
    runtime.repository = object()
    st = _St()

    runtime._render_prediction_accuracy(st, px=None)

    assert len(calls) == 1
    assert any("not out-of-sample" in text for text in st.warnings + st.infos)
