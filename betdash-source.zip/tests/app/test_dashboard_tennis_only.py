from pathlib import Path

from betdash.app.dashboard import tennis_only


def test_tennis_filter_drops_other_sports():
    rows = [
        {"sport": "tennis", "event": "e1"},
        {"sport": "basketball", "event": "e2"},
        {"sport": "dota2", "event": "e3"},
    ]
    assert tennis_only(rows) == [{"sport": "tennis", "event": "e1"}]


def test_tennis_filter_accepts_event_objects():
    class Event:
        def __init__(self, sport: str, uid: str):
            self.sport = sport
            self.event_uid = uid

    events = [Event("tennis", "t1"), Event("basketball", "b1")]
    assert [e.event_uid for e in tennis_only(events)] == ["t1"]


def test_dashboard_has_no_sport_selector():
    source = Path(__file__).resolve().parents[2] / "src" / "betdash" / "app" / "dashboard.py"
    text = source.read_text(encoding="utf-8")
    assert 'selectbox("Спорт"' not in text
    assert 'selectbox("Sport"' not in text
