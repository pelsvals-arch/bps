from pathlib import Path

import betdash.app.dashboard as dashboard


def test_live_scoreboard_marks_stale_rows():
    source = Path(dashboard.__file__).read_text(encoding="utf-8")
    assert "_stale" in source
    assert "устаревшие" in source
