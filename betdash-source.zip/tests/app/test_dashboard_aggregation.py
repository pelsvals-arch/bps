from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

from betdash.app.dashboard import StreamlitRuntime
from betdash.config import Settings
from betdash.db.repository import Repository, Snapshot


def test_market_depth_aggregates_by_event_market_line(tmp_path):
    db = tmp_path / "db.sqlite"
    repo = Repository(str(db))
    repo.upsert_canonical_event(
        SimpleNamespace(
            event_uid="e1",
            sport="tennis",
            league="L",
            participant_ids=("a", "b"),
            start_at=datetime(2026, 1, 2, tzinfo=timezone.utc),
            mapping_confidence=1.0,
        ),
        market_close_at=None,
    )
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    repo.save_snapshots([
        Snapshot("e1", "pari", "match_winner", "p1", 2.0, t0, "s", "v1"),
        Snapshot("e1", "fonbet", "match_winner", "p1", 2.1, t0, "s", "v1"),
        Snapshot("e1", "pari", "match_winner", "p2", 1.8, t0, "s", "v1"),
        Snapshot("e1", "fonbet", "match_winner", "p2", 1.75, t0, "s", "v1"),
    ])

    rt = StreamlitRuntime(settings=Settings(db_path=str(db)))
    rows = rt.market_depth()

    assert len(rows) == 1
    assert rows[0]["best_bookmaker"] == "fonbet"
    assert "p1: 2.10" in rows[0]["best_odds_by_outcome"]
    assert rows[0]["coverage_books"] == 2


def test_market_depth_has_no_twenty_event_truncation():
    source = (Path(__file__).resolve().parents[2] / "src/betdash/app/dashboard.py").read_text(encoding="utf-8")

    assert "events[:20]" not in source


def test_dashboard_has_prediction_accuracy_screen():
    source = (Path(__file__).resolve().parents[2] / "src/betdash/app/dashboard.py").read_text(encoding="utf-8")

    assert '"Prediction accuracy"' in source
    assert "prediction_outcomes" in source


def test_prediction_accuracy_screen_refreshes_outcomes():
    source = (Path(__file__).resolve().parents[2] / "src/betdash/app/dashboard.py").read_text(encoding="utf-8")

    assert "forecast_quality_report(self.repository)" in source
    assert "settled_at_msk" in source
