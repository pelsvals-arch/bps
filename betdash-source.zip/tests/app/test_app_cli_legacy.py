from types import SimpleNamespace

import betdash.app.__main__ as app_main
import betdash.results.ingest as ingest_module


class _Report:
    def as_dict(self):
        return {"ingested": 1}


def test_main_keeps_legacy_ingest_flags(tmp_path, monkeypatch):
    captured = {}

    def fake_ingest(path, repo, create_missing_events=False):
        captured.update(path=str(path), create_missing_events=create_missing_events)
        return _Report()

    monkeypatch.setattr(ingest_module, "ingest_tennis_results_report", fake_ingest)
    monkeypatch.setattr(app_main, "Settings", lambda: SimpleNamespace(db_path=str(tmp_path / "db.sqlite")))
    monkeypatch.setattr(app_main, "Repository", lambda path: object())

    csv_path = tmp_path / "results.csv"
    rc = app_main.main(["--ingest-tennis", str(csv_path), "--create-missing-events"])

    assert rc == 0
    assert captured == {"path": str(csv_path), "create_missing_events": True}
