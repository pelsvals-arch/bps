from datetime import datetime, timezone, timedelta
from types import SimpleNamespace
from betdash.app.dashboard import StreamlitRuntime
from betdash.config import Settings
from betdash.db.repository import Repository, Snapshot

def test_opportunity_feed_has_movement(tmp_path):
    db = tmp_path / "db.sqlite"
    repo = Repository(str(db))
    repo.upsert_canonical_event(SimpleNamespace(event_uid="e1", sport="tennis", league="L", participant_ids=("a","b"), start_at=datetime(2026,1,2,tzinfo=timezone.utc), mapping_confidence=1.0), market_close_at=None)
    t0 = datetime(2026,1,1, tzinfo=timezone.utc)
    for i, odds in enumerate([2.0, 2.2]):
        repo.save_snapshots([
            Snapshot("e1","b1","match_winner","p1",odds,t0+timedelta(minutes=i),"s","v1",False,None,None),
            Snapshot("e1","b2","match_winner","p1",2.0,t0+timedelta(minutes=i),"s","v1",False,None,None),
            Snapshot("e1","b1","match_winner","p2",1.8,t0+timedelta(minutes=i),"s","v1",False,None,None),
            Snapshot("e1","b2","match_winner","p2",1.8,t0+timedelta(minutes=i),"s","v1",False,None,None),
        ])
    rt = StreamlitRuntime(settings=Settings(db_path=str(db)))
    feed = rt.opportunity_feed()
    row = [r for r in feed if r["event_uid"]=="e1" and r["market"]=="match_winner"][0]
    assert row["movement_abs"] is not None
