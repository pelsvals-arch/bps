from __future__ import annotations

from pathlib import Path

from types import SimpleNamespace

from betdash.app.dashboard import StreamlitRuntime, _with_msk_times, format_msk


def test_format_msk():
    assert format_msk("2026-11-27T12:34:00Z") == "27.11 15:34 MSK"
    assert format_msk(None) == "—"


def test_dashboard_has_live_scoreboard_and_moscow_time():
    source = (Path(__file__).resolve().parents[2] / "src/betdash/app/dashboard.py").read_text(encoding="utf-8")

    assert 'ZoneInfo("Europe/Moscow")' in source
    assert '"Live scoreboard"' in source
    assert "fetch_live_events" in source
    assert "start_at_msk" in source


def test_with_msk_times_formats_settled_at():
    rows = _with_msk_times([{"settled_at": "2026-11-27T12:34:00Z"}])

    assert rows[0]["settled_at_msk"] == "27.11 15:34 MSK"


def test_model_predictions_keep_event_start_at_alias():
    rt = object.__new__(StreamlitRuntime)
    rt.repository = SimpleNamespace(
        predictions=lambda limit: [{"event_uid": "e1", "market": "match_winner", "model_prob": 0.6, "outcome": "p1"}],
        events_for_resolution=lambda: [SimpleNamespace(event_uid="e1", sport="tennis", league="ATP", start_at=None)],
    )
    rt._event_labels = lambda events: {}

    row = rt.model_predictions(limit=10)[0]

    assert row["start_at"] is None
    assert row["event_start_at"] is None
