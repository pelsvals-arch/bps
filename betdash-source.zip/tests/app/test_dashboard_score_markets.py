from datetime import datetime, timezone

from betdash.app.dashboard import score_market_rows
from betdash.tennis.markets import canonical_tennis_market
from betdash.db.repository import Snapshot

NOW = datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
DIST = {
    "event_uid": "e1",
    "model_run_id": "run-1",
    "provider": "blend",
    "observed_at": NOW,
    "distribution": {((6, 4), (6, 3)): 0.6, ((4, 6), (3, 6)): 0.4},
    "p1_prob": 0.6,
}


def _snapshot(bookmaker, outcome, odds):
    return Snapshot(
        event_uid="e1",
        bookmaker=bookmaker,
        market="match_winner",
        outcome=outcome,
        odds_decimal=odds,
        observed_at=NOW,
        source_event_id="s1",
        adapter_version="test",
        line=None,
    )


def test_score_market_rows_aggregate_to_one_row_per_market():
    snapshots = [
        _snapshot("book-a", "p1", 2.1),
        _snapshot("book-a", "p2", 1.7),
        _snapshot("book-b", "p1", 2.0),
        _snapshot("book-b", "p2", 1.8),
    ]

    rows = score_market_rows([DIST], snapshots, "blend")

    assert len(rows) == 1
    assert rows[0]["outcome"] == "p1"
    assert rows[0]["best_odds"] == 2.1
    assert rows[0]["bookmaker"] == "book-a"
    assert rows[0]["value_ev"] is not None


def test_score_market_rows_use_each_event_own_snapshot_time():
    later = datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    earlier = datetime(2026, 11, 25, 10, tzinfo=timezone.utc)
    dist_e2 = dict(DIST, event_uid="e2", observed_at=earlier)

    def snap(event_uid, bookmaker, odds, observed_at):
        return Snapshot(
            event_uid=event_uid,
            bookmaker=bookmaker,
            market="match_winner",
            outcome="p1",
            odds_decimal=odds,
            observed_at=observed_at,
            source_event_id="s",
            adapter_version="test",
        )

    rows = score_market_rows(
        [DIST, dist_e2],
        [
            snap("e1", "book-a", 2.1, later),
            snap("e2", "book-a", 2.2, earlier),
        ],
        "blend",
    )

    assert {row["event_uid"] for row in rows} == {"e1", "e2"}


def test_score_market_rows_do_not_claim_value_without_market_coverage():
    rows = score_market_rows([DIST], [_snapshot("book-a", "p1", 2.1)], "blend")

    assert len(rows) == 1
    assert rows[0]["value_ev"] is None


def test_score_market_rows_show_canonical_names_for_market_aliases():
    def snap(market, outcome, line):
        return Snapshot(
            event_uid="e1",
            bookmaker="book-a",
            market=market,
            outcome=outcome,
            odds_decimal=2.0,
            observed_at=NOW,
            source_event_id="s",
            adapter_version="test",
            line=line,
        )

    snapshots = [snap("total_points", "over", 19.5), snap("spread", "p1", 1.5)]

    rows = score_market_rows([DIST], snapshots, "blend")

    assert canonical_tennis_market("total_points") == "total_games"
    assert canonical_tennis_market("spread") == "game_handicap"
    assert {(row["market"], row["market_canonical"]) for row in rows} == {
        ("total_points", "total_games"),
        ("spread", "game_handicap"),
    }
