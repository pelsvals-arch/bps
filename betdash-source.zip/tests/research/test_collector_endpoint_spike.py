from pathlib import Path


def test_endpoint_spike_is_read_only():
    report = (
        Path(__file__).resolve().parents[2]
        / "docs/research/2026-11-27-collector-endpoint-spike.md"
    ).read_text(encoding="utf-8")

    assert "/api/xds/v2/" in report
    assert "/api/cls/" in report
    assert "/events/listBase" in report
    assert "/events/event" in report
    assert "not a runtime source" in report
