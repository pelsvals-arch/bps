from datetime import datetime, timezone
from betdash.backtest.clv import backfill_clv, compute_clv, clv_report
from betdash.backtest.closing import refresh_closing_lines
from betdash.db.repository import Repository, Snapshot
from betdash.normalize.models import CanonicalEvent


def test_compute_clv_basic():
    assert compute_clv(2.10, 2.00) > 0
    assert compute_clv(1.90, 2.00) < 0
    assert compute_clv(2.00, 2.00) == 0
    assert compute_clv(None, 2.0) is None
    assert compute_clv(1.0, 2.0) is None


def test_clv_compares_same_bookmaker_not_cross_book_max(tmp_path):
    repo = Repository(str(tmp_path / "t.sqlite"))
    repo.upsert_canonical_event(CanonicalEvent(
        event_uid="e1", sport="tennis", league="L",
        start_at=datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc),
        participant_ids=("a", "b"), mapping_confidence=1.0,
    ))
    repo.save_snapshots([
        Snapshot(event_uid="e1", bookmaker="b1", market="match_winner", outcome="p1",
                 odds_decimal=2.0, observed_at=datetime(2026, 1, 1, 11, 20, tzinfo=timezone.utc),
                 source_event_id="e1", adapter_version="t"),
        Snapshot(event_uid="e1", bookmaker="b1", market="match_winner", outcome="p1",
                 odds_decimal=1.8, observed_at=datetime(2026, 1, 1, 11, 50, tzinfo=timezone.utc),
                 source_event_id="e1", adapter_version="t"),
        Snapshot(event_uid="e1", bookmaker="b2", market="match_winner", outcome="p1",
                 odds_decimal=5.0, observed_at=datetime(2026, 1, 1, 11, 50, tzinfo=timezone.utc),
                 source_event_id="e1", adapter_version="t"),
    ])
    with repo._connect() as conn:
        conn.execute(
            "INSERT INTO predictions(prediction_id,event_uid,market,outcome,model_prob,odds_decimal,bookmaker,observed_at,event_start_at) "
            "VALUES('pred-1','e1','match_winner','p1',0.55,2.0,'b1','2026-01-01T10:00:00+00:00','2026-01-01T12:00:00+00:00')"
        )
        conn.commit()
    refresh_closing_lines(repo, close_window_minutes=10)
    assert backfill_clv(repo) == 1
    with repo._connect() as conn:
        row = conn.execute("SELECT closing_odds, clv FROM predictions").fetchone()
    assert float(row["closing_odds"]) == 1.8
    assert float(row["clv"]) > 0.1


def test_clv_report_has_robust_stats(tmp_path):
    repo = Repository(str(tmp_path / "t.sqlite"))
    repo.upsert_canonical_event(CanonicalEvent(
        event_uid="e1", sport="tennis", league="L", start_at=datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc),
        participant_ids=("a", "b"), mapping_confidence=1.0,
    ))
    with repo._connect() as conn:
        conn.executemany("INSERT INTO predictions(prediction_id,event_uid,market,outcome,model_prob,odds_decimal,observed_at,created_at,clv) VALUES(?,?,?,?,?,?,?,?,?)", [
            ("p1","e1","match_winner","p1",0.5,2.0,"2026-01-01T09:00:00+00:00","2026-01-01T09:00:00+00:00",0.1),
            ("p2","e1","match_winner","p1",0.5,2.0,"2026-01-01T09:00:00+00:00","2026-01-01T09:00:00+00:00",0.0),
            ("p3","e1","match_winner","p1",0.5,2.0,"2026-01-01T09:00:00+00:00","2026-01-01T09:00:00+00:00",-0.1),
            ("p4","e1","match_winner","p1",0.5,2.0,"2026-01-01T09:00:00+00:00","2026-01-01T09:00:00+00:00",8.0),
        ])
        conn.commit()
    rep = clv_report(repo, min_samples=1)
    assert "by_sport" not in rep
    o = rep["overall"]
    assert o["n"] == 4
    assert o["median"] == 0.05  # median of [-0.1,0,0.1,8.0]
    assert o["p90"] is not None
    assert o["trimmed_mean"] is not None
    assert o["outlier_pct"] > 0
