from betdash.models.trainer import barnett_clarke_hold_rates


def test_hold_rates_use_opponent_return_and_have_defaults():
    rates = barnett_clarke_hold_rates(
        {
            "p1_srv_win": 0.68,
            "p2_srv_win": 0.51,
            "p1_ret_win": 0.38,
            "p2_ret_win": 0.32,
        }
    )
    assert rates[0] == (0.68 + (1.0 - 0.32)) / 2
    assert rates[1] == (0.51 + (1.0 - 0.38)) / 2

    defaults = barnett_clarke_hold_rates({})
    assert defaults == (0.62, 0.62)
