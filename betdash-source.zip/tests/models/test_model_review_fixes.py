from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from betdash.analytics.calibration import kelly_fraction
from betdash.config import Settings
from betdash.db.repository import Repository, Snapshot
from betdash.models.trainer import Trainer
from betdash.normalize.models import CanonicalEvent
from betdash.results.ingest import ResultRow

START = datetime(2026, 1, 10, 18, 0, tzinfo=timezone.utc)
DECISION = START - timedelta(hours=1)


def _seed_repo(tmp_path: Path, score: str = "6-0 6-0") -> Repository:
    repo = Repository(str(tmp_path / "b.sqlite"))
    event = CanonicalEvent(
        event_uid="e1",
        sport="tennis",
        league="ATP",
        participant_ids=("p1", "p2"),
        start_at=START,
        mapping_confidence=0.99,
    )
    repo.upsert_canonical_event(event)
    repo.save_snapshots(
        [
            Snapshot("e1", "b1", "match_winner", "p1", 2.0, DECISION, "s1", "v1"),
            Snapshot("e1", "b1", "match_winner", "p2", 2.0, DECISION, "s1", "v1"),
            Snapshot("e1", "b2", "match_winner", "p1", 1.9, DECISION, "s2", "v1"),
            Snapshot("e1", "b2", "match_winner", "p2", 2.1, DECISION, "s2", "v1"),
        ]
    )
    repo.save_result(
        "e1",
        ResultRow(
            participant_a="p1",
            participant_b="p2",
            date="2026-01-10",
            score=score,
            league="ATP",
        ),
    )
    return repo


def test_welo_weight_is_wired_into_trainer_rating_updates(tmp_path):
    repo = _seed_repo(tmp_path)
    trainer = Trainer(repo, Settings(checkpoint_dir=str(tmp_path / "ckpt")))

    trainer.step()

    # Plain Elo with k=20 and p=0.5 lands on 1510. A decisive 6-0 6-0 score
    # must move the rating further via _welo_weight (weight ~= 1.63 here).
    assert trainer._elo["tennis"].get("p1") > 1515.0


def test_market_prior_requires_fresh_nonlive_and_two_books():
    fresh = [
        Snapshot("e", "b1", "match_winner", "p1", 2.0, DECISION, "s1", "v1"),
        Snapshot("e", "b1", "match_winner", "p2", 2.0, DECISION, "s1", "v1"),
        Snapshot("e", "b2", "match_winner", "p1", 1.9, DECISION, "s2", "v1"),
        Snapshot("e", "b2", "match_winner", "p2", 2.1, DECISION, "s2", "v1"),
    ]
    stale = Snapshot("e", "b3", "match_winner", "p1", 1.05, START - timedelta(hours=20), "s3", "v1")
    live = Snapshot("e", "b4", "match_winner", "p1", 1.05, DECISION, "s4", "v1", is_live=True)

    prob, coverage = Trainer._market_p1_from_snapshots(fresh + [stale, live], START)

    assert coverage == 2
    assert 0.0 < prob < 1.0
    one_book = [fresh[0], fresh[1]]
    assert Trainer._market_p1_from_snapshots(one_book, START) == (0.0, 1)


def test_market_probs_uses_real_prior_only_with_coverage():
    trainer = Trainer.__new__(Trainer)

    low = trainer._market_probs("match_winner", None, {}, 0.7, object(), alpha=0.3, market_p1=0.4, coverage_books=1)
    good = trainer._market_probs("match_winner", None, {}, 0.7, object(), alpha=0.3, market_p1=0.4, coverage_books=2)

    assert low["p1"] == pytest.approx(0.7)
    assert low["p2"] == pytest.approx(0.3)
    assert good["p1"] == pytest.approx(0.61)


def test_oof_metrics_use_actual_market_pairs_and_stakes(tmp_path):
    trainer = Trainer(Repository(str(tmp_path / "metrics.sqlite")), Settings())
    rows = []
    for i, actual in enumerate([1, 0, 1, 0, 1, 0]):
        rows.append(
            {
                "event_uid": f"e{i}",
                "event_start_at": (START + timedelta(hours=i)).isoformat(),
                "features": {"signal": float(actual)},
                "actual": actual,
                "market_p1": 0.99 if actual else 0.01,
                "market_coverage": 2,
                "offered_odds": 2.0,
            }
        )

    metrics = trainer._build_metrics(rows, [], {"accuracy": None})

    assert metrics["blend_alpha"] > 0.0
    assert metrics["suggested_stake"] > 0.0
    assert metrics["oof_calibration_bins"]


def test_kelly_fraction_never_returns_negative_on_bad_cap():
    assert kelly_fraction(0.6, 2.0, cap=-1.0) == 0.0


def test_model_diagnostics_displays_oof_metrics():
    source = (
        Path(__file__).resolve().parents[2]
        / "src" / "betdash" / "app" / "dashboard.py"
    ).read_text(encoding="utf-8")
    assert "oof_brier" in source
    assert "OOF" in source


def test_oof_calibration_and_market_comparison_are_reported(tmp_path):
    trainer = Trainer(Repository(str(tmp_path / "cal.sqlite")), Settings())
    rows = [
        {
            "event_uid": f"c{i}",
            "event_start_at": (START + timedelta(hours=i)).isoformat(),
            "features": {"signal": float(actual)},
            "actual": actual,
            "market_p1": 0.2 if actual == 0 else 0.8,
            "market_coverage": 2,
            "offered_odds": 2.0,
        }
        for i, actual in enumerate([0, 1, 0, 1])
    ]

    metrics = trainer._build_metrics(rows, [], {"accuracy": None})

    assert metrics["calibration_breakpoints"]
    assert metrics["market_comparison"]["n"] > 0


def test_generate_predictions_applies_oof_calibration(tmp_path):
    repo = _seed_repo(tmp_path, score="6-0 6-0")
    # Add a separate near-future, unresolved event so predictions are generated
    # and the market prior is inside the freshness window.
    future = datetime.now(timezone.utc) + timedelta(hours=1)
    recent = future - timedelta(minutes=30)
    repo.upsert_canonical_event(
        CanonicalEvent(
            event_uid="cal", sport="tennis", league="ATP",
            participant_ids=("p1", "p2"), start_at=future, mapping_confidence=0.99,
        )
    )
    repo.save_snapshots(
        [
            Snapshot("cal", "b1", "match_winner", "p1", 2.0, recent, "s9", "v1"),
            Snapshot("cal", "b1", "match_winner", "p2", 2.0, recent, "s9", "v1"),
            Snapshot("cal", "b2", "match_winner", "p1", 1.9, recent, "s10", "v1"),
            Snapshot("cal", "b2", "match_winner", "p2", 2.1, recent, "s10", "v1"),
        ]
    )
    trainer = Trainer(repo, Settings(checkpoint_dir=str(tmp_path / "ckpt")))
    breaks = [(0.0, 1.0, 0.9)]

    preds = trainer._generate_predictions(
        "run", None, {"tennis": __import__("betdash.models.baseline", fromlist=["EloRating"]).EloRating()},
        {"tennis": __import__("betdash.models.baseline", fromlist=["GlickoRating"]).GlickoRating()},
        calibration_breaks=breaks,
    )

    p1 = [p for p in preds if p["outcome"] == "p1"]
    assert p1
    assert p1[0]["model_prob"] == pytest.approx(0.9)
