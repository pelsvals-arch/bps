from datetime import datetime, timedelta, timezone

from betdash.config import Settings
from betdash.db.repository import Repository, init_db
from betdash.models.baseline import EloRating, GlickoRating
from betdash.models.trainer import Trainer
from betdash.normalize.models import CanonicalEvent


def test_generate_predictions_reuses_cached_results(tmp_path, monkeypatch):
    repo = Repository(str(tmp_path / "reuse.db"))
    init_db(repo.path)
    event = CanonicalEvent(
        event_uid="future-match",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime.now(timezone.utc) + timedelta(hours=1),
        mapping_confidence=1.0,
    )
    repo.upsert_canonical_event(event)

    seen = {}

    def fake_build_features(event, repo, **kwargs):
        seen.update(kwargs)
        return {"p1_srv_win": 0.62, "p2_srv_win": 0.58}

    monkeypatch.setattr("betdash.models.trainer.build_features", fake_build_features)
    trainer = Trainer(repo, Settings(checkpoint_dir=str(tmp_path / "ckpt")))
    trainer._generate_predictions(
        "run",
        None,
        {"tennis": EloRating()},
        {"tennis": GlickoRating()},
    )

    assert "cached_results" in seen
    assert isinstance(seen["cached_results"], list)


def test_generate_predictions_loads_results_only_once(tmp_path, monkeypatch):
    repo = Repository(str(tmp_path / "once.db"))
    init_db(repo.path)
    event = CanonicalEvent(
        event_uid="future-once",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime.now(timezone.utc) + timedelta(hours=1),
        mapping_confidence=1.0,
    )
    repo.upsert_canonical_event(event)

    calls = {"n": 0}
    original_results = repo.results

    def counted_results(*args, **kwargs):
        calls["n"] += 1
        return original_results(*args, **kwargs)

    monkeypatch.setattr(repo, "results", counted_results)
    trainer = Trainer(repo, Settings(checkpoint_dir=str(tmp_path / "ckpt-once")))
    trainer._generate_predictions(
        "run",
        None,
        {"tennis": EloRating()},
        {"tennis": GlickoRating()},
    )

    assert calls["n"] == 1
