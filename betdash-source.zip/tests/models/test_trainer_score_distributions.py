from datetime import datetime, timezone

from betdash.models import trainer
from betdash.normalize.models import CanonicalEvent


class FakeRepo:
    def __init__(self):
        self.prediction_saves = 0

    def save_predictions(self, rows):
        self.prediction_saves += 1
        return len(rows)


def test_build_score_distribution_rows_creates_three_providers(monkeypatch):
    event = CanonicalEvent(
        event_uid="e1",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2026, 11, 28, 12, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )
    monkeypatch.setattr(
        trainer,
        "build_features",
        lambda *a, **k: {
            "surface": "hard",
            "p1_srv_win": 0.65,
            "p2_srv_win": 0.55,
            "p1_ret_win": 0.35,
            "p2_ret_win": 0.40,
            "p1_elo_blend": 1550.0,
            "p2_elo_blend": 1450.0,
        },
    )
    monkeypatch.setattr(
        trainer,
        "empirical_provider_distribution",
        lambda repo, p1, p2, target: {((6, 4), (6, 3)): 0.6, ((4, 6), (3, 6)): 0.4},
    )
    repo = FakeRepo()

    rows = trainer.build_score_distribution_rows(
        event, repo, 0.6, "run-1", datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    )

    assert {row["provider"] for row in rows} == {"empirical", "markov", "blend"}
    assert all(abs(sum(row["distribution"].values()) - 1.0) < 1e-9 for row in rows)
    assert repo.prediction_saves == 0


def test_markov_uses_server_hold_rates(monkeypatch):
    event = CanonicalEvent(
        event_uid="e4",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2026, 11, 28, 12, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )
    monkeypatch.setattr(
        trainer,
        "build_features",
        lambda *a, **k: {
            "surface": 0.0,
            "surface_name": "hard",
            "best_of": 3,
            "p1_srv_win": 0.68,
            "p2_srv_win": 0.51,
            "p1_ret_win": 0.32,
            "p2_ret_win": 0.49,
        },
    )
    monkeypatch.setattr(
        trainer,
        "empirical_provider_distribution",
        lambda repo, p1, p2, target: {((6, 4), (6, 3)): 1.0},
    )
    captured = {}

    def fake_markov(p1_hold, p2_hold, **kwargs):
        captured["holds"] = (p1_hold, p2_hold)
        return {((6, 4), (6, 3)): 1.0}

    monkeypatch.setattr(trainer, "markov_score_distribution", fake_markov)

    trainer.build_score_distribution_rows(
        event, FakeRepo(), 0.6, "run-1", datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    )

    assert captured["holds"] == (0.595, 0.595)


def test_elo_gap_is_converted_to_rank_units(monkeypatch):
    event = CanonicalEvent(
        event_uid="e3",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2026, 11, 28, 12, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )
    monkeypatch.setattr(
        trainer,
        "build_features",
        lambda *a, **k: {
            "surface": "hard",
            "p1_srv_win": 0.65,
            "p2_srv_win": 0.55,
            "p1_ret_win": 0.35,
            "p2_ret_win": 0.40,
            "p1_elo_blend": 1700.0,
            "p2_elo_blend": 1500.0,
        },
    )
    captured = {}

    def fake_empirical(repo, p1, p2, target):
        captured["target"] = target
        return {((6, 4), (6, 3)): 1.0}

    monkeypatch.setattr(trainer, "empirical_provider_distribution", fake_empirical)

    trainer.build_score_distribution_rows(
        event, FakeRepo(), 0.6, "run-1", datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    )

    assert abs(captured["target"]["elo_gap"] - (200.0 / 15.0)) < 1e-6


def test_build_features_exposes_surface_for_score_context(tmp_path, monkeypatch):
    from betdash.db.repository import Repository
    from betdash.models import features

    monkeypatch.setattr(
        features,
        "_tennis_sackmann_features",
        lambda repo, p1, p2, start_at: {"surface": "hard", "p1_elo_blend": 1500.0},
    )
    event = CanonicalEvent(
        event_uid="e2",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2026, 11, 28, 12, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )

    result = features.build_features(event, Repository(str(tmp_path / "features.db")))

    assert result["surface_name"] == "hard"
    assert isinstance(result["surface"], float)
