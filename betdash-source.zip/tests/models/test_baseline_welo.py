from betdash.models.baseline import EloRating, _welo_weight, score_margin


def test_welo_updates_more_for_decisive_score():
    close = EloRating(k=20.0)
    decisive = EloRating(k=20.0)
    close.update("A", "B", 1.0, weight=_welo_weight(score_margin("6-4 7-6")))
    decisive.update("A", "B", 1.0, weight=_welo_weight(score_margin("6-0 6-0")))
    assert decisive.get("A") > close.get("A")


def test_welo_missing_score_uses_neutral_weight():
    assert _welo_weight(score_margin(None)) == 1.0


def test_score_margin_ignores_tiebreak_points():
    assert score_margin("6-7(4-6) 7-5") == 3.0
