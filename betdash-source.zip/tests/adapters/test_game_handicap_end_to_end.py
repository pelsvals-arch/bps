from datetime import datetime, timezone

from betdash.adapters.json_family import JsonFamilyAdapter
from betdash.adapters.marathon import MarathonAdapter
from betdash.config import Settings
from betdash.normalize.models import RawOdd


def _json_family_payload():
    return {
        "events": [{
            "id": "E1",
            "sportId": "T1",
            "team1": "A",
            "team2": "B",
            "startTime": 1893456000000,
        }],
        "sports": [{"id": "T1", "name": "Теннис", "kind": "sport"}],
        "tournamentInfos": [{"id": "T1", "caption": "ATP"}],
        "customFactors": [{"e": "E1", "factors": [
            {"f": 927, "v": 1.9, "p": -2.5},
            {"f": 928, "v": 1.9, "p": -2.5},
        ]}],
    }


def test_json_family_persists_two_sided_game_handicap():
    rows = JsonFamilyAdapter("pari", Settings()).parse_fixture(_json_family_payload())
    handicap = [row for row in rows if row.market == "game_handicap"]
    assert len(handicap) == 2
    assert {row.outcome for row in handicap} == {"p1", "p2"}


def test_raw_odd_carries_line_for_handicap_markets():
    odd = RawOdd(
        bookmaker="pari",
        source_event_id="E1",
        sport="tennis",
        league="ATP",
        participants=("A", "B"),
        market="game_handicap",
        outcome="p1",
        odds_decimal=1.9,
        observed_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        is_live=False,
        line=1.5,
    )
    assert odd.line == 1.5


def test_marathon_pairs_opposite_signed_handicap_lines():
    def build(first, second):
        return MarathonAdapter(Settings()).parse_json({"items": [{
            "name": "Tennis",
            "sportCode": "tennis",
            "events": [{
                "eventId": "1",
                "sportCode": "tennis",
                "displayTime": "2027-01-01T00:00:00",
                "members": {
                    "1": {"name": "Novak Djokovic"},
                    "2": {"name": "Carlos Alcaraz"},
                },
                "markets": {"m1": {
                    "model": "MTCH_HB",
                    "selections": {
                        "s1": {"name": first, "coeff": {"price": "1.9"}},
                        "s2": {"name": second, "coeff": {"price": "1.9"}},
                    },
                }},
            }],
        }]})

    rows = build("1 (+1.5)", "2 (-1.5)")
    assert len(rows) == 2
    assert {row.outcome for row in rows if row.market == "game_handicap"} == {"p1", "p2"}
