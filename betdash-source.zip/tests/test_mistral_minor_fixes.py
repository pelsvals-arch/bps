from pathlib import Path

from betdash.backtest.clv import backfill_clv
from betdash.db.repository import Repository


SRC = Path(__file__).resolve().parents[1] / "src" / "betdash"


def test_market_metrics_uses_normal_datetime_import():
    text = (SRC / "analytics" / "market_metrics.py").read_text(encoding="utf-8")
    assert "__import__('datetime')" not in text


def test_trainer_stop_has_no_empty_lock_block():
    text = (SRC / "models" / "trainer.py").read_text(encoding="utf-8")
    assert "with self._lock:\n            pass" not in text


def test_dashboard_chart_label_uses_line_column():
    text = (SRC / "app" / "dashboard.py").read_text(encoding="utf-8")
    assert 'chart_df.get("line", pd.Series' not in text


def test_backfill_clv_does_not_erase_existing_clv(tmp_path):
    repo = Repository(str(tmp_path / "clv.sqlite"))
    with repo._connect() as conn:
        conn.execute(
            "INSERT INTO predictions(prediction_id,event_uid,market,outcome,model_prob,odds_decimal,clv,observed_at,event_start_at) "
            "VALUES('pred-1','e1','match_winner','p1',0.55,2.0,0.2,'2026-01-01T10:00:00+00:00','2026-01-01T12:00:00+00:00')"
        )
        conn.commit()

    backfill_clv(repo)

    with repo._connect() as conn:
        row = conn.execute("SELECT clv FROM predictions WHERE prediction_id='pred-1'").fetchone()
    assert float(row["clv"]) == 0.2
