from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

import pytest

import importlib

prediction_outcomes_module = importlib.import_module("betdash.analytics.prediction_outcomes")
from betdash.analytics.prediction_outcomes import backfill_prediction_outcomes, prediction_outcomes
from betdash.db.repository import Repository


def _seed(db_path, *, with_result=True, model_prob=0.5, result_a="Roger Federer", result_b="Novak Djokovic", score="6-4 6-4"):
    repo = Repository(str(db_path))
    conn = sqlite3.connect(str(db_path))
    now = datetime(2026, 11, 27, 12, tzinfo=timezone.utc).isoformat()
    conn.execute(
        "INSERT INTO canonical_events(event_uid,sport,league,participant_ids,start_at,mapping_confidence) VALUES(?,?,?,?,?,?)",
        ("e1", "tennis", "ATP", '["name:Novak Djokovic","name:Roger Federer"]', now, 1.0),
    )
    conn.execute(
        "INSERT INTO predictions(prediction_id,event_uid,market,outcome,model_prob,odds_decimal,observed_at,clv) VALUES(?,?,?,?,?,?,?,?)",
        ("p1id", "e1", "match_winner", "p2", model_prob, 2.0, now, 0.1),
    )
    if with_result:
        conn.execute(
            "INSERT INTO results(event_uid,participant_a,participant_b,score,source) VALUES(?,?,?,?,?)",
            ("e1", result_a, result_b, score, "test"),
        )
    conn.commit()
    conn.close()
    return repo


def test_outcome_passes_result_comment_to_score_parser(monkeypatch):
    captured = {}

    def fake_parser(score, comment=""):
        captured["score"] = score
        captured["comment"] = comment
        return "left"

    monkeypatch.setattr(prediction_outcomes_module, "tennis_winner_side", fake_parser)
    row = {
        "participant_a": "Roger Federer",
        "participant_b": "Novak Djokovic",
        "score": "",
        "comment": "RET",
    }

    outcome = prediction_outcomes_module._outcome(
        ["name:Novak Djokovic", "name:Roger Federer"], row
    )

    assert captured == {"score": "", "comment": "RET"}
    assert outcome in {"p1", "p2"}


def test_prediction_outcome_uses_canonical_order(tmp_path):
    repo = _seed(tmp_path / "canonical.db")

    report = backfill_prediction_outcomes(repo)
    rows = prediction_outcomes(repo)

    assert report["settled"] == 1
    assert len(rows) == 1
    assert rows[0]["actual"] == 1
    assert rows[0]["brier"] == pytest.approx(0.25)
    assert rows[0]["log_loss"] == pytest.approx(0.693147, abs=1e-5)


def test_prediction_outcome_ignores_missing_results(tmp_path):
    repo = _seed(tmp_path / "missing.db", with_result=False)

    report = backfill_prediction_outcomes(repo)

    assert report["skipped"] == 1
    assert prediction_outcomes(repo) == []


def test_prediction_outcomes_are_idempotent(tmp_path):
    repo = _seed(tmp_path / "idem.db")

    assert backfill_prediction_outcomes(repo)["settled"] == 1
    assert backfill_prediction_outcomes(repo)["settled"] == 1
    assert len(prediction_outcomes(repo)) == 1


def test_prediction_outcome_uses_score_for_winner(tmp_path):
    repo = _seed(tmp_path / "score.db", result_a="Roger Federer", result_b="Novak Djokovic")

    backfill_prediction_outcomes(repo)

    assert prediction_outcomes(repo)[0]["actual"] == 1


def test_prediction_outcome_uses_score_to_pick_winner(tmp_path):
    repo = _seed(
        tmp_path / "score-reversed.db",
        result_a="Roger Federer",
        result_b="Novak Djokovic",
        score="4-6 4-6",
    )
    with repo._connect() as conn:
        conn.execute("UPDATE predictions SET outcome='p1' WHERE prediction_id='p1id'")

    backfill_prediction_outcomes(repo)

    assert prediction_outcomes(repo)[0]["actual"] == 1


def test_prediction_outcome_ignores_duplicate_results(tmp_path):
    repo = _seed(tmp_path / "dupes.db")
    with repo._connect() as conn:
        conn.execute(
            "INSERT INTO results(event_uid,participant_a,participant_b,score,source) VALUES(?,?,?,?,?)",
            ("e1", "Novak Djokovic", "Roger Federer", "6-4 6-4", "other"),
        )

    report = backfill_prediction_outcomes(repo)

    assert report["settled"] == 1
    assert len(prediction_outcomes(repo)) == 1


def test_prediction_outcome_clamps_certain_probabilities(tmp_path):
    repo = _seed(tmp_path / "certain.db", model_prob=1.0)

    backfill_prediction_outcomes(repo)

    assert prediction_outcomes(repo)[0]["log_loss"] < 30


def test_prediction_outcome_skips_malformed_rows(tmp_path):
    repo = _seed(tmp_path / "malformed.db")
    with repo._connect() as conn:
        conn.execute("UPDATE canonical_events SET participant_ids='not json' WHERE event_uid='e1'")

    assert backfill_prediction_outcomes(repo)["skipped"] == 1
