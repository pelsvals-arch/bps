from betdash.analytics.market_metrics import median, z_score

def test_median_odd_even():
    assert median([1,2,3]) == 2
    assert median([1,2,3,4]) == 2.5

def test_z_score():
    z = z_score(2.2, [2.0,2.1,2.0,1.9])
    assert z is not None
    assert z > 0
    assert z_score(2.0, [2.0,2.0]) == 0.0
