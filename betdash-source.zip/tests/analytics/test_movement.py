from betdash.analytics.market_metrics import movement_delta

def test_movement_delta():
    assert movement_delta(2.0, 2.2) == {"abs": 0.20000000000000018, "pct": 0.10000000000000009}
    assert movement_delta(2.0, 2.0) == {"abs": 0.0, "pct": 0.0}
    assert movement_delta(None, 2.0) == {"abs": None, "pct": None}
