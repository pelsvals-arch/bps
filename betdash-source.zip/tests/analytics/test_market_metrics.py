from betdash.analytics.market_metrics import margin, fair_odds, edge_vs_consensus, movement_delta

def test_margin_1x2():
    # 2.10,3.40,3.60 -> ~4.6%
    m = margin([2.10,3.40,3.60])
    assert abs(m - 0.04808590102707755) < 1e-9

def test_fair_odds_sum_inverse():
    fair = fair_odds([2.10,3.40,3.60])
    assert len(fair)==3
    inv = sum(1/x for x in fair)
    assert abs(inv-1.0) < 1e-9

def test_edge_vs_consensus():
    assert abs(edge_vs_consensus(2.20,2.00)-0.10) < 1e-12

def test_movement_delta():
    d = movement_delta(2.05,2.18)
    assert abs(d['abs'] - 0.13) < 1e-12
    assert abs(d['pct'] - (0.13/2.05)) < 1e-12
