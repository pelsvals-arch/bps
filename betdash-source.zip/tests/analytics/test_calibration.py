from __future__ import annotations

import math

from betdash.analytics.calibration import (
    apply_blend,
    calibration_report,
    fit_blend_alpha,
    fit_isotonic,
    kelly_fraction,
    market_comparison,
    predict_isotonic,
)


def _brier(pairs):
    return sum((p - a) ** 2 for p, a in pairs) / len(pairs)


def test_isotonic_fit_reduces_brier_on_overconfident_predictions():
    pairs = [(0.9, 0), (0.8, 0), (0.2, 0), (0.1, 0), (0.85, 1), (0.75, 1), (0.3, 1), (0.15, 1)]
    breaks = fit_isotonic(pairs)
    calibrated = predict_isotonic(breaks, [p for p, _ in pairs])

    assert _brier(list(zip(calibrated, [a for _, a in pairs]))) < _brier(pairs)


def test_calibration_report_exposes_bin_gaps():
    pairs = [(0.2, 0), (0.25, 0), (0.8, 0), (0.85, 1)]
    report = calibration_report(pairs, bins=2)

    assert report["n"] == 4
    assert math.isfinite(report["brier"])
    assert math.isfinite(report["log_loss"])
    assert any(abs(b["avg_pred"] - b["avg_actual"]) > 0.1 for b in report["bins"])


def test_market_comparison_scores_model_against_devigged_market():
    rows = [
        (0.60, 0.55, 1),
        (0.40, 0.45, 0),
        (0.70, 0.65, 1),
        (0.30, 0.35, 0),
    ]
    result = market_comparison(rows)

    assert result["n"] == 4
    assert result["log_loss_model"] < result["log_loss_market"]
    assert result["delta_log_loss"] < 0


def test_blend_ignores_market_when_coverage_is_below_two():
    assert apply_blend(0.60, 0.90, 0.0) == 0.60


def test_kelly_half_cap_and_floor():
    assert round(kelly_fraction(0.55, 2.0), 6) == 0.05
    assert kelly_fraction(0.95, 2.0) == 0.08
    assert kelly_fraction(0.40, 2.0) == 0.0


def test_fit_blend_alpha_prefers_accurate_model():
    pairs = [(0.70, 0.55, 1), (0.30, 0.45, 0), (0.60, 0.55, 1), (0.40, 0.45, 0)]
    assert fit_blend_alpha(pairs) == 0.0
