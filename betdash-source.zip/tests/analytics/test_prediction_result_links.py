import json
import sqlite3

from betdash.analytics.prediction_links import link_prediction_results
from betdash.analytics.prediction_outcomes import backfill_prediction_outcomes
from betdash.db.repository import SCHEMA_PATH, Repository, init_db


def test_link_prediction_results_scores_outcome_when_uids_differ(tmp_path):
    db = tmp_path / "links.db"
    init_db(str(db))
    repo = Repository(str(db))
    prediction_uid = "prediction-event"
    result_uid = "result-event"
    with repo._connect() as conn:
        conn.execute(
            "INSERT INTO canonical_events (event_uid,sport,league,participant_ids,start_at,mapping_confidence) "
            "VALUES (?,?,?,?,?,?)",
            (prediction_uid, "tennis", "ATP", json.dumps(["name:Andrey Rublev", "name:Daniil Medvedev"]), "2026-01-02T10:00:00Z", 1.0),
        )
        conn.execute(
            "INSERT INTO predictions (prediction_id,event_uid,market,outcome,model_prob,observed_at) "
            "VALUES (?,?,?,?,?,?)",
            ("p1", prediction_uid, "match_winner", "p1", 0.6, "2026-01-02T09:00:00Z"),
        )
        conn.execute(
            "INSERT INTO results (event_uid,participant_a,participant_b,score,league,event_date,source) "
            "VALUES (?,?,?,?,?,?,?)",
            (result_uid, "Rublev A.", "Medvedev D.", "2-0", "ATP", "2026-01-02", "tennis-data"),
        )

    report = link_prediction_results(repo)
    assert report["linked"] == 1
    assert backfill_prediction_outcomes(repo)["settled"] == 1
    with repo._connect() as conn:
        row = conn.execute("SELECT actual FROM prediction_outcomes WHERE prediction_id='p1'").fetchone()
    assert row["actual"] == 1


def test_legacy_db_gains_link_table_from_init_db(tmp_path):
    db = tmp_path / "legacy.db"
    init_db(str(db))
    with sqlite3.connect(db) as conn:
        conn.execute("DROP TABLE prediction_result_links")
    repo = Repository(str(db))
    with repo.connection() as conn:
        conn.execute(
            "INSERT INTO canonical_events (event_uid,sport,league,participant_ids,start_at,mapping_confidence) "
            "VALUES (?,?,?,?,?,?)",
            ("legacy-pred", "tennis", "ATP", json.dumps(["name:Novak Djokovic", "name:Carlos Alcaraz"]), "2026-01-03T10:00:00Z", 1.0),
        )
        conn.execute(
            "INSERT INTO results (event_uid,participant_a,participant_b,score,league,event_date,source) "
            "VALUES (?,?,?,?,?,?,?)",
            ("legacy-result", "Djokovic N.", "Alcaraz C.", "2-0", "ATP", "2026-01-03", "tennis-data"),
        )
        conn.execute(
            "INSERT INTO predictions (prediction_id,event_uid,market,outcome,model_prob,observed_at) "
            "VALUES (?,?,?,?,?,?)",
            ("legacy-p", "legacy-pred", "match_winner", "p1", 0.6, "2026-01-03T09:00:00Z"),
        )
    init_db(str(db))
    assert link_prediction_results(repo)["linked"] == 1


def test_prediction_result_links_ddl_has_single_source():
    ddl = "CREATE TABLE IF NOT EXISTS prediction_result_links"
    assert ddl in SCHEMA_PATH.read_text(encoding="utf-8")

    root = SCHEMA_PATH.parent
    offenders = [
        str(path.relative_to(root))
        for path in root.rglob("*.py")
        if ddl in path.read_text(encoding="utf-8")
    ]
    assert offenders == []
