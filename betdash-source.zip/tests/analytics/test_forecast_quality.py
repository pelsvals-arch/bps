import json
import math

from betdash.analytics.forecast_quality import forecast_quality_report
from betdash.db.repository import Repository, init_db


def _seed(db, *, both_odds=True):
    init_db(str(db))
    repo = Repository(str(db))
    with repo.connection() as conn:
        conn.execute(
            "INSERT INTO canonical_events (event_uid,sport,league,participant_ids,start_at,mapping_confidence) "
            "VALUES (?,?,?,?,?,?)",
            ("q-pred", "tennis", "ATP", json.dumps(["name:Novak Djokovic", "name:Carlos Alcaraz"]), "2026-01-04T10:00:00Z", 1.0),
        )
        conn.execute(
            "INSERT INTO results (event_uid,participant_a,participant_b,score,league,event_date,source) "
            "VALUES (?,?,?,?,?,?,?)",
            ("q-result", "Djokovic N.", "Alcaraz C.", "2-0", "ATP", "2026-01-04", "tennis-data"),
        )
        conn.execute(
            "INSERT INTO predictions (prediction_id,event_uid,market,outcome,model_prob,odds_decimal,observed_at) "
            "VALUES (?,?,?,?,?,?,?)",
            ("q1", "q-pred", "match_winner", "p1", 0.4, 2.0 if both_odds else None, "2026-01-04T09:00:00Z"),
        )
        if both_odds:
            conn.execute(
                "INSERT INTO predictions (prediction_id,event_uid,market,outcome,model_prob,odds_decimal,observed_at) "
                "VALUES (?,?,?,?,?,?,?)",
                ("q2", "q-pred", "match_winner", "p2", 0.6, 2.0, "2026-01-04T09:00:00Z"),
            )
    return repo


def test_forecast_quality_report_scores_model_and_market(tmp_path):
    report = forecast_quality_report(_seed(tmp_path / "quality.db"))
    assert report["links"]["linked"] == 1
    assert report["settlement"]["settled"] == 2
    assert report["sample_type"] == "historical_settled_predictions_not_oof"
    assert "not out-of-sample" in report["warning"]
    assert report["model"]["n"] == 2
    assert math.isclose(report["model"]["brier"], 0.16)
    assert report["market"]["n"] == 2
    assert math.isclose(report["market"]["brier_market"], 0.25)


def test_forecast_quality_report_excludes_incomplete_market_pairs(tmp_path):
    report = forecast_quality_report(_seed(tmp_path / "incomplete.db", both_odds=False))
    assert report["model"]["n"] == 1
    assert report["market"]["n"] == 0
