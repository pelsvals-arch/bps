from datetime import datetime, timezone, timedelta
from betdash.analytics.market_metrics import movement_windows

def test_movement_windows():
    t0 = datetime(2026,1,1,tzinfo=timezone.utc)
    hist = [(t0,2.0),(t0+timedelta(minutes=4),2.1),(t0+timedelta(minutes=59),2.3),(t0+timedelta(minutes=60),2.4)]
    res = movement_windows(hist, now=t0+timedelta(minutes=60), windows_min=[1,5,15,60])
    assert res['60m_pct'] is not None
    assert res['5m_pct'] is not None
