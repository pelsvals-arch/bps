from datetime import datetime, timezone
from betdash.db.repository import Repository
from betdash.normalize.models import RawOdd
from betdash.normalize.registry import EntityRegistry, normalize_event
from betdash.backtest.closing import refresh_closing_lines


def _event(start_at: str):
    reg = EntityRegistry({"P1": "p1", "P2": "p2"})
    return normalize_event(RawOdd(
        bookmaker="bk1", source_event_id="e1", sport="tennis", league="L",
        participants=("P1", "P2"), market="match_winner", outcome="p1", odds_decimal=2.0,
        observed_at=datetime(2026, 1, 1, tzinfo=timezone.utc), is_live=False,
        start_at=datetime.fromisoformat(start_at),
    ), reg)


def test_closing_uses_max_in_primary_window(tmp_path):
    repo = Repository(str(tmp_path / "t.sqlite"))
    ev = _event("2026-01-01T12:00:00+00:00")
    repo.upsert_canonical_event(ev)
    from betdash.db.repository import Snapshot
    repo.save_snapshots([
        Snapshot(event_uid=ev.event_uid, bookmaker="b1", market="match_winner", outcome="p1", odds_decimal=2.0, observed_at=datetime.fromisoformat("2026-01-01T11:20:00+00:00"), source_event_id="e1", adapter_version="t"),
        Snapshot(event_uid=ev.event_uid, bookmaker="b2", market="match_winner", outcome="p1", odds_decimal=2.3, observed_at=datetime.fromisoformat("2026-01-01T11:40:00+00:00"), source_event_id="e1", adapter_version="t"),
        Snapshot(event_uid=ev.event_uid, bookmaker="b3", market="match_winner", outcome="p1", odds_decimal=9.0, observed_at=datetime.fromisoformat("2026-01-01T12:10:00+00:00"), source_event_id="e1", adapter_version="t"),
    ])
    n = refresh_closing_lines(repo, close_window_minutes=60, fallback_window_hours=24)
    assert n == 1
    with repo._connect() as conn:
        row = conn.execute("SELECT odds_closing,bookmaker FROM closing_lines").fetchone()
    assert float(row[0]) == 2.3
    assert row[1] == "b2"
