from pathlib import Path


def test_code_dump_encodes_binary_fixtures_without_data_loss():
    dump = Path("betdash-project-code-for-review.txt")
    text = dump.read_text(encoding="utf-8")

    assert "\ufffd" not in text
    assert "FILE: tests/adapters/fixtures/winline_frame.bin" in text
    assert "ENCODING: base64" in text
