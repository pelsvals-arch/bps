from pathlib import Path


def test_supported_python_version_is_pinned():
    text = Path("pyproject.toml").read_text()

    assert 'requires-python = ">=3.12,<3.13"' in text


def test_pytest_is_not_a_runtime_dependency():
    text = Path("pyproject.toml").read_text()
    runtime = text.split("dependencies = [", 1)[1].split("]", 1)[0]

    assert "pytest" not in runtime


def test_catboost_is_declared_as_optional_dependency():
    text = Path("pyproject.toml").read_text()

    assert "catboost = [" in text
