from datetime import datetime, timezone

from betdash.db.repository import Repository
from betdash.models import features, trainer
from betdash.normalize.models import CanonicalEvent


def _event() -> CanonicalEvent:
    return CanonicalEvent(
        event_uid="e1",
        sport="tennis",
        league="ATP",
        participant_ids=("name:Novak Djokovic", "name:Carlos Alcaraz"),
        start_at=datetime(2026, 11, 28, 12, tzinfo=timezone.utc),
        mapping_confidence=1.0,
    )


def test_build_features_keeps_model_features_numeric(tmp_path, monkeypatch):
    monkeypatch.setattr(
        features,
        "_tennis_sackmann_features",
        lambda repo, p1, p2, start_at: {"surface": "clay", "best_of": 5},
    )

    result = features.build_features(_event(), Repository(str(tmp_path / "f.db")))

    assert isinstance(result["surface"], (int, float))
    assert result["surface_name"] == "clay"
    assert result["best_of"] == 5


def test_score_distribution_uses_surface_name(monkeypatch):
    monkeypatch.setattr(
        trainer,
        "build_features",
        lambda *a, **k: {
            "surface": 0.0,
            "surface_name": "hard",
            "best_of": 5,
            "p1_srv_win": 0.65,
            "p2_srv_win": 0.55,
            "p1_ret_win": 0.35,
            "p2_ret_win": 0.45,
            "p1_elo_blend": 1600.0,
            "p2_elo_blend": 1500.0,
        },
    )
    captured = {}

    def fake_empirical(repo, p1, p2, target):
        captured["target"] = target
        return {((6, 4), (6, 3)): 1.0}

    monkeypatch.setattr(trainer, "empirical_provider_distribution", fake_empirical)

    trainer.build_score_distribution_rows(
        _event(), object(), 0.6, "run-1", datetime(2026, 11, 28, 10, tzinfo=timezone.utc)
    )

    assert captured["target"]["surface"] == "hard"
